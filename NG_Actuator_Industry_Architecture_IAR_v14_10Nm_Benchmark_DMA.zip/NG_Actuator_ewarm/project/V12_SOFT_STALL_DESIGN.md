# NG Actuator v12 — Software Soft Stall / Soft End-Stop

## 1. Baseline

v12 is derived directly from the known-working `v11_1_CalibrationRetryFix` project. The validated SPI2 transport, external CS timing, TMC6460 register layer, motor middleware, `0x00002786` run motion mode, non-zero-flux HOLD behavior, FreeRTOS ownership model, 400 Hz normal position sampling, and `G` calibration implementation are unchanged.

The new software-stall layer is additive and is used only by the new `X` and `Y` test commands. Existing `V`, `W`, `Z`, and `G` behavior remains available as a benchmark.

## 2. Debug UART commands

| Character | Function |
|---|---|
| A | Select/init 10 kg profile |
| B | Select/init 20 kg profile |
| C | Select/init 35 kg profile |
| V | Normal/raw CW benchmark command |
| W | Normal/raw CCW benchmark command |
| Z | Stop/HOLD; also aborts active G/X/Y operation |
| G | Existing automatic 0°/90° calibration |
| X | Software-soft CW move to physical 90° end |
| Y | Software-soft CCW move to physical 0° end |
| P | Print soft-stall tuning macros and current calibration |
| R | Refresh TMC diagnostic snapshot |
| H / ? | Help |

`X/Y` require a successful `G` calibration in the current power-up session because TMC6460 Hall position is incremental.

## 3. Architecture

```text
Debug UART task
   |
   | X / Y command
   v
FreeRTOS motor-command queue
   |
   v
MotorServiceTask (sole TMC6460 bus owner)
   |
   v
ActuatorSoftStall_Run()
   |
   +--> TMC6460_MotorSetVelocity()
   +--> TMC6460_MotorReadMotionSample()
   +--> TMC6460_MotorStopHold()
   |
   v
TMC6460 register layer
   |
   v
Selectable transport (SPI benchmark / UART optional)
```

No other task accesses the TMC6460 while X/Y is active. This preserves the v10.4/v11.1 single-owner bus model.

## 4. Soft move state machine

```text
START
  |
  | valid current-session G calibration required
  v
Determine calibrated target and stroke direction
  |
  v
CRUISE at normal profile velocity
  |
  | position reaches CREEP_START_PERCENT of calibrated stroke
  v
CREEP at low fixed/profile-scaled velocity
  |
  | contact detection armed only near calibrated end
  v
SUSTAINED CONTACT VOTE
  |
  +-- position delta low
  +-- actual velocity low
  +-- torque high (optional)
  |
  | 2-of-3 corroboration, or longer position-only fallback
  v
STOP/HOLD
  |
  | velocity target = 0
  | non-zero hold torque/flux limit remains
  | gate driver remains enabled
  v
COMPLETE
```

The calibrated endpoint is a reference, not an immediate stop point. The actuator is allowed to pass that reference at creep speed so it can softly contact the real mechanical end. A small calibrated-stroke overshoot allowance is the final software guard.

## 5. Qt logic carried into STM32

The working Qt implementation avoided torque-only stopping and used a sustained multi-signal vote based on position movement, actual velocity, and torque. v12 keeps that core idea while using the already-calibrated STM32 endpoints:

- Torque alone can never declare the end.
- Contact voting is disabled until the actuator is in the calibrated end region.
- Position-stable + velocity-low is the default contact detector.
- Optional torque thresholds can be enabled per actuator as corroboration.
- The vote must persist for `ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS`.
- A longer position-only stable interval is retained as a robust fallback.

This prevents spring/load torque in the middle of the stroke from being mistaken for an end stop.

## 6. Main tuning macros

All software-stall policy is centralized in `config/actuator_soft_stall_config.h`.

### Position / percentage

```c
#define ACTUATOR_SOFT_STALL_CREEP_START_PERCENT  96U
#define ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT  97U
```

For a 90° actuator, 96% starts creep with roughly the last 3.6° remaining.

To start creep earlier, reduce `CREEP_START_PERCENT`, e.g. 94. To narrow the creep zone, increase it, e.g. 97 or 98.

### Creep velocity

```c
#define ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW 200000L
#define ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW 200000L
#define ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW 200000L
```

These are intentionally independent of normal V/W speed. Lower them for softer contact; increase them only after validating end impact and reliable motion.

### Contact detector

```c
#define ACTUATOR_SOFT_STALL_POSITION_DELTA_COUNTS       8L
#define ACTUATOR_SOFT_STALL_VELOCITY_STOP_PERCENT      12U
#define ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS        180U
#define ACTUATOR_SOFT_STALL_POSITION_ONLY_CONFIRM_MS  400U
```

### Optional torque corroboration

```c
#define ACTUATOR_SOFT_STALL_10KG_TORQUE_CONTACT_RAW 0L
#define ACTUATOR_SOFT_STALL_20KG_TORQUE_CONTACT_RAW 0L
#define ACTUATOR_SOFT_STALL_35KG_TORQUE_CONTACT_RAW 0L
```

Zero disables torque participation. Enable only after bench characterization.

### Final guards

```c
#define ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 50U
#define ACTUATOR_SOFT_STALL_MAX_MOVE_TIME_MS        30000U
```

`50U` means 0.50% of calibrated stroke beyond the median endpoint.

## 7. Recommended test sequence

1. Power up and select profile: `A` / `B` / `C`.
2. Verify benchmark commands still work: `V`, `Z`, `W`, `Z`.
3. Run `G` and allow calibration to complete.
4. Send `P` and verify current-session zero/90/stroke values.
5. From 0° send `X` and observe CRUISE -> CREEP -> CONTACT -> HOLD.
6. Send `Y` and verify the same behavior back to 0°.
7. Use `Z` at any time during X/Y to abort to HOLD.

## 8. Runtime diagnostics

The normal `STAT` line now adds:

```text
softAct
softSt
softStage
softDir
softCreep
softEnd
softDist
softFinal
softContact
softRetry
```

Stages:
- 0 = IDLE
- 1 = CRUISE
- 2 = CREEP
- 3 = HOLD

Status:
- 0 = OK
- 1 = invalid parameter
- 2 = actuator not initialized
- 3 = calibration required
- 4 = TMC communication error
- 5 = move timeout
- 6 = user aborted
- 7 = overshoot guard

## 9. Safety behavior

Software soft stall is not an energy-isolating safety function. The mechanism must still be validated on a current-limited bench supply. `Z` uses the existing controlled HOLD implementation: it commands zero velocity while preserving the configured hold torque/flux limit and keeping the gate driver enabled.
