#ifndef RUNTIME_MEMORY_H
#define RUNTIME_MEMORY_H

#include <stdint.h>
#include <stddef.h>

typedef struct
{
    uint32_t heap_total_bytes;
    uint32_t heap_free_bytes;
    uint32_t heap_min_ever_free_bytes;
    uint32_t heap_used_now_bytes;
    uint32_t heap_peak_used_bytes;

    uint32_t heartbeat_stack_free_words;
    uint32_t motor_stack_free_words;
    uint32_t command_stack_free_words;
    uint32_t diagnostics_stack_free_words;

    uint32_t motor_queue_spaces;
    uint32_t motor_queue_length;

    uint32_t spi_transfers;
    uint32_t spi_timeouts;
    uint32_t spi_errors;
    uint32_t uart_tx_transfers;
    uint32_t uart_rx_bytes;
    uint32_t uart_rx_dropped;
    uint32_t uart_errors;
} runtime_memory_snapshot_t;

void RuntimeMemory_Get(runtime_memory_snapshot_t *snapshot);
int RuntimeMemory_FormatCompact(char *buffer, size_t buffer_size,
                                const runtime_memory_snapshot_t *snapshot);
int RuntimeMemory_FormatDetailed(char *buffer, size_t buffer_size,
                                 const runtime_memory_snapshot_t *snapshot);

#endif /* RUNTIME_MEMORY_H */
