#ifndef ACTUATOR_SOFT_STALL_CONFIG_H
#define ACTUATOR_SOFT_STALL_CONFIG_H

#include <stdint.h>

/* ========================================================================== */
/* Software soft-stall / soft-end-stop configuration                          */
/* ========================================================================== */
/*
 * Benchmark baseline: v11.1 CalibrationRetryFix.
 *
 * The soft-stall test uses the valid current-session calibration produced by
 * command G.  Normal V/W commands are intentionally unchanged.
 *
 * Sequence:
 *   CRUISE -> calibrated creep-start position -> CREEP -> soft contact -> HOLD
 *
 * Positive velocity remains CW / 0 -> 90 deg.
 * Negative velocity remains CCW / 90 -> 0 deg.
 */

#define ACTUATOR_SOFT_STALL_ENABLE                         1U

/* Dedicated soft-stall control-loop sampling rate.  This is independent from
 * the normal 400 Hz cached position sampling task.  The soft-stall algorithm
 * executes inside MotorServiceTask, which remains the sole TMC bus owner. */
#define ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ                200U

/* Run at this percentage of the profile's default V/W velocity before creep.
 * 100 = same cruise velocity as the normal V/W command. */
#define ACTUATOR_SOFT_STALL_CRUISE_VELOCITY_PERCENT       100U

/* Start creep after this percentage of the calibrated 0..90 stroke has been
 * travelled. 96% means the final 4% (about 3.6 mechanical degrees of a 90 deg
 * stroke) is traversed at creep speed. */
#define ACTUATOR_SOFT_STALL_CREEP_START_PERCENT            96U

/* Contact/stall voting is ignored until this percentage of the calibrated
 * stroke. This prevents normal load/spring torque from being mistaken for the
 * mechanical end. It should be >= CREEP_START_PERCENT. */
#define ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT            97U

/* Creep velocity selection.
 * If the actuator-specific fixed value below is non-zero it is used.
 * If it is zero, CREEP_VELOCITY_PERCENT of cruise velocity is used and then
 * clamped to MIN/MAX. */
#define ACTUATOR_SOFT_STALL_CREEP_VELOCITY_PERCENT         20U
#define ACTUATOR_SOFT_STALL_CREEP_MIN_RAW              100000L
#define ACTUATOR_SOFT_STALL_CREEP_MAX_RAW              350000L

#define ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW    200000L
#define ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW    200000L
#define ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW    200000L

/* Ignore contact voting briefly after motion starts or after changing from
 * cruise to creep. */
#define ACTUATOR_SOFT_STALL_STARTUP_BLANKING_MS           250U
#define ACTUATOR_SOFT_STALL_CREEP_BLANKING_MS             120U

/* Position/velocity contact vote.  Torque is optional and defaults disabled.
 * This follows the working Qt principle that torque alone must never stop the
 * actuator: position must also be stable, or velocity+torque must corroborate
 * near the calibrated end. */
#define ACTUATOR_SOFT_STALL_POSITION_DELTA_COUNTS           8L
#define ACTUATOR_SOFT_STALL_VELOCITY_STOP_PERCENT          12U
#define ACTUATOR_SOFT_STALL_VELOCITY_STOP_MIN_RAW        1000L

/* How long a valid contact vote must persist before HOLD. */
#define ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS            180U

/* Robust fallback: position continuously stable for this time in the armed
 * end region is enough to accept the end even if velocity feedback is noisy. */
#define ACTUATOR_SOFT_STALL_POSITION_ONLY_CONFIRM_MS      400U

/* Optional per-actuator torque corroboration. 0 disables torque threshold.
 * After bench logging, set these to a validated absolute raw torque value. */
#define ACTUATOR_SOFT_STALL_10KG_TORQUE_CONTACT_RAW         0L
#define ACTUATOR_SOFT_STALL_20KG_TORQUE_CONTACT_RAW         0L
#define ACTUATOR_SOFT_STALL_35KG_TORQUE_CONTACT_RAW         0L

/* Endpoint guards.
 * The calibrated exact endpoint is NOT used as an immediate stop point.  The
 * actuator is allowed to creep through that reference and softly touch the
 * real mechanical end, where the sustained software-stall vote stops it.
 * MAX_OVERSHOOT_PERCENT_X100 is the hard software guard beyond the calibrated
 * endpoint in case contact feedback is not detected. 50 = 0.50% of stroke. */
#define ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS      16L
#define ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100     50U /* 0.50% */

/* Hard safety timeout for one X/Y software-stall move. */
#define ACTUATOR_SOFT_STALL_MAX_MOVE_TIME_MS            30000U

/* Settle before reporting final endpoint/holding status. */
#define ACTUATOR_SOFT_STALL_HOLD_SETTLE_MS                100U

/* Transient TMC transport errors are retried, matching the proven calibration
 * resilience approach from v11.1. */
#define ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT                 3U
#define ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS              2U

/* ========================================================================== */
/* Compile-time checks                                                        */
/* ========================================================================== */

#if (ACTUATOR_SOFT_STALL_ENABLE != 0U)

#if ((ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ == 0U) || \
     (ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ > 1000U))
#error "Invalid ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ"
#endif

#if ((ACTUATOR_SOFT_STALL_CREEP_START_PERCENT == 0U) || \
     (ACTUATOR_SOFT_STALL_CREEP_START_PERCENT >= 100U))
#error "Creep start percentage must be between 1 and 99"
#endif

#if ((ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT < \
      ACTUATOR_SOFT_STALL_CREEP_START_PERCENT) || \
     (ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT > 100U))
#error "Contact arm percentage must be >= creep start percentage and <= 100"
#endif

#if (ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS == 0U)
#error "Soft stall contact confirmation must be non-zero"
#endif

#endif /* ACTUATOR_SOFT_STALL_ENABLE */

#endif /* ACTUATOR_SOFT_STALL_CONFIG_H */
