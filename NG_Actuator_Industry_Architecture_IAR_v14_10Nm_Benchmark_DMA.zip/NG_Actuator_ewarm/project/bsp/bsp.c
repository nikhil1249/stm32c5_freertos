#include "bsp.h"
#include "hardware_config.h"

#include <stddef.h>

#if (HW_TMC_UART_ENABLE != 0U)
void HW_TMC_UART_IRQ_HANDLER(void);
#if (HW_UART_DMA_ENABLE != 0U)
void HW_DMA_TMC_UART_RX_IRQ_HANDLER(void);
void HW_DMA_TMC_UART_TX_IRQ_HANDLER(void);
#endif
#endif

#if (HW_TMC_SPI_ENABLE != 0U)
void HW_TMC_SPI_IRQ_HANDLER(void);
#if (HW_SPI_DMA_ENABLE != 0U)
void HW_DMA_SPI2_RX_IRQ_HANDLER(void);
void HW_DMA_SPI2_TX_IRQ_HANDLER(void);
#endif
#endif

#if (HW_DEBUG_UART_ENABLE != 0U)
void HW_DEBUG_UART_IRQ_HANDLER(void);
#if (HW_UART_DMA_ENABLE != 0U)
void HW_DMA_DEBUG_UART_RX_IRQ_HANDLER(void);
void HW_DMA_DEBUG_UART_TX_IRQ_HANDLER(void);
#endif
#endif

#if (HW_TMC_UART_ENABLE != 0U)
static hal_uart_handle_t s_tmc_uart;
#if (HW_UART_DMA_ENABLE != 0U)
static hal_dma_handle_t s_tmc_uart_dma_rx;
static hal_dma_handle_t s_tmc_uart_dma_tx;
#endif
#endif

#if (HW_TMC_SPI_ENABLE != 0U)
static hal_spi_handle_t s_tmc_spi;
#if (HW_SPI_DMA_ENABLE != 0U)
static hal_dma_handle_t s_tmc_spi_dma_rx;
static hal_dma_handle_t s_tmc_spi_dma_tx;
#endif
#endif

#if (HW_DEBUG_UART_ENABLE != 0U)
static hal_uart_handle_t s_debug_uart;
#if (HW_UART_DMA_ENABLE != 0U)
static hal_dma_handle_t s_debug_uart_dma_rx;
static hal_dma_handle_t s_debug_uart_dma_tx;
#endif
#endif

static bsp_status_t BSP_LED_Init(void)
{
    hal_gpio_config_t gpio_config;

    gpio_config.mode        = HAL_GPIO_MODE_OUTPUT;
    gpio_config.speed       = HAL_GPIO_SPEED_FREQ_LOW;
    gpio_config.pull        = HAL_GPIO_PULL_NO;
    gpio_config.output_type = HAL_GPIO_OUTPUT_PUSHPULL;
    gpio_config.init_state  = HW_LED_INIT_STATE;

    return (HAL_GPIO_Init(HW_LED_PORT, HW_LED_PIN, &gpio_config) == HAL_OK) ?
           BSP_OK : BSP_ERROR;
}

#if ((HW_UART_DMA_ENABLE != 0U) || (HW_SPI_DMA_ENABLE != 0U))
static bsp_status_t BSP_DMA_Config(hal_dma_handle_t *hdma,
                                   hal_dma_channel_t channel,
                                   hal_dma_request_source_t request,
                                   hal_dma_direction_t direction,
                                   hal_dma_src_addr_increment_t src_inc,
                                   hal_dma_dest_addr_increment_t dest_inc,
                                   hal_dma_priority_t priority,
                                   IRQn_Type irqn)
{
    hal_dma_direct_xfer_config_t dma_config;

    if (hdma == NULL)
    {
        return BSP_ERROR;
    }

    if (HAL_DMA_Init(hdma, channel) != HAL_OK)
    {
        return BSP_ERROR;
    }

    dma_config.request         = request;
    dma_config.direction       = direction;
    dma_config.src_inc         = src_inc;
    dma_config.dest_inc        = dest_inc;
    dma_config.src_data_width  = HAL_DMA_SRC_DATA_WIDTH_BYTE;
    dma_config.dest_data_width = HAL_DMA_DEST_DATA_WIDTH_BYTE;
    dma_config.priority        = priority;

    if (HAL_DMA_SetConfigDirectXfer(hdma, &dma_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    HAL_CORTEX_NVIC_SetPriority(irqn,
                                HW_DMA_IRQ_PREEMPT_PRIORITY,
                                HW_DMA_IRQ_SUB_PRIORITY);
    HAL_CORTEX_NVIC_EnableIRQ(irqn);

    return BSP_OK;
}
#endif

static bsp_status_t BSP_UART_Config(hal_uart_handle_t *huart,
                                    hal_uart_t instance,
                                    uint32_t baudrate,
                                    hal_gpio_t tx_port,
                                    uint32_t tx_pin,
                                    hal_gpio_t rx_port,
                                    uint32_t rx_pin,
                                    uint32_t alternate,
                                    IRQn_Type irqn,
                                    hal_cortex_nvic_preemp_priority_t preempt_priority,
                                    hal_cortex_nvic_sub_priority_t sub_priority,
                                    hal_status_t (*kernel_clock_config)(void))
{
    hal_uart_config_t uart_config;
    hal_gpio_config_t gpio_config;

    if ((huart == NULL) || (kernel_clock_config == NULL))
    {
        return BSP_ERROR;
    }

    if (HAL_UART_Init(huart, instance) != HAL_OK)
    {
        return BSP_ERROR;
    }

    if (kernel_clock_config() != HAL_OK)
    {
        return BSP_ERROR;
    }

    uart_config.baud_rate        = baudrate;
    uart_config.clock_prescaler  = HW_UART_PRESCALER;
    uart_config.word_length      = HW_UART_WORD_LENGTH;
    uart_config.stop_bits        = HW_UART_STOP_BITS;
    uart_config.parity           = HW_UART_PARITY;
    uart_config.direction        = HW_UART_DIRECTION;
    uart_config.hw_flow_ctl      = HW_UART_HW_FLOW_CONTROL;
    uart_config.oversampling     = HW_UART_OVERSAMPLING;
    uart_config.one_bit_sampling = HW_UART_ONE_BIT_SAMPLING;

    if (HAL_UART_SetConfig(huart, &uart_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    gpio_config.mode        = HAL_GPIO_MODE_ALTERNATE;
    gpio_config.output_type = HW_UART_GPIO_OUTPUT_TYPE;
    gpio_config.pull        = HW_UART_GPIO_PULL;
    gpio_config.speed       = HW_UART_GPIO_SPEED;
    gpio_config.alternate   = alternate;

    if (HAL_GPIO_Init(tx_port, tx_pin, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    if (HAL_GPIO_Init(rx_port, rx_pin, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    HAL_CORTEX_NVIC_SetPriority(irqn, preempt_priority, sub_priority);
    HAL_CORTEX_NVIC_EnableIRQ(irqn);

    return BSP_OK;
}

#if (HW_TMC_SPI_ENABLE != 0U)
static bsp_status_t BSP_SPI_Config(hal_spi_handle_t *hspi)
{
    hal_spi_config_t spi_config;
    hal_gpio_config_t gpio_config;

    if (hspi == NULL)
    {
        return BSP_ERROR;
    }

    if (HW_TMC_SPI_KERNEL_CLOCK_CONFIG() != HAL_OK)
    {
        return BSP_ERROR;
    }

    HW_TMC_SPI_ENABLE_CLOCK();

    if (HAL_SPI_Init(hspi, HW_TMC_SPI_INSTANCE) != HAL_OK)
    {
        return BSP_ERROR;
    }

    spi_config.mode                = HW_TMC_SPI_MODE;
    spi_config.direction           = HW_TMC_SPI_DIRECTION;
    spi_config.data_width          = HW_TMC_SPI_DATA_WIDTH;
    spi_config.clock_polarity      = HW_TMC_SPI_CLOCK_POLARITY;
    spi_config.clock_phase         = HW_TMC_SPI_CLOCK_PHASE;
    spi_config.baud_rate_prescaler = HW_TMC_SPI_BAUD_PRESCALER;
    spi_config.first_bit           = HW_TMC_SPI_FIRST_BIT;
    spi_config.nss_pin_management  = HW_TMC_SPI_NSS_MANAGEMENT;

    if (HAL_SPI_SetConfig(hspi, &spi_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

#if (HW_TMC_SPI_EXTERNAL_CS_ENABLE != 0U)
    gpio_config.mode        = HAL_GPIO_MODE_OUTPUT;
    gpio_config.output_type = HAL_GPIO_OUTPUT_PUSHPULL;
    gpio_config.pull        = HAL_GPIO_PULL_NO;
    gpio_config.speed       = HW_TMC_SPI_GPIO_SPEED;
    gpio_config.init_state  = HW_TMC_SPI_CS_INACTIVE_STATE;

    if (HAL_GPIO_Init(HW_TMC_SPI_CS_PORT, HW_TMC_SPI_CS_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    HAL_GPIO_WritePin(HW_TMC_SPI_CS_PORT,
                      HW_TMC_SPI_CS_PIN,
                      HW_TMC_SPI_CS_INACTIVE_STATE);
#endif

    gpio_config.mode        = HAL_GPIO_MODE_ALTERNATE;
    gpio_config.output_type = HW_TMC_SPI_GPIO_OUTPUT_TYPE;
    gpio_config.speed       = HW_TMC_SPI_GPIO_SPEED;
    gpio_config.alternate   = HW_TMC_SPI_GPIO_AF;

    gpio_config.pull = HW_TMC_SPI_SCK_PULL;
    if (HAL_GPIO_Init(HW_TMC_SPI_SCK_PORT, HW_TMC_SPI_SCK_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    gpio_config.pull = HW_TMC_SPI_MISO_PULL;
    if (HAL_GPIO_Init(HW_TMC_SPI_MISO_PORT, HW_TMC_SPI_MISO_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    gpio_config.pull = HW_TMC_SPI_MOSI_PULL;
    if (HAL_GPIO_Init(HW_TMC_SPI_MOSI_PORT, HW_TMC_SPI_MOSI_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

#if (HW_TMC_SPI_EXTERNAL_CS_ENABLE == 0U)
    gpio_config.mode        = HAL_GPIO_MODE_ALTERNATE;
    gpio_config.output_type = HW_TMC_SPI_GPIO_OUTPUT_TYPE;
    gpio_config.pull        = HAL_GPIO_PULL_NO;
    gpio_config.speed       = HW_TMC_SPI_GPIO_SPEED;
    gpio_config.alternate   = HW_TMC_SPI_CS_GPIO_AF;

    if (HAL_GPIO_Init(HW_TMC_SPI_CS_PORT, HW_TMC_SPI_CS_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }
#endif

    HAL_CORTEX_NVIC_SetPriority(HW_TMC_SPI_IRQn,
                                HW_TMC_SPI_IRQ_PREEMPT_PRIORITY,
                                HW_TMC_SPI_IRQ_SUB_PRIORITY);
    HAL_CORTEX_NVIC_EnableIRQ(HW_TMC_SPI_IRQn);

    return BSP_OK;
}
#endif

#if (HW_TMC_UART_ENABLE != 0U)
static hal_status_t BSP_TMC_UART_SetKernelClock(void)
{
    return HW_TMC_UART_KERNEL_CLOCK_CONFIG();
}
#endif

#if (HW_DEBUG_UART_ENABLE != 0U)
static hal_status_t BSP_DEBUG_UART_SetKernelClock(void)
{
    return HW_DEBUG_UART_KERNEL_CLOCK_CONFIG();
}
#endif

bsp_status_t BSP_Init(void)
{
#if ((HW_UART_DMA_ENABLE != 0U) || (HW_SPI_DMA_ENABLE != 0U))
    /* USE_HAL_DMA_CLK_ENABLE_MODEL is HAL_CLK_ENABLE_NO: BSP owns the clock. */
    HAL_RCC_LPDMA1_EnableClock();
#endif

    if (BSP_LED_Init() != BSP_OK)
    {
        return BSP_ERROR;
    }

#if (HW_TMC_UART_ENABLE != 0U)
    if (BSP_UART_Config(&s_tmc_uart,
                        HW_TMC_UART_INSTANCE,
                        HW_TMC_UART_BAUDRATE,
                        HW_TMC_UART_TX_PORT,
                        HW_TMC_UART_TX_PIN,
                        HW_TMC_UART_RX_PORT,
                        HW_TMC_UART_RX_PIN,
                        HW_TMC_UART_GPIO_AF,
                        HW_TMC_UART_IRQn,
                        HW_TMC_UART_IRQ_PREEMPT_PRIORITY,
                        HW_TMC_UART_IRQ_SUB_PRIORITY,
                        BSP_TMC_UART_SetKernelClock) != BSP_OK)
    {
        return BSP_ERROR;
    }
#if (HW_UART_DMA_ENABLE != 0U)
    if ((BSP_DMA_Config(&s_tmc_uart_dma_rx,
                        HW_DMA_TMC_UART_RX_CHANNEL,
                        HW_DMA_TMC_UART_RX_REQUEST,
                        HAL_DMA_DIRECTION_PERIPH_TO_MEMORY,
                        HAL_DMA_SRC_ADDR_FIXED,
                        HAL_DMA_DEST_ADDR_INCREMENTED,
                        HW_DMA_UART_PRIORITY,
                        HW_DMA_TMC_UART_RX_IRQn) != BSP_OK) ||
        (BSP_DMA_Config(&s_tmc_uart_dma_tx,
                        HW_DMA_TMC_UART_TX_CHANNEL,
                        HW_DMA_TMC_UART_TX_REQUEST,
                        HAL_DMA_DIRECTION_MEMORY_TO_PERIPH,
                        HAL_DMA_SRC_ADDR_INCREMENTED,
                        HAL_DMA_DEST_ADDR_FIXED,
                        HW_DMA_UART_PRIORITY,
                        HW_DMA_TMC_UART_TX_IRQn) != BSP_OK) ||
        (HAL_UART_SetRxDMA(&s_tmc_uart, &s_tmc_uart_dma_rx) != HAL_OK) ||
        (HAL_UART_SetTxDMA(&s_tmc_uart, &s_tmc_uart_dma_tx) != HAL_OK))
    {
        return BSP_ERROR;
    }
#endif
#endif

#if (HW_TMC_SPI_ENABLE != 0U)
    if (BSP_SPI_Config(&s_tmc_spi) != BSP_OK)
    {
        return BSP_ERROR;
    }
#if (HW_SPI_DMA_ENABLE != 0U)
    if ((BSP_DMA_Config(&s_tmc_spi_dma_rx,
                        HW_DMA_SPI2_RX_CHANNEL,
                        HW_DMA_SPI2_RX_REQUEST,
                        HAL_DMA_DIRECTION_PERIPH_TO_MEMORY,
                        HAL_DMA_SRC_ADDR_FIXED,
                        HAL_DMA_DEST_ADDR_INCREMENTED,
                        HW_DMA_SPI_PRIORITY,
                        HW_DMA_SPI2_RX_IRQn) != BSP_OK) ||
        (BSP_DMA_Config(&s_tmc_spi_dma_tx,
                        HW_DMA_SPI2_TX_CHANNEL,
                        HW_DMA_SPI2_TX_REQUEST,
                        HAL_DMA_DIRECTION_MEMORY_TO_PERIPH,
                        HAL_DMA_SRC_ADDR_INCREMENTED,
                        HAL_DMA_DEST_ADDR_FIXED,
                        HW_DMA_SPI_PRIORITY,
                        HW_DMA_SPI2_TX_IRQn) != BSP_OK) ||
        (HAL_SPI_SetRxDMA(&s_tmc_spi, &s_tmc_spi_dma_rx) != HAL_OK) ||
        (HAL_SPI_SetTxDMA(&s_tmc_spi, &s_tmc_spi_dma_tx) != HAL_OK))
    {
        return BSP_ERROR;
    }
#endif
#endif

#if (HW_DEBUG_UART_ENABLE != 0U)
    if (BSP_UART_Config(&s_debug_uart,
                        HW_DEBUG_UART_INSTANCE,
                        HW_DEBUG_UART_BAUDRATE,
                        HW_DEBUG_UART_TX_PORT,
                        HW_DEBUG_UART_TX_PIN,
                        HW_DEBUG_UART_RX_PORT,
                        HW_DEBUG_UART_RX_PIN,
                        HW_DEBUG_UART_GPIO_AF,
                        HW_DEBUG_UART_IRQn,
                        HW_DEBUG_UART_IRQ_PREEMPT_PRIORITY,
                        HW_DEBUG_UART_IRQ_SUB_PRIORITY,
                        BSP_DEBUG_UART_SetKernelClock) != BSP_OK)
    {
        return BSP_ERROR;
    }
#if (HW_UART_DMA_ENABLE != 0U)
    if ((BSP_DMA_Config(&s_debug_uart_dma_rx,
                        HW_DMA_DEBUG_UART_RX_CHANNEL,
                        HW_DMA_DEBUG_UART_RX_REQUEST,
                        HAL_DMA_DIRECTION_PERIPH_TO_MEMORY,
                        HAL_DMA_SRC_ADDR_FIXED,
                        HAL_DMA_DEST_ADDR_INCREMENTED,
                        HW_DMA_UART_PRIORITY,
                        HW_DMA_DEBUG_UART_RX_IRQn) != BSP_OK) ||
        (BSP_DMA_Config(&s_debug_uart_dma_tx,
                        HW_DMA_DEBUG_UART_TX_CHANNEL,
                        HW_DMA_DEBUG_UART_TX_REQUEST,
                        HAL_DMA_DIRECTION_MEMORY_TO_PERIPH,
                        HAL_DMA_SRC_ADDR_INCREMENTED,
                        HAL_DMA_DEST_ADDR_FIXED,
                        HW_DMA_UART_PRIORITY,
                        HW_DMA_DEBUG_UART_TX_IRQn) != BSP_OK) ||
        (HAL_UART_SetRxDMA(&s_debug_uart, &s_debug_uart_dma_rx) != HAL_OK) ||
        (HAL_UART_SetTxDMA(&s_debug_uart, &s_debug_uart_dma_tx) != HAL_OK))
    {
        return BSP_ERROR;
    }
#endif
#endif

    return BSP_OK;
}

void BSP_LED_On(void)     { HAL_GPIO_WritePin(HW_LED_PORT, HW_LED_PIN, HAL_GPIO_PIN_SET); }
void BSP_LED_Off(void)    { HAL_GPIO_WritePin(HW_LED_PORT, HW_LED_PIN, HAL_GPIO_PIN_RESET); }
void BSP_LED_Toggle(void) { HAL_GPIO_TogglePin(HW_LED_PORT, HW_LED_PIN); }

hal_uart_handle_t *BSP_UART_GetHandle(bsp_uart_id_t id)
{
#if (HW_TMC_UART_ENABLE != 0U)
    if (id == BSP_UART_TMC) { return &s_tmc_uart; }
#endif
#if (HW_DEBUG_UART_ENABLE != 0U)
    if (id == BSP_UART_DEBUG) { return &s_debug_uart; }
#endif
    return NULL;
}

hal_spi_handle_t *BSP_SPI_GetHandle(bsp_spi_id_t id)
{
#if (HW_TMC_SPI_ENABLE != 0U)
    if (id == BSP_SPI_TMC) { return &s_tmc_spi; }
#else
    (void)id;
#endif
    return NULL;
}

void BSP_SPI_Select(bsp_spi_id_t id)
{
#if ((HW_TMC_SPI_ENABLE != 0U) && (HW_TMC_SPI_EXTERNAL_CS_ENABLE != 0U))
    if (id == BSP_SPI_TMC)
    {
        HAL_GPIO_WritePin(HW_TMC_SPI_CS_PORT, HW_TMC_SPI_CS_PIN, HW_TMC_SPI_CS_ACTIVE_STATE);
    }
#else
    (void)id;
#endif
}

void BSP_SPI_Deselect(bsp_spi_id_t id)
{
#if ((HW_TMC_SPI_ENABLE != 0U) && (HW_TMC_SPI_EXTERNAL_CS_ENABLE != 0U))
    if (id == BSP_SPI_TMC)
    {
        HAL_GPIO_WritePin(HW_TMC_SPI_CS_PORT, HW_TMC_SPI_CS_PIN, HW_TMC_SPI_CS_INACTIVE_STATE);
    }
#else
    (void)id;
#endif
}

#if (HW_TMC_UART_ENABLE != 0U)
void HW_TMC_UART_IRQ_HANDLER(void) { HAL_UART_IRQHandler(&s_tmc_uart); }
#if (HW_UART_DMA_ENABLE != 0U)
void HW_DMA_TMC_UART_RX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_tmc_uart_dma_rx); }
void HW_DMA_TMC_UART_TX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_tmc_uart_dma_tx); }
#endif
#endif

#if (HW_TMC_SPI_ENABLE != 0U)
void HW_TMC_SPI_IRQ_HANDLER(void) { HAL_SPI_IRQHandler(&s_tmc_spi); }
#if (HW_SPI_DMA_ENABLE != 0U)
void HW_DMA_SPI2_RX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_tmc_spi_dma_rx); }
void HW_DMA_SPI2_TX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_tmc_spi_dma_tx); }
#endif
#endif

#if (HW_DEBUG_UART_ENABLE != 0U)
void HW_DEBUG_UART_IRQ_HANDLER(void) { HAL_UART_IRQHandler(&s_debug_uart); }
#if (HW_UART_DMA_ENABLE != 0U)
void HW_DMA_DEBUG_UART_RX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_debug_uart_dma_rx); }
void HW_DMA_DEBUG_UART_TX_IRQ_HANDLER(void) { HAL_DMA_IRQHandler(&s_debug_uart_dma_tx); }
#endif
#endif
