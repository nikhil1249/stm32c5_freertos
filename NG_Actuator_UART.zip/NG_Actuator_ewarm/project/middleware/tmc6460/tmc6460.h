#ifndef TMC6460_H
#define TMC6460_H

#include "uart_iface.h"
#include "tmc6460_registers.h"
#include <stdint.h>

typedef enum
{
    TMC6460_OK = 0,
    TMC6460_ERROR,
    TMC6460_BUSY,
    TMC6460_TIMEOUT,
    TMC6460_INVALID_PARAM,
    TMC6460_INVALID_RESPONSE,
    TMC6460_INVALID_CHIP_ID,
    TMC6460_DRIVER_NOT_ENABLED,
    TMC6460_HALL_INVALID,
    TMC6460_VELOCITY_LIMIT_FAULT
} tmc6460_status_t;

typedef struct
{
    uart_if_port_t uart_port;
    uint32_t timeout_ms;
} tmc6460_t;

void TMC6460_Init(tmc6460_t *device,
                  uart_if_port_t uart_port,
                  uint32_t timeout_ms);

tmc6460_status_t TMC6460_ReadRegister(tmc6460_t *device,
                                      uint16_t address,
                                      uint32_t *value);

tmc6460_status_t TMC6460_WriteRegister(tmc6460_t *device,
                                       uint16_t address,
                                       uint32_t value);

tmc6460_status_t TMC6460_ReadField(tmc6460_t *device,
                                   uint16_t address,
                                   uint32_t mask,
                                   uint8_t shift,
                                   uint32_t *value);

tmc6460_status_t TMC6460_WriteField(tmc6460_t *device,
                                    uint16_t address,
                                    uint32_t mask,
                                    uint8_t shift,
                                    uint32_t value);

tmc6460_status_t TMC6460_ReadChipID(tmc6460_t *device,
                                    uint32_t *chip_id);

tmc6460_status_t TMC6460_CheckCommunication(tmc6460_t *device,
                                             uint32_t expected_chip_id);

#endif /* TMC6460_H */
