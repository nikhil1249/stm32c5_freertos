#include "uart_iface.h"
#include "hardware_config.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "stream_buffer.h"
#include "task.h"

#include <stddef.h>

typedef struct
{
    hal_uart_handle_t *handle;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t tx_done;
    SemaphoreHandle_t rx_done;
    StreamBufferHandle_t rx_stream;
    uint8_t buffered_rx_byte;
    volatile uint8_t error;
    volatile uint8_t buffered_rx_enabled;
    uint8_t initialized;
} uart_if_context_t;

static uart_if_context_t s_uart[UART_IF_PORT_COUNT];

static uart_if_context_t *UART_IF_GetContext(uart_if_port_t port)
{
    if ((uint32_t)port >= (uint32_t)UART_IF_PORT_COUNT)
    {
        return NULL;
    }

    return &s_uart[(uint32_t)port];
}

static uart_if_context_t *UART_IF_FindByHandle(hal_uart_handle_t *huart)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)UART_IF_PORT_COUNT; i++)
    {
        if ((s_uart[i].initialized != 0U) && (s_uart[i].handle == huart))
        {
            return &s_uart[i];
        }
    }

    return NULL;
}

static void UART_IF_ClearSemaphore(SemaphoreHandle_t semaphore)
{
    while (xSemaphoreTake(semaphore, (TickType_t)0U) == pdTRUE)
    {
        /* Drain stale completion tokens. */
    }
}

static uart_if_status_t UART_IF_Register(uart_if_port_t port,
                                         hal_uart_handle_t *handle)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);

    if ((ctx == NULL) || (handle == NULL))
    {
        return UART_IF_INVALID_PARAM;
    }

    ctx->handle = handle;
    ctx->error = 0U;
    ctx->buffered_rx_enabled = 0U;
    ctx->buffered_rx_byte = 0U;
    ctx->initialized = 0U;

    ctx->mutex = xSemaphoreCreateMutex();
    ctx->tx_done = xSemaphoreCreateBinary();
    ctx->rx_done = xSemaphoreCreateBinary();
    ctx->rx_stream = NULL;

    if ((ctx->mutex == NULL) || (ctx->tx_done == NULL) || (ctx->rx_done == NULL))
    {
        return UART_IF_ERROR;
    }

    ctx->initialized = 1U;
    return UART_IF_OK;
}

uart_if_status_t UART_IF_Init(void)
{
    uart_if_status_t status;

    status = UART_IF_Register(UART_IF_PORT_TMC,
                              BSP_UART_GetHandle(BSP_UART_TMC));
    if (status != UART_IF_OK)
    {
        return status;
    }

#if (HW_DEBUG_UART_ENABLE != 0U)
    status = UART_IF_Register(UART_IF_PORT_DEBUG,
                              BSP_UART_GetHandle(BSP_UART_DEBUG));
    if (status != UART_IF_OK)
    {
        return status;
    }
#endif

    return UART_IF_OK;
}

static uart_if_status_t UART_IF_Lock(uart_if_context_t *ctx,
                                     uint32_t timeout_ms)
{
    TickType_t timeout_ticks = pdMS_TO_TICKS(timeout_ms);

    if (timeout_ticks == 0U)
    {
        timeout_ticks = 1U;
    }

    if (xSemaphoreTake(ctx->mutex, timeout_ticks) != pdTRUE)
    {
        return UART_IF_BUSY;
    }

    return UART_IF_OK;
}

static void UART_IF_Unlock(uart_if_context_t *ctx)
{
    (void)xSemaphoreGive(ctx->mutex);
}

static uart_if_status_t UART_IF_WaitCompletion(uart_if_context_t *ctx,
                                               SemaphoreHandle_t semaphore,
                                               uint32_t timeout_ms)
{
    TickType_t timeout_ticks = pdMS_TO_TICKS(timeout_ms);

    if (timeout_ticks == 0U)
    {
        timeout_ticks = 1U;
    }

    if (xSemaphoreTake(semaphore, timeout_ticks) != pdTRUE)
    {
        (void)HAL_UART_Abort(ctx->handle);
        return UART_IF_TIMEOUT;
    }

    if (ctx->error != 0U)
    {
        return UART_IF_ERROR;
    }

    return UART_IF_OK;
}

uart_if_status_t UART_IF_Write(uart_if_port_t port,
                               const uint8_t *data,
                               uint32_t length,
                               uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hal_status;

    if ((ctx == NULL) || (data == NULL) || (length == 0U))
    {
        return UART_IF_INVALID_PARAM;
    }

    if (ctx->initialized == 0U)
    {
        return UART_IF_NOT_INITIALIZED;
    }

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK)
    {
        return result;
    }

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->tx_done);

    hal_status = HAL_UART_Transmit_IT(ctx->handle, data, length);
    if (hal_status != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hal_status == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->tx_done, timeout_ms);
    UART_IF_Unlock(ctx);
    return result;
}

uart_if_status_t UART_IF_Read(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t length,
                              uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hal_status;

    if ((ctx == NULL) || (data == NULL) || (length == 0U))
    {
        return UART_IF_INVALID_PARAM;
    }

    if (ctx->initialized == 0U)
    {
        return UART_IF_NOT_INITIALIZED;
    }

    /* A UART cannot use transactional RX and continuous buffered RX at once. */
    if (ctx->buffered_rx_enabled != 0U)
    {
        return UART_IF_BUSY;
    }

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK)
    {
        return result;
    }

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->rx_done);

    hal_status = HAL_UART_Receive_IT(ctx->handle, data, length);
    if (hal_status != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hal_status == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->rx_done, timeout_ms);
    UART_IF_Unlock(ctx);
    return result;
}

uart_if_status_t UART_IF_WriteRead(uart_if_port_t port,
                                   const uint8_t *tx_data,
                                   uint32_t tx_length,
                                   uint8_t *rx_data,
                                   uint32_t rx_length,
                                   uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hal_status;

    if ((ctx == NULL) || (tx_data == NULL) || (rx_data == NULL) ||
        (tx_length == 0U) || (rx_length == 0U))
    {
        return UART_IF_INVALID_PARAM;
    }

    if (ctx->initialized == 0U)
    {
        return UART_IF_NOT_INITIALIZED;
    }

    if (ctx->buffered_rx_enabled != 0U)
    {
        return UART_IF_BUSY;
    }

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK)
    {
        return result;
    }

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->tx_done);
    UART_IF_ClearSemaphore(ctx->rx_done);

    /* TMC6460 can respond immediately. Arm RX before transmitting. */
    hal_status = HAL_UART_Receive_IT(ctx->handle, rx_data, rx_length);
    if (hal_status != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hal_status == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    hal_status = HAL_UART_Transmit_IT(ctx->handle, tx_data, tx_length);
    if (hal_status != HAL_OK)
    {
        (void)HAL_UART_Abort(ctx->handle);
        UART_IF_Unlock(ctx);
        return (hal_status == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->rx_done, timeout_ms);
    if (result == UART_IF_OK)
    {
        result = UART_IF_WaitCompletion(ctx, ctx->tx_done, timeout_ms);
    }

    UART_IF_Unlock(ctx);
    return result;
}

uart_if_status_t UART_IF_StartBufferedRx(uart_if_port_t port)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    hal_status_t hal_status;

    if (ctx == NULL)
    {
        return UART_IF_INVALID_PARAM;
    }

    if (ctx->initialized == 0U)
    {
        return UART_IF_NOT_INITIALIZED;
    }

    if (ctx->buffered_rx_enabled != 0U)
    {
        return UART_IF_OK;
    }

    ctx->rx_stream = xStreamBufferCreate((size_t)HW_DEBUG_RX_STREAM_SIZE, 1U);
    if (ctx->rx_stream == NULL)
    {
        return UART_IF_ERROR;
    }

    ctx->error = 0U;
    ctx->buffered_rx_enabled = 1U;

    hal_status = HAL_UART_Receive_IT(ctx->handle, &ctx->buffered_rx_byte, 1U);
    if (hal_status != HAL_OK)
    {
        ctx->buffered_rx_enabled = 0U;
        vStreamBufferDelete(ctx->rx_stream);
        ctx->rx_stream = NULL;
        return (hal_status == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    return UART_IF_OK;
}

uint32_t UART_IF_ReadBuffered(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t max_length,
                              uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    TickType_t timeout_ticks;
    size_t received;

    if ((ctx == NULL) || (data == NULL) || (max_length == 0U) ||
        (ctx->initialized == 0U) || (ctx->buffered_rx_enabled == 0U) ||
        (ctx->rx_stream == NULL))
    {
        return 0U;
    }

    timeout_ticks = pdMS_TO_TICKS(timeout_ms);
    if ((timeout_ms != 0U) && (timeout_ticks == 0U))
    {
        timeout_ticks = 1U;
    }

    received = xStreamBufferReceive(ctx->rx_stream,
                                    data,
                                    (size_t)max_length,
                                    timeout_ticks);

    return (uint32_t)received;
}

void HAL_UART_TxCpltCallback(hal_uart_handle_t *huart)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t higher_priority_task_woken = pdFALSE;

    if (ctx != NULL)
    {
        (void)xSemaphoreGiveFromISR(ctx->tx_done, &higher_priority_task_woken);
        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
}

void HAL_UART_RxCpltCallback(hal_uart_handle_t *huart,
                             uint32_t size_byte,
                             hal_uart_rx_event_types_t rx_event)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t higher_priority_task_woken = pdFALSE;

    (void)size_byte;
    (void)rx_event;

    if (ctx == NULL)
    {
        return;
    }

    if ((ctx->buffered_rx_enabled != 0U) && (ctx->rx_stream != NULL))
    {
        (void)xStreamBufferSendFromISR(ctx->rx_stream,
                                       &ctx->buffered_rx_byte,
                                       1U,
                                       &higher_priority_task_woken);

        /* Keep USART RX armed continuously. */
        if (HAL_UART_Receive_IT(ctx->handle, &ctx->buffered_rx_byte, 1U) != HAL_OK)
        {
            ctx->error = 1U;
        }
    }
    else
    {
        (void)xSemaphoreGiveFromISR(ctx->rx_done, &higher_priority_task_woken);
    }

    portYIELD_FROM_ISR(higher_priority_task_woken);
}

void HAL_UART_ErrorCallback(hal_uart_handle_t *huart)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t higher_priority_task_woken = pdFALSE;

    if (ctx != NULL)
    {
        ctx->error = 1U;

        if (ctx->buffered_rx_enabled != 0U)
        {
            /* Re-arm command RX after a recoverable UART error. */
            if (HAL_UART_Receive_IT(ctx->handle, &ctx->buffered_rx_byte, 1U) == HAL_OK)
            {
                ctx->error = 0U;
            }
        }
        else
        {
            (void)xSemaphoreGiveFromISR(ctx->rx_done, &higher_priority_task_woken);
        }

        (void)xSemaphoreGiveFromISR(ctx->tx_done, &higher_priority_task_woken);
        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
}
