#ifndef UART_IFACE_H
#define UART_IFACE_H

#include "bsp.h"
#include <stdint.h>

typedef enum
{
    UART_IF_OK = 0,
    UART_IF_ERROR,
    UART_IF_BUSY,
    UART_IF_TIMEOUT,
    UART_IF_INVALID_PARAM,
    UART_IF_NOT_INITIALIZED
} uart_if_status_t;

typedef enum
{
    UART_IF_PORT_TMC = 0,
    UART_IF_PORT_DEBUG,
    UART_IF_PORT_COUNT
} uart_if_port_t;

uart_if_status_t UART_IF_Init(void);

uart_if_status_t UART_IF_Write(uart_if_port_t port,
                               const uint8_t *data,
                               uint32_t length,
                               uint32_t timeout_ms);

/* Transactional interrupt RX.  Intended for request/response devices. */
uart_if_status_t UART_IF_Read(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t length,
                              uint32_t timeout_ms);

uart_if_status_t UART_IF_WriteRead(uart_if_port_t port,
                                   const uint8_t *tx_data,
                                   uint32_t tx_length,
                                   uint8_t *rx_data,
                                   uint32_t rx_length,
                                   uint32_t timeout_ms);

/* Continuous one-byte interrupt RX into a FreeRTOS stream buffer.
 * Used by the debug/command UART so commands cannot be lost while tasks run. */
uart_if_status_t UART_IF_StartBufferedRx(uart_if_port_t port);

uint32_t UART_IF_ReadBuffered(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t max_length,
                              uint32_t timeout_ms);

#endif /* UART_IFACE_H */
