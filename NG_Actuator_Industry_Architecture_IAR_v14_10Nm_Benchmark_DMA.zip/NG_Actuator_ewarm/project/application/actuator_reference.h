#ifndef ACTUATOR_REFERENCE_H
#define ACTUATOR_REFERENCE_H

#include "actuator_calibration.h"
#include "actuator_profile.h"
#include <stdint.h>

/*
 * Persistent calibration vs. runtime position reference
 * -----------------------------------------------------
 * The Hall position counter is incremental.  Therefore the reusable values
 * after a power cycle are STROKE_COUNTS and DIRECTION_SIGN.  Absolute raw
 * ZERO/NINETY values printed by G are retained only as diagnostics.
 *
 * At boot, if ACT_CAL_x_VALID is 1, X/Y are immediately enabled.  The first
 * X/Y command performs a low-speed soft reference search to the requested
 * physical end and establishes the current-session raw zero/ninety references.
 * No full G calibration is required again.
 */
typedef struct
{
    actuator_type_t actuator_type;

    uint8_t calibration_available;
    uint8_t runtime_anchor_valid;

    uint32_t stroke_counts;
    int32_t direction_sign;

    int32_t stored_zero_raw_reference;
    int32_t stored_ninety_raw_reference;

    int32_t runtime_zero_raw;
    int32_t runtime_ninety_raw;
} actuator_reference_t;

void ActuatorReference_Clear(actuator_reference_t *reference);

/* Load ACT_CAL_x_* macros for the selected actuator. */
uint8_t ActuatorReference_LoadCompileTime(actuator_type_t type,
                                          actuator_reference_t *reference);

/* Use a just-completed G calibration immediately in this session. */
void ActuatorReference_UpdateFromCalibration(
    actuator_reference_t *reference,
    const actuator_calibration_result_t *calibration);

/* Establish the current-session raw reference after softly touching one end.
 * reached_ninety != 0 means the CW/90-degree end was touched; otherwise the
 * CCW/0-degree end was touched.  The opposite endpoint is derived from the
 * stored calibrated stroke. */
void ActuatorReference_AnchorAtEnd(actuator_reference_t *reference,
                                   uint8_t reached_ninety,
                                   int32_t position_raw);

/* Convert the current reference to the legacy calibration result shape used by
 * angle/debug code. Returns 1 only when a runtime anchor exists. */
uint8_t ActuatorReference_ToCalibrationResult(
    const actuator_reference_t *reference,
    actuator_calibration_result_t *result);

int32_t ActuatorReference_PositionToDegX100(
    const actuator_reference_t *reference,
    int32_t position_raw);

#endif /* ACTUATOR_REFERENCE_H */
