# NG Actuator v14 — 10 Nm Calibration Benchmark, DMA I/O and Runtime Memory Instrumentation

## 1. Benchmark definition

The functional baseline is `NG_Actuator_Industry_Architecture_IAR_v13_2_CalibrationRestoreFix`.
For the 10 Nm actuator, command `A` remains the legacy `ACTUATOR_TYPE_10KG` enum for source compatibility, but its display name is now **10 Nm benchmark**.

Validated behavior that must not be changed casually:

- STM32C562RE, HCLK 144 MHz, FreeRTOS tick 1 kHz.
- TMC6460 SPI2 host interface with external GPIO CSN.
- TMC6460 run motion mode `0x00002786`; initialization mode `0x00002386`.
- Runtime TMC position acquisition at 400 Hz.
- `A` initialize benchmark actuator, `V/W` manual direction, `Z` hold, `G` calibration, `X/Y` soft ends.
- Calibration and soft end use the sole-owner MotorService task.

## 2. Requested configuration changes

### 2.1 10 Nm profile speed

`project/application/actuator_profile.c`

```c
{ 1000, 1200, 1200, 9000000, 9000000 }
```

The two `9000000` fields are `default_velocity_raw` and `maximum_velocity_raw`.
Only the benchmark A profile is changed. B/C remain untouched until independently validated.

### 2.2 Calibration leg timeout

```c
#define ACTUATOR_CALIBRATION_MAX_LEG_TIME_MS 150000U
```

Each homing/calibration leg can therefore run for up to 150 seconds before the safety timeout is declared.

### 2.3 Soft stall creep start

```c
#define ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 9800U
```

Creep begins at 98.00% of the calibrated stroke. The existing contact-arm point remains 99.50%.

### 2.4 Reduced debug traffic

Periodic diagnostics are changed from the large multi-hundred-byte line to a compact one-second status. Detailed memory data is printed only on command `M`; controller refresh remains on `R`; soft configuration remains on `P`.

## 3. Layered architecture

```text
Application
  app.c
  actuator_calibration.c
  actuator_reference.c
  actuator_soft_stall.c
  actuator_profile.c
  runtime_memory.c
          |
          v
TMC6460 middleware
  tmc6460_motor.c
  tmc6460.c
  tmc6460_transport.c
          |
          +-------------------+
          |                   |
          v                   v
     UART interface       SPI interface
       DMA/IT               DMA/IT
          |                   |
          +--------+----------+
                   v
                  BSP
         UART/SPI/DMA/GPIO/NVIC
                   |
                   v
             STM32C562RE HAL2
```

`hardware_config.h` contains STM32C5-specific routing, clock, DMA channels, interrupts, task sizing and communication policy. Motor/control code never contains DMA channel numbers or GPIO pins.

## 4. DMA architecture

### 4.1 Selection

```c
#define HW_UART_DMA_ENABLE 1U
#define HW_SPI_DMA_ENABLE  1U
```

These switches are independent of the TMC host interface selector:

```c
#define HW_TMC_UART_ENABLE 0U
#define HW_TMC_SPI_ENABLE  1U
```

### 4.2 LPDMA1 channel allocation

| Channel | Function | Request |
|---|---|---|
| CH0 | SPI2 RX | SPI2_RX |
| CH1 | SPI2 TX | SPI2_TX |
| CH2 | Debug USART2 RX | USART2_RX |
| CH3 | Debug USART2 TX | USART2_TX |
| CH4 | Optional TMC USART1 RX | USART1_RX |
| CH5 | Optional TMC USART1 TX | USART1_TX |

All DMA IRQ priorities are set to FreeRTOS-compatible priority 5. ISR callbacks may therefore use `xSemaphoreGiveFromISR()` / stream-buffer ISR APIs.

### 4.3 SPI DMA transaction

The TMC6460 still gets one external CS pulse per 48-bit frame:

```text
MotorService
   |
   v
SPI_IF_Transfer()
   |
   +-- take SPI mutex
   +-- clear completion semaphore
   +-- critical section
   |      CSN LOW
   |      HAL_SPI_TransmitReceive_DMA()
   +-- leave critical section
   |
   +-- block on done semaphore
                |
         LPDMA1 RX/TX IRQ
                |
          HAL DMA callbacks
                |
        HAL_SPI_TxRxCpltCallback
                |
              CSN HIGH
                |
       xSemaphoreGiveFromISR(done)
```

The TMC pipelined two-frame read/write behavior is unchanged in `tmc6460_transport.c`.

### 4.4 UART DMA

Transmit uses `HAL_UART_Transmit_DMA()`.
Transactional receive uses `HAL_UART_Receive_DMA()`.
Debug command input uses `HAL_UART_ReceiveToIdle_DMA()` with a 32-byte DMA chunk. Each IDLE/full event copies received bytes to the existing FreeRTOS stream buffer and immediately rearms DMA.

The application still calls the same `UART_IF_Write()`, `UART_IF_Read()` and `UART_IF_ReadBuffered()` APIs.

## 5. Safe migration sequence

Do not migrate both peripherals on an unverified board in one diagnostic step even though v14 has both DMA switches enabled by default.

1. Archive the v13.2 IAR build, map and hex as rollback benchmark.
2. Apply only the actuator parameter changes and verify `A G V W Z` using the old IT transport.
3. Set `HW_UART_DMA_ENABLE=1`, `HW_SPI_DMA_ENABLE=0`. Verify debug RX commands and long debug TX during calibration.
4. Verify `M` shows no UART errors or dropped RX bytes.
5. Set `HW_SPI_DMA_ENABLE=1`. Verify CHIP_ID, non-zero register read, A initialization, manual shaft position, V/W/Z.
6. Run a complete five-iteration G calibration and compare endpoint spread against v13.2.
7. Run X/Y soft-end tests and confirm external CSN waveform remains one 48-bit frame per pulse.
8. Stress test repeated X/Y and watch `M`: DMA timeout/error counters must remain near zero, stream drops must remain zero, stack high-water marks must retain margin.

For rollback, either DMA switch can be set back to 0; the interface API does not change.

## 6. FreeRTOS tasks

### MotorService — priority 4, 2048 words (~8192 B stack)

Sole owner of TMC6460 register traffic. It processes the motor command queue, runs calibration synchronously, runs soft-stall synchronously, and performs normal 400 Hz position reads. This ownership rule prevents TMC SPI transaction collisions.

### DebugCommand — priority 3, 384 words (~1536 B)

Consumes the UART RX stream buffer. Converts A/B/C/V/W/Z/G/X/Y/R/P/M into application operations. Normal motor commands go into the motor command queue. During long G/X/Y operations, Z writes an abort flag instead of waiting behind the active command.

### Diagnostics — priority 1, 512 words (~2048 B)

Prints a compact status once per second. It never accesses TMC registers directly; it consumes cached `g_app_status`. It also samples runtime heap/stack data.

### Heartbeat — priority 1, 256 words (~1024 B)

Toggles the board LED once per second and contains no motor logic.

### FreeRTOS internal tasks

Idle task: minimum 128 words (~512 B). Timer service task: 128 words (~512 B), priority 2, timer queue length 10.

## 7. IPC and synchronization

### Motor command queue

`xQueueCreate(12, sizeof(app_motor_command_t))` transfers commands from DebugCommand to MotorService. It decouples console timing from motor timing and serializes all motor actions.

### SPI mutex

`xSemaphoreCreateMutex()` ensures only one logical SPI transfer can own SPI2 and external CS. Today only MotorService uses the TMC bus, but the mutex provides defensive protection and future scalability.

### SPI completion semaphore

Binary semaphore. The task starts DMA then blocks. DMA/SPI completion ISR gives the semaphore. CPU time is available to other tasks while 48 bits move.

### UART mutex

One per initialized UART context. Prevents overlapping TX or transactional RX sequences on the same USART.

### UART TX/RX completion semaphores

Binary semaphores bridge HAL DMA/IRQ completion callbacks to waiting tasks.

### Debug RX stream buffer

128-byte FreeRTOS stream buffer. DMA-to-idle produces chunks; ISR pushes the chunk to the stream; DebugCommand consumes characters one at a time. Runtime statistics count bytes received and any drops.

### Calibration/soft-stall abort flags

Volatile flags are used instead of a second TMC command queue because the long operation is already running inside MotorService. DebugCommand can request abort, while MotorService remains the only task that actually touches the motor controller.

### Critical sections

Used for short updates of shared status and for the few instructions from external CS assertion to starting SPI DMA. No long motor operation is executed with interrupts disabled.

## 8. Memory architecture

STM32C562RE project regions:

- Flash: 512 KiB.
- SRAM configured by linker: 128 KiB.
- FreeRTOS heap_4 reserve: 24 KiB (`24576` bytes). This entire array appears in linked RW/BSS RAM even when FreeRTOS has not consumed it all.

Configured stack payload taken from the FreeRTOS heap:

| Task | Words | Approx bytes |
|---|---:|---:|
| MotorService | 2048 | 8192 |
| Diagnostics | 512 | 2048 |
| DebugCommand | 384 | 1536 |
| Heartbeat | 256 | 1024 |
| Idle | 128 | 512 |
| Timer service | 128 | 512 |
| **Total stack payload** | **3456** | **13824** |

Before TCB/queue/semaphore/stream-buffer overhead, about `24576 - 13824 = 10752` bytes of the FreeRTOS heap remain for kernel objects and margin.

DMA handle objects and the 32-byte debug RX DMA chunk are static `.bss`, not FreeRTOS heap allocations.

### Runtime command M

`M` prints:

- heap total/free/min-ever-free/used/peak-used,
- high-water mark of all four application task stacks,
- motor queue free slots,
- SPI DMA transfer/timeout/error counts,
- debug UART DMA TX count, RX byte count, dropped bytes and error count.

Stack values are in FreeRTOS words. On Cortex-M33 one word is 4 bytes.

### Link-time ROM/RAM

Exact post-DMA ROM/Flash and linked RAM can only be stated after IAR links this version. The project contains:

```text
tools/analyze_iar_map.py
```

After `Rebuild All`, run:

```text
python tools/analyze_iar_map.py project/debug/List/NG_Actuator.map
```

or pass the actual map path generated by IAR. The tool extracts IAR grand totals and computes percentage against 512 KiB Flash / 128 KiB RAM.

Link-time and runtime memory answer different questions:

- `.map`: code/const/static/BSS reservation, including the full 24 KiB FreeRTOS heap array.
- `M`: actual FreeRTOS allocations and task stack margin while the system is operating.

## 9. Compact diagnostics

Periodic line example:

```text
STAT p=0 st=1 tmc=0 pos=123456 vel=0 cmd=0 drv=1 Hz=400 cal=1/0 ref=1 soft=0/0 err=0 heap=9736 stkM=1450
```

Use `M` only when memory detail is required. Use `P` for soft-stall parameters and `R` for explicit TMC diagnostic refresh. Calibration still prints meaningful state transitions and final copyable calibration defines.

## 10. Code reading order

For understanding the firmware, read in this order:

1. `hardware_config.h` — hardware and RTOS policy.
2. `main.c` — boot order only.
3. `mx_freertos_app.c` — task creation and priorities.
4. `app.c` — command routing and task behavior.
5. `actuator_profile.c` — actuator-specific limits/speeds.
6. `actuator_calibration.c` — hard-end learning state machine.
7. `actuator_reference.c` — stored stroke vs current-session anchor.
8. `actuator_soft_stall.c` — cruise/creep/contact/hold state machine.
9. `tmc6460_motor.c` — high-level TMC motor operations.
10. `tmc6460.c` — generic 32-bit register API.
11. `tmc6460_transport.c` — UART/SPI protocol adaptation and TMC SPI pipeline.
12. `spi_iface.c` / `uart_iface.c` — RTOS/DMA synchronization.
13. `bsp.c` — STM32C5 pin/peripheral/DMA/NVIC initialization.
14. `runtime_memory.c` — runtime observability.

## 11. Acceptance tests for v14

- Compile with zero warnings/errors in IAR.
- `A` reads CHIP_ID and initializes 10 Nm profile.
- A profile default/max velocity both equal 9,000,000 raw.
- `V/W/Z` remain functional.
- Manual shaft rotation changes position/velocity.
- `G` completes all configured iterations; any individual leg can legally run up to 150 s.
- `X/Y` creep begins at 98.00% and contact behavior remains safe.
- Debug UART responds while motor is running.
- `M` reports zero dropped debug bytes and no persistent DMA errors/timeouts.
- Position acquisition remains ~400 Hz.
- External CS pulse stays correct for each 48-bit TMC SPI frame.
- FreeRTOS stack-overflow hook is never reached and MotorService high-water mark retains margin.
