#ifndef ACTUATOR_SOFT_STALL_H
#define ACTUATOR_SOFT_STALL_H

#include "actuator_profile.h"
#include "actuator_reference.h"
#include "actuator_soft_stall_config.h"
#include "tmc6460_motor.h"

#include <stdint.h>

typedef enum
{
    ACTUATOR_SOFT_STALL_STATUS_OK = 0,
    ACTUATOR_SOFT_STALL_STATUS_INVALID_PARAM,
    ACTUATOR_SOFT_STALL_STATUS_NOT_INITIALIZED,
    ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED,
    ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR,
    ACTUATOR_SOFT_STALL_STATUS_TIMEOUT,
    ACTUATOR_SOFT_STALL_STATUS_ABORTED,
    ACTUATOR_SOFT_STALL_STATUS_OVERSHOOT,
    ACTUATOR_SOFT_STALL_STATUS_REFERENCE_SEARCH_FAILED
} actuator_soft_stall_status_t;

typedef enum
{
    ACTUATOR_SOFT_STALL_STAGE_IDLE = 0,
    ACTUATOR_SOFT_STALL_STAGE_REFERENCE_SEARCH,
    ACTUATOR_SOFT_STALL_STAGE_CRUISE,
    ACTUATOR_SOFT_STALL_STAGE_CREEP,
    ACTUATOR_SOFT_STALL_STAGE_HOLD
} actuator_soft_stall_stage_t;

typedef enum
{
    ACTUATOR_SOFT_STALL_EVENT_START = 0,
    ACTUATOR_SOFT_STALL_EVENT_REFERENCE_SEARCH,
    ACTUATOR_SOFT_STALL_EVENT_REFERENCE_ESTABLISHED,
    ACTUATOR_SOFT_STALL_EVENT_CRUISE,
    ACTUATOR_SOFT_STALL_EVENT_CREEP,
    ACTUATOR_SOFT_STALL_EVENT_CREEP_BOOST,
    ACTUATOR_SOFT_STALL_EVENT_SAMPLE,
    ACTUATOR_SOFT_STALL_EVENT_CONTACT,
    ACTUATOR_SOFT_STALL_EVENT_COMPLETE,
    ACTUATOR_SOFT_STALL_EVENT_ABORTED,
    ACTUATOR_SOFT_STALL_EVENT_ERROR
} actuator_soft_stall_event_t;

typedef enum
{
    ACTUATOR_SOFT_STALL_DIRECTION_CCW = -1,
    ACTUATOR_SOFT_STALL_DIRECTION_CW = 1
} actuator_soft_stall_direction_t;

typedef struct
{
    actuator_soft_stall_event_t event;
    actuator_soft_stall_status_t status;
    actuator_soft_stall_stage_t stage;
    actuator_soft_stall_direction_t direction;

    int32_t position_raw;
    int32_t velocity_raw;
    int32_t torque_raw;

    int32_t target_end_raw;
    int32_t creep_start_raw;
    int32_t distance_to_end_counts;
    int32_t commanded_velocity_raw;

    uint8_t position_stable;
    uint8_t velocity_low;
    uint8_t torque_high;
    uint8_t reference_valid;
} actuator_soft_stall_progress_t;

typedef void (*actuator_soft_stall_progress_cb_t)(
    const actuator_soft_stall_progress_t *progress,
    void *context);

typedef struct
{
    actuator_soft_stall_status_t status;
    actuator_soft_stall_direction_t direction;

    int32_t start_position_raw;
    int32_t creep_start_raw;
    int32_t contact_arm_raw;
    int32_t target_end_raw;
    int32_t final_position_raw;

    int32_t cruise_velocity_raw;
    int32_t creep_velocity_raw;
    int32_t final_creep_velocity_raw;

    uint32_t elapsed_ms;
    uint32_t tmc_retry_count;
    uint32_t creep_boost_count;

    uint8_t creep_entered;
    uint8_t contact_confirmed;
    uint8_t reference_search_used;
    uint8_t reference_established;
} actuator_soft_stall_result_t;

/* reference is mutable because a successful end contact updates the current-
 * session zero/ninety raw anchor. */
actuator_soft_stall_status_t ActuatorSoftStall_Run(
    tmc6460_motor_t *motor,
    const actuator_profile_t *profile,
    actuator_reference_t *reference,
    actuator_soft_stall_direction_t direction,
    volatile uint8_t *abort_requested,
    actuator_soft_stall_result_t *result,
    actuator_soft_stall_progress_cb_t progress_cb,
    void *progress_context);

uint32_t ActuatorSoftStall_GetTmcRetryCount(void);
tmc6460_status_t ActuatorSoftStall_GetLastTmcError(void);

#endif /* ACTUATOR_SOFT_STALL_H */
