#include "runtime_memory.h"
#include "hardware_config.h"
#include "app.h"
#include "mx_freertos_app.h"
#include "spi_iface.h"
#include "uart_iface.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stdio.h>
#include <string.h>

static uint32_t RuntimeMemory_StackFree(TaskHandle_t handle)
{
    if (handle == NULL) return 0U;
    return (uint32_t)uxTaskGetStackHighWaterMark(handle);
}

void RuntimeMemory_Get(runtime_memory_snapshot_t *s)
{
    spi_if_stats_t spi_stats;
    uart_if_stats_t uart_stats;
    uint32_t free_heap;
    uint32_t min_heap;

    if (s == NULL) return;
    memset(s, 0, sizeof(*s));

    free_heap = (uint32_t)xPortGetFreeHeapSize();
    min_heap  = (uint32_t)xPortGetMinimumEverFreeHeapSize();

    s->heap_total_bytes = HW_RTOS_HEAP_SIZE_BYTES;
    s->heap_free_bytes = free_heap;
    s->heap_min_ever_free_bytes = min_heap;
    s->heap_used_now_bytes = (HW_RTOS_HEAP_SIZE_BYTES >= free_heap) ?
                             (HW_RTOS_HEAP_SIZE_BYTES - free_heap) : 0U;
    s->heap_peak_used_bytes = (HW_RTOS_HEAP_SIZE_BYTES >= min_heap) ?
                              (HW_RTOS_HEAP_SIZE_BYTES - min_heap) : 0U;

    s->heartbeat_stack_free_words = RuntimeMemory_StackFree(app_get_heartbeat_task_handle());
    s->motor_stack_free_words = RuntimeMemory_StackFree(app_get_motor_task_handle());
    s->command_stack_free_words = RuntimeMemory_StackFree(app_get_command_task_handle());
    s->diagnostics_stack_free_words = RuntimeMemory_StackFree(app_get_diagnostics_task_handle());

    s->motor_queue_spaces = APP_GetMotorCommandQueueSpaces();
    s->motor_queue_length = HW_MOTOR_COMMAND_QUEUE_LENGTH;

    SPI_IF_GetStats(SPI_IF_PORT_TMC, &spi_stats);
    s->spi_transfers = spi_stats.transfers;
    s->spi_timeouts = spi_stats.timeouts;
    s->spi_errors = spi_stats.errors;

    UART_IF_GetStats(UART_IF_PORT_DEBUG, &uart_stats);
    s->uart_tx_transfers = uart_stats.tx_transfers;
    s->uart_rx_bytes = uart_stats.buffered_rx_bytes;
    s->uart_rx_dropped = uart_stats.buffered_rx_dropped;
    s->uart_errors = uart_stats.errors;
}

int RuntimeMemory_FormatCompact(char *buffer, size_t size,
                                const runtime_memory_snapshot_t *s)
{
    if ((buffer == NULL) || (size == 0U) || (s == NULL)) return 0;
    return snprintf(buffer, size,
                    "MEM heap=%lu/%lu minFree=%lu stk[M/C/D/H]=%lu/%lu/%lu/%lu\r\n",
                    (unsigned long)s->heap_used_now_bytes,
                    (unsigned long)s->heap_total_bytes,
                    (unsigned long)s->heap_min_ever_free_bytes,
                    (unsigned long)s->motor_stack_free_words,
                    (unsigned long)s->command_stack_free_words,
                    (unsigned long)s->diagnostics_stack_free_words,
                    (unsigned long)s->heartbeat_stack_free_words);
}

int RuntimeMemory_FormatDetailed(char *buffer, size_t size,
                                 const runtime_memory_snapshot_t *s)
{
    if ((buffer == NULL) || (size == 0U) || (s == NULL)) return 0;
    return snprintf(buffer, size,
        "MEMORY RTOS: heap total=%lu free=%lu minEverFree=%lu usedNow=%lu peakUsed=%lu\r\n"
        "STACK free words: Motor=%lu Command=%lu Diagnostics=%lu Heartbeat=%lu (x4 bytes on Cortex-M33)\r\n"
        "IPC: motorQueue free=%lu/%lu\r\n"
        "DMA I/O: SPI xfers=%lu timeout=%lu err=%lu | UART tx=%lu rxBytes=%lu drop=%lu err=%lu\r\n",
        (unsigned long)s->heap_total_bytes,
        (unsigned long)s->heap_free_bytes,
        (unsigned long)s->heap_min_ever_free_bytes,
        (unsigned long)s->heap_used_now_bytes,
        (unsigned long)s->heap_peak_used_bytes,
        (unsigned long)s->motor_stack_free_words,
        (unsigned long)s->command_stack_free_words,
        (unsigned long)s->diagnostics_stack_free_words,
        (unsigned long)s->heartbeat_stack_free_words,
        (unsigned long)s->motor_queue_spaces,
        (unsigned long)s->motor_queue_length,
        (unsigned long)s->spi_transfers,
        (unsigned long)s->spi_timeouts,
        (unsigned long)s->spi_errors,
        (unsigned long)s->uart_tx_transfers,
        (unsigned long)s->uart_rx_bytes,
        (unsigned long)s->uart_rx_dropped,
        (unsigned long)s->uart_errors);
}
