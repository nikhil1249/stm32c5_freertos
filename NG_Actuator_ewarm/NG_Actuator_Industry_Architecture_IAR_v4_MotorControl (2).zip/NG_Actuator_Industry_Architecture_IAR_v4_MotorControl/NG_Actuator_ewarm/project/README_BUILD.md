# Build and first motor test

1. Open `NG_Actuator.eww` in IAR Embedded Workbench.
2. Select the Debug configuration.
3. Project -> Rebuild All.
4. Flash the NUCLEO-C562RE.
5. Open the ST-LINK Virtual COM port at **115200, 8-N-1**.
6. Power the TMC6460/motor using the already-validated wiring and a conservative
   current limit.
7. Send `A`, `B`, or `C`. Wait for the periodic status to show `init=1` and
   `tmc=0`.
8. Send `V` for CW, `W` for CCW, and `Z` for controlled zero-speed hold.

Current verified profile mapping:

| Command | Profile | Run limit | Hold limit | Max torque/flux ceiling | Basic velocity |
|---|---:|---:|---:|---:|---:|
| A | 10 kg | 1000 | 1200 | 1200 | 1,000,000 |
| B | 20 kg | 1500 | 1500 | 2000 | 1,000,000 |
| C | 35 kg | 2500 | 2000 | 2500 | 1,000,000 |

`D`/`E` are intentionally not assigned unverified motor parameters.

The basic bring-up does not yet automatically stop at the mechanical end. Use
`Z` before reaching the end during the first test. End-stop/stall logic should be
ported only after CW/CCW/hold and position feedback are confirmed.
