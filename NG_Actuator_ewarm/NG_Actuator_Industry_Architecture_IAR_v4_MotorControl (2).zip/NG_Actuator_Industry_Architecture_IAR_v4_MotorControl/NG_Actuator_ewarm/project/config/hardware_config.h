#ifndef HARDWARE_CONFIG_H
#define HARDWARE_CONFIG_H

/*
 * NG Actuator - single board/application configuration file.
 *
 * Keep STM32C5 board selections, clocks, GPIO, UART routing and RTOS sizing
 * in this file.  Motor-controller register values and actuator profiles live
 * in their own device/application configuration files because they are not
 * STM32-specific hardware settings.
 */

/* -------------------------------------------------------------------------- */
/* System clock / FreeRTOS tick                                               */
/* -------------------------------------------------------------------------- */
#define HW_CPU_CLOCK_HZ                       144000000U
#define HW_SYSTICK_CLOCK_HZ                    18000000U
#define HW_RTOS_TICK_RATE_HZ                       1000U
#define HW_RTOS_HEAP_SIZE_BYTES                   24576U

/* 24 MHz HSE -> PSI 144 MHz -> SYSCLK/HCLK 144 MHz. */
#define HW_RCC_ENABLE_HSE                           1U
#define HW_RCC_ENABLE_PSI                           1U
#define HW_RCC_PSI_SOURCE                 HAL_RCC_PSI_SRC_HSE
#define HW_RCC_PSI_REFERENCE             HAL_RCC_PSI_REF_24MHZ
#define HW_RCC_PSI_OUTPUT                HAL_RCC_PSI_OUT_144MHZ
#define HW_RCC_SYSCLK_SOURCE             HAL_RCC_SYSCLK_SRC_PSIS
#define HW_RCC_HCLK_PRESCALER            HAL_RCC_HCLK_PRESCALER1
#define HW_RCC_PCLK1_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_RCC_PCLK2_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_RCC_PCLK3_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_FLASH_LATENCY                 HAL_FLASH_ITF_LATENCY_4
#define HW_FLASH_PROGRAM_DELAY           HAL_FLASH_ITF_PROGRAM_DELAY_2

/* -------------------------------------------------------------------------- */
/* On-board heartbeat LED                                                    */
/* -------------------------------------------------------------------------- */
#define HW_LED_PORT                            HAL_GPIOA
#define HW_LED_PIN                             HAL_GPIO_PIN_5
#define HW_LED_INIT_STATE                      HAL_GPIO_PIN_RESET
#define HW_LED_PERIOD_MS                       1000U

/* -------------------------------------------------------------------------- */
/* TMC6460 UART - dedicated motor-controller link                             */
/* USART1: PB15=TX, PB14=RX on NUCLEO-C562RE.                                 */
/* -------------------------------------------------------------------------- */
#define HW_TMC_UART_INSTANCE                   HAL_UART1
#define HW_TMC_UART_BAUDRATE                   115200U
#define HW_TMC_UART_TX_PORT                    HAL_GPIOB
#define HW_TMC_UART_TX_PIN                     HAL_GPIO_PIN_15
#define HW_TMC_UART_RX_PORT                    HAL_GPIOB
#define HW_TMC_UART_RX_PIN                     HAL_GPIO_PIN_14
#define HW_TMC_UART_GPIO_AF                    HAL_GPIO_AF_4
#define HW_TMC_UART_IRQn                       USART1_IRQn
#define HW_TMC_UART_IRQ_HANDLER                USART1_IRQHandler
#define HW_TMC_UART_IRQ_PRIORITY_NUM           5U
#define HW_TMC_UART_IRQ_PREEMPT_PRIORITY       ((hal_cortex_nvic_preemp_priority_t)HW_TMC_UART_IRQ_PRIORITY_NUM)
#define HW_TMC_UART_IRQ_SUB_PRIORITY           HAL_CORTEX_NVIC_SUB_PRIORITY_0
#define HW_TMC_UART_KERNEL_CLOCK_CONFIG()      HAL_RCC_USART1_SetKernelClkSource(HAL_RCC_USART1_CLK_SRC_PCLK2)
#define HW_TMC_UART_RESET()                    HAL_RCC_USART1_Reset()
#define HW_TMC_UART_DISABLE_CLOCK()            HAL_RCC_USART1_DisableClock()

/* -------------------------------------------------------------------------- */
/* Debug UART - ST-LINK VCP                                                   */
/* USART2: PA2=TX, PA3=RX on NUCLEO-C562RE.                                   */
/* -------------------------------------------------------------------------- */
#define HW_DEBUG_UART_ENABLE                   1U
#define HW_DEBUG_UART_INSTANCE                 HAL_UART2
#define HW_DEBUG_UART_BAUDRATE                 115200U
#define HW_DEBUG_UART_TX_PORT                  HAL_GPIOA
#define HW_DEBUG_UART_TX_PIN                   HAL_GPIO_PIN_2
#define HW_DEBUG_UART_RX_PORT                  HAL_GPIOA
#define HW_DEBUG_UART_RX_PIN                   HAL_GPIO_PIN_3
#define HW_DEBUG_UART_GPIO_AF                  HAL_GPIO_AF_7
#define HW_DEBUG_UART_IRQn                     USART2_IRQn
#define HW_DEBUG_UART_IRQ_HANDLER              USART2_IRQHandler
#define HW_DEBUG_UART_IRQ_PRIORITY_NUM         6U
#define HW_DEBUG_UART_IRQ_PREEMPT_PRIORITY     ((hal_cortex_nvic_preemp_priority_t)HW_DEBUG_UART_IRQ_PRIORITY_NUM)
#define HW_DEBUG_UART_IRQ_SUB_PRIORITY         HAL_CORTEX_NVIC_SUB_PRIORITY_0
#define HW_DEBUG_UART_KERNEL_CLOCK_CONFIG()    HAL_RCC_USART2_SetKernelClkSource(HAL_RCC_USART2_CLK_SRC_PCLK1)
#define HW_DEBUG_UART_RESET()                  HAL_RCC_USART2_Reset()
#define HW_DEBUG_UART_DISABLE_CLOCK()          HAL_RCC_USART2_DisableClock()

/* UART framing shared by TMC and debug links. */
#define HW_UART_WORD_LENGTH                    HAL_UART_WORD_LENGTH_8_BIT
#define HW_UART_STOP_BITS                      HAL_UART_STOP_BIT_1
#define HW_UART_PARITY                         HAL_UART_PARITY_NONE
#define HW_UART_DIRECTION                      HAL_UART_DIRECTION_TX_RX
#define HW_UART_HW_FLOW_CONTROL                HAL_UART_HW_CONTROL_NONE
#define HW_UART_OVERSAMPLING                   HAL_UART_OVERSAMPLING_16
#define HW_UART_ONE_BIT_SAMPLING               HAL_UART_ONE_BIT_SAMPLE_DISABLE
#define HW_UART_PRESCALER                      HAL_UART_PRESCALER_DIV1
#define HW_UART_GPIO_OUTPUT_TYPE               HAL_GPIO_OUTPUT_PUSHPULL
#define HW_UART_GPIO_PULL                      HAL_GPIO_PULL_NO
#define HW_UART_GPIO_SPEED                     HAL_GPIO_SPEED_FREQ_LOW

/* -------------------------------------------------------------------------- */
/* UART middleware                                                            */
/* -------------------------------------------------------------------------- */
#define HW_TMC_UART_TIMEOUT_MS                 25U
#define HW_DEBUG_UART_TIMEOUT_MS               50U
#define HW_DEBUG_RX_STREAM_SIZE                64U
#define HW_TMC_STARTUP_DELAY_MS                100U
#define HW_TMC_EXPECTED_CHIP_ID                0x36343630UL

/* -------------------------------------------------------------------------- */
/* Application / motor service                                                */
/* -------------------------------------------------------------------------- */
#define HW_MOTOR_COMMAND_QUEUE_LENGTH          12U
#define HW_DIAG_PERIOD_MS                      500U

/* The motor service intentionally has no periodic vTaskDelay while initialized.
 * A position read blocks on the USART1 completion interrupt, which yields the
 * CPU to other tasks while the bytes are on the wire.  This gives the highest
 * practical position sampling rate at 115200 baud without busy-spinning. */

/* -------------------------------------------------------------------------- */
/* FreeRTOS application tasks                                                 */
/* Stack values are FreeRTOS StackType_t entries, not bytes.                  */
/* -------------------------------------------------------------------------- */
#define HW_TASK_HEARTBEAT_NAME                 "Heartbeat"
#define HW_TASK_HEARTBEAT_STACK                256U
#define HW_TASK_HEARTBEAT_PRIORITY             1U

#define HW_TASK_MOTOR_NAME                     "MotorService"
#define HW_TASK_MOTOR_STACK                    512U
#define HW_TASK_MOTOR_PRIORITY                 4U

#define HW_TASK_COMMAND_NAME                   "DebugCommand"
#define HW_TASK_COMMAND_STACK                  384U
#define HW_TASK_COMMAND_PRIORITY               3U

#define HW_TASK_DIAG_NAME                      "Diagnostics"
#define HW_TASK_DIAG_STACK                     512U
#define HW_TASK_DIAG_PRIORITY                  1U

/* -------------------------------------------------------------------------- */
/* Compile-time sanity checks                                                 */
/* -------------------------------------------------------------------------- */
#if (HW_TMC_UART_IRQ_PRIORITY_NUM < 5U)
#error "TMC UART IRQ priority must be FreeRTOS-safe (numeric priority >= 5)."
#endif

#if (HW_DEBUG_UART_ENABLE != 0U) && (HW_DEBUG_UART_IRQ_PRIORITY_NUM < 5U)
#error "Debug UART IRQ priority must be FreeRTOS-safe (numeric priority >= 5)."
#endif

#endif /* HARDWARE_CONFIG_H */
