#include "actuator_calibration.h"
#include "hardware_config.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stddef.h>
#include <string.h>

static volatile tmc6460_status_t s_calibration_last_tmc_error = TMC6460_OK;
static volatile uint32_t s_calibration_tmc_retry_count = 0U;

static void ActuatorCalibration_RecordTmcFailure(tmc6460_status_t status)
{
    s_calibration_last_tmc_error = status;
    s_calibration_tmc_retry_count++;
}

static int32_t ActuatorCalibration_Abs32(int32_t value)
{
    if (value >= 0)
    {
        return value;
    }

    if (value == (int32_t)0x80000000UL)
    {
        return 0x7FFFFFFF;
    }

    return -value;
}

static uint32_t ActuatorCalibration_AbsDiff32(int32_t a, int32_t b)
{
    int64_t diff = (int64_t)a - (int64_t)b;

    if (diff < 0)
    {
        diff = -diff;
    }

    if (diff > 0xFFFFFFFFLL)
    {
        return 0xFFFFFFFFUL;
    }

    return (uint32_t)diff;
}

static int32_t ActuatorCalibration_GetVelocity(actuator_type_t type)
{
    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            return (int32_t)ACTUATOR_CAL_10KG_VELOCITY_RAW;

        case ACTUATOR_TYPE_20KG:
            return (int32_t)ACTUATOR_CAL_20KG_VELOCITY_RAW;

        case ACTUATOR_TYPE_35KG:
            return (int32_t)ACTUATOR_CAL_35KG_VELOCITY_RAW;

        default:
            return 0;
    }
}

static int32_t ActuatorCalibration_GetTorqueThreshold(actuator_type_t type)
{
    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            return (int32_t)ACTUATOR_CAL_10KG_TORQUE_STALL_RAW;

        case ACTUATOR_TYPE_20KG:
            return (int32_t)ACTUATOR_CAL_20KG_TORQUE_STALL_RAW;

        case ACTUATOR_TYPE_35KG:
            return (int32_t)ACTUATOR_CAL_35KG_TORQUE_STALL_RAW;

        default:
            return 0;
    }
}

/* Calibration lasts much longer than a normal V/W test.  Do not terminate the
 * entire calibration because of one transient TMC transport failure.  The
 * v10.4 SPI transport remains unchanged; these wrappers simply retry a failed
 * operation after CS/SPI has already been released by the transport layer. */
static tmc6460_status_t ActuatorCalibration_ReadMotionSampleRetry(
    tmc6460_motor_t *motor,
    tmc6460_motion_sample_t *sample)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_CALIBRATION_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorReadMotionSample(motor, sample);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorCalibration_RecordTmcFailure(status);

        if (attempt < ACTUATOR_CALIBRATION_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorCalibration_ReadPositionRetry(
    tmc6460_motor_t *motor,
    int32_t *position_raw)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_CALIBRATION_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorReadPosition(motor, position_raw);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorCalibration_RecordTmcFailure(status);

        if (attempt < ACTUATOR_CALIBRATION_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorCalibration_SetVelocityRetry(
    tmc6460_motor_t *motor,
    int32_t velocity_raw)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_CALIBRATION_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorSetVelocity(motor, velocity_raw);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorCalibration_RecordTmcFailure(status);

        if (attempt < ACTUATOR_CALIBRATION_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorCalibration_StopHoldRetry(
    tmc6460_motor_t *motor)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_CALIBRATION_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorStopHold(motor);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorCalibration_RecordTmcFailure(status);

        if (attempt < ACTUATOR_CALIBRATION_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static void ActuatorCalibration_Notify(
    actuator_calibration_progress_cb_t cb,
    void *context,
    actuator_calibration_event_t event,
    uint32_t iteration,
    const tmc6460_motion_sample_t *sample,
    actuator_calibration_status_t status)
{
    actuator_calibration_progress_t progress;

    if (cb == NULL)
    {
        return;
    }

    memset(&progress, 0, sizeof(progress));
    progress.event = event;
    progress.iteration = iteration;
    progress.status = status;

    if (sample != NULL)
    {
        progress.position_raw = sample->position_raw;
        progress.velocity_raw = sample->velocity_raw;
        progress.torque_raw = sample->torque_raw;
    }

    cb(&progress, context);
}

static int32_t ActuatorCalibration_Median(const int32_t *values, uint32_t count)
{
    int32_t sorted[ACTUATOR_CALIBRATION_ITERATION_COUNT];
    uint32_t i;
    uint32_t j;
    int32_t temp;

    if ((values == NULL) || (count == 0U) ||
        (count > ACTUATOR_CALIBRATION_ITERATION_COUNT))
    {
        return 0;
    }

    for (i = 0U; i < count; i++)
    {
        sorted[i] = values[i];
    }

    for (i = 1U; i < count; i++)
    {
        temp = sorted[i];
        j = i;

        while ((j > 0U) && (sorted[j - 1U] > temp))
        {
            sorted[j] = sorted[j - 1U];
            j--;
        }

        sorted[j] = temp;
    }

    if ((count & 1U) != 0U)
    {
        return sorted[count / 2U];
    }

    return (int32_t)(((int64_t)sorted[(count / 2U) - 1U] +
                      (int64_t)sorted[count / 2U]) / 2LL);
}

static int32_t ActuatorCalibration_Average(const int32_t *values, uint32_t count)
{
    int64_t sum = 0LL;
    uint32_t i;

    if ((values == NULL) || (count == 0U))
    {
        return 0;
    }

    for (i = 0U; i < count; i++)
    {
        sum += (int64_t)values[i];
    }

    return (int32_t)(sum / (int64_t)count);
}

static uint32_t ActuatorCalibration_Spread(const int32_t *values, uint32_t count)
{
    int32_t minimum;
    int32_t maximum;
    uint32_t i;

    if ((values == NULL) || (count == 0U))
    {
        return 0U;
    }

    minimum = values[0];
    maximum = values[0];

    for (i = 1U; i < count; i++)
    {
        if (values[i] < minimum)
        {
            minimum = values[i];
        }

        if (values[i] > maximum)
        {
            maximum = values[i];
        }
    }

    return ActuatorCalibration_AbsDiff32(maximum, minimum);
}

static actuator_calibration_status_t ActuatorCalibration_CaptureEndpoint(
    tmc6460_motor_t *motor,
    volatile uint8_t *abort_requested,
    int32_t *endpoint_raw,
    actuator_calibration_progress_cb_t cb,
    void *context,
    uint32_t iteration)
{
    int64_t position_sum = 0LL;
    uint32_t i;
    int32_t position_raw = 0;
    tmc6460_status_t tmc_status;
    TickType_t sample_ticks;

    if ((motor == NULL) || (endpoint_raw == NULL))
    {
        return ACTUATOR_CAL_STATUS_INVALID_PARAM;
    }

    vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_SETTLE_TIME_MS));

    sample_ticks = pdMS_TO_TICKS(1000U / ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ);
    if (sample_ticks == (TickType_t)0U)
    {
        sample_ticks = (TickType_t)1U;
    }

    for (i = 0U; i < ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES; i++)
    {
        if ((abort_requested != NULL) && (*abort_requested != 0U))
        {
            return ACTUATOR_CAL_STATUS_ABORTED;
        }

        tmc_status = ActuatorCalibration_ReadPositionRetry(motor, &position_raw);
        if (tmc_status != TMC6460_OK)
        {
            return ACTUATOR_CAL_STATUS_TMC_ERROR;
        }

        position_sum += (int64_t)position_raw;
        vTaskDelay(sample_ticks);
    }

    *endpoint_raw = (int32_t)(position_sum /
        (int64_t)ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES);

    (void)cb;
    (void)context;
    (void)iteration;

    return ACTUATOR_CAL_STATUS_OK;
}

static actuator_calibration_status_t ActuatorCalibration_MoveToEnd(
    tmc6460_motor_t *motor,
    actuator_type_t actuator_type,
    int32_t commanded_velocity,
    volatile uint8_t *abort_requested,
    int32_t *endpoint_raw,
    actuator_calibration_progress_cb_t cb,
    void *context,
    uint32_t iteration)
{
    tmc6460_motion_sample_t sample;
    tmc6460_status_t tmc_status;
    actuator_calibration_status_t cal_status;
    TickType_t start_tick;
    TickType_t last_wake;
    TickType_t sample_ticks;
    TickType_t blanking_ticks;
    TickType_t max_leg_ticks;
    uint32_t stable_count = 0U;
    uint32_t position_only_count = 0U;
    uint32_t stable_required;
    uint32_t position_only_required;
    uint32_t delta_counts;
    int32_t last_position = 0;
    int32_t velocity_stop_threshold;
    int32_t torque_threshold;
    uint8_t have_previous = 0U;
    uint8_t position_stable;
    uint8_t velocity_low;
    uint8_t torque_high;

    if ((motor == NULL) || (endpoint_raw == NULL) || (commanded_velocity == 0))
    {
        return ACTUATOR_CAL_STATUS_INVALID_PARAM;
    }

    sample_ticks = pdMS_TO_TICKS(1000U / ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ);
    if (sample_ticks == (TickType_t)0U)
    {
        sample_ticks = (TickType_t)1U;
    }

    blanking_ticks = pdMS_TO_TICKS(ACTUATOR_CALIBRATION_STARTUP_BLANKING_MS);
    max_leg_ticks = pdMS_TO_TICKS(ACTUATOR_CALIBRATION_MAX_LEG_TIME_MS);

    stable_required =
        ((ACTUATOR_CALIBRATION_STALL_CONFIRM_MS *
          ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ) + 999U) / 1000U;
    if (stable_required == 0U)
    {
        stable_required = 1U;
    }

    position_only_required =
        ((ACTUATOR_CALIBRATION_POSITION_ONLY_CONFIRM_MS *
          ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ) + 999U) / 1000U;
    if (position_only_required == 0U)
    {
        position_only_required = 1U;
    }

    velocity_stop_threshold =
        (ActuatorCalibration_Abs32(commanded_velocity) *
         (int32_t)ACTUATOR_CALIBRATION_VELOCITY_STOP_PERCENT) / 100;
    if (velocity_stop_threshold < ACTUATOR_CALIBRATION_VELOCITY_STOP_MIN_RAW)
    {
        velocity_stop_threshold = ACTUATOR_CALIBRATION_VELOCITY_STOP_MIN_RAW;
    }

    torque_threshold = ActuatorCalibration_GetTorqueThreshold(actuator_type);

    tmc_status = ActuatorCalibration_SetVelocityRetry(motor, commanded_velocity);
    if (tmc_status != TMC6460_OK)
    {
        return ACTUATOR_CAL_STATUS_TMC_ERROR;
    }

    start_tick = xTaskGetTickCount();
    last_wake = start_tick;
    memset(&sample, 0, sizeof(sample));

    for (;;)
    {
        if ((abort_requested != NULL) && (*abort_requested != 0U))
        {
            (void)ActuatorCalibration_StopHoldRetry(motor);
            return ACTUATOR_CAL_STATUS_ABORTED;
        }

        tmc_status = ActuatorCalibration_ReadMotionSampleRetry(motor, &sample);
        if (tmc_status != TMC6460_OK)
        {
            (void)ActuatorCalibration_StopHoldRetry(motor);
            return ACTUATOR_CAL_STATUS_TMC_ERROR;
        }

        ActuatorCalibration_Notify(cb,
                                   context,
                                   ACTUATOR_CAL_EVENT_SAMPLE,
                                   iteration,
                                   &sample,
                                   ACTUATOR_CAL_STATUS_OK);

        if (have_previous != 0U)
        {
            delta_counts =
                ActuatorCalibration_AbsDiff32(sample.position_raw,
                                              last_position);

            position_stable =
                (delta_counts <=
                 (uint32_t)ACTUATOR_CALIBRATION_POSITION_DELTA_COUNTS) ? 1U : 0U;

            velocity_low =
                (ActuatorCalibration_Abs32(sample.velocity_raw) <=
                 velocity_stop_threshold) ? 1U : 0U;

            torque_high = 0U;
            if (torque_threshold > 0)
            {
                torque_high =
                    (ActuatorCalibration_Abs32(sample.torque_raw) >=
                     torque_threshold) ? 1U : 0U;
            }

            if ((xTaskGetTickCount() - start_tick) >= blanking_ticks)
            {
                if (position_stable != 0U)
                {
                    position_only_count++;
                }
                else
                {
                    position_only_count = 0U;
                }

                if ((position_stable != 0U) &&
                    ((velocity_low != 0U) || (torque_high != 0U)))
                {
                    stable_count++;
                }
                else
                {
                    stable_count = 0U;
                }
            }
        }

        last_position = sample.position_raw;
        have_previous = 1U;

        if ((stable_count >= stable_required) ||
            (position_only_count >= position_only_required))
        {
            tmc_status = ActuatorCalibration_StopHoldRetry(motor);
            if (tmc_status != TMC6460_OK)
            {
                return ACTUATOR_CAL_STATUS_TMC_ERROR;
            }

            cal_status = ActuatorCalibration_CaptureEndpoint(
                motor,
                abort_requested,
                endpoint_raw,
                cb,
                context,
                iteration);

            return cal_status;
        }

        if ((xTaskGetTickCount() - start_tick) >= max_leg_ticks)
        {
            (void)ActuatorCalibration_StopHoldRetry(motor);
            return ACTUATOR_CAL_STATUS_TIMEOUT;
        }

        vTaskDelayUntil(&last_wake, sample_ticks);
    }
}

static actuator_calibration_status_t ActuatorCalibration_Analyze(
    actuator_calibration_result_t *result)
{
    uint32_t stroke_samples[ACTUATOR_CALIBRATION_ITERATION_COUNT];
    uint64_t stroke_sum = 0ULL;
    uint32_t stroke_min;
    uint32_t stroke_max;
    uint32_t max_allowed_spread;
    uint32_t i;
    int64_t signed_stroke;

    if (result == NULL)
    {
        return ACTUATOR_CAL_STATUS_INVALID_PARAM;
    }

    result->zero_average_raw =
        ActuatorCalibration_Average(result->zero_samples,
                                    ACTUATOR_CALIBRATION_ITERATION_COUNT);
    result->ninety_average_raw =
        ActuatorCalibration_Average(result->ninety_samples,
                                    ACTUATOR_CALIBRATION_ITERATION_COUNT);

    result->zero_raw =
        ActuatorCalibration_Median(result->zero_samples,
                                   ACTUATOR_CALIBRATION_ITERATION_COUNT);
    result->ninety_raw =
        ActuatorCalibration_Median(result->ninety_samples,
                                   ACTUATOR_CALIBRATION_ITERATION_COUNT);

    result->zero_spread_counts =
        ActuatorCalibration_Spread(result->zero_samples,
                                   ACTUATOR_CALIBRATION_ITERATION_COUNT);
    result->ninety_spread_counts =
        ActuatorCalibration_Spread(result->ninety_samples,
                                   ACTUATOR_CALIBRATION_ITERATION_COUNT);

    signed_stroke = (int64_t)result->ninety_raw - (int64_t)result->zero_raw;
    if (signed_stroke > 0LL)
    {
        result->direction_sign = 1;
        result->stroke_counts = (uint32_t)signed_stroke;
    }
    else if (signed_stroke < 0LL)
    {
        result->direction_sign = -1;
        result->stroke_counts = (uint32_t)(-signed_stroke);
    }
    else
    {
        return ACTUATOR_CAL_STATUS_UNSTABLE;
    }

    result->stroke_signed_counts = (int32_t)signed_stroke;

    if (result->stroke_counts < ACTUATOR_CALIBRATION_MIN_STROKE_COUNTS)
    {
        return ACTUATOR_CAL_STATUS_UNSTABLE;
    }

    for (i = 0U; i < ACTUATOR_CALIBRATION_ITERATION_COUNT; i++)
    {
        stroke_samples[i] =
            ActuatorCalibration_AbsDiff32(result->ninety_samples[i],
                                          result->zero_samples[i]);
        stroke_sum += (uint64_t)stroke_samples[i];
    }

    stroke_min = stroke_samples[0];
    stroke_max = stroke_samples[0];
    for (i = 1U; i < ACTUATOR_CALIBRATION_ITERATION_COUNT; i++)
    {
        if (stroke_samples[i] < stroke_min)
        {
            stroke_min = stroke_samples[i];
        }
        if (stroke_samples[i] > stroke_max)
        {
            stroke_max = stroke_samples[i];
        }
    }

    result->stroke_min_counts = stroke_min;
    result->stroke_max_counts = stroke_max;
    result->stroke_average_counts =
        (uint32_t)(stroke_sum /
                   (uint64_t)ACTUATOR_CALIBRATION_ITERATION_COUNT);

    max_allowed_spread =
        (result->stroke_counts *
         ACTUATOR_CALIBRATION_MAX_SPREAD_PERCENT) / 100U;
    if (max_allowed_spread < ACTUATOR_CALIBRATION_MIN_ALLOWED_SPREAD)
    {
        max_allowed_spread = ACTUATOR_CALIBRATION_MIN_ALLOWED_SPREAD;
    }

    if ((result->zero_spread_counts > max_allowed_spread) ||
        (result->ninety_spread_counts > max_allowed_spread) ||
        ((stroke_max - stroke_min) > max_allowed_spread))
    {
        return ACTUATOR_CAL_STATUS_UNSTABLE;
    }

    result->valid = 1U;
    return ACTUATOR_CAL_STATUS_OK;
}

actuator_calibration_status_t ActuatorCalibration_Run(
    tmc6460_motor_t *motor,
    const actuator_profile_t *profile,
    volatile uint8_t *abort_requested,
    actuator_calibration_result_t *result,
    actuator_calibration_progress_cb_t progress_cb,
    void *progress_context)
{
    actuator_calibration_status_t status;
    tmc6460_motion_sample_t event_sample;
    int32_t calibration_velocity;
    int32_t zero_velocity;
    int32_t ninety_velocity;
    int32_t home_zero_raw = 0;
    uint32_t i;

    if ((motor == NULL) || (profile == NULL) || (result == NULL))
    {
        return ACTUATOR_CAL_STATUS_INVALID_PARAM;
    }

    if (motor->initialized == 0U)
    {
        return ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
    }

    calibration_velocity = ActuatorCalibration_GetVelocity(profile->type);
    if (calibration_velocity <= 0)
    {
        return ACTUATOR_CAL_STATUS_INVALID_PARAM;
    }

    s_calibration_last_tmc_error = TMC6460_OK;
    s_calibration_tmc_retry_count = 0U;

    memset(result, 0, sizeof(*result));
    result->actuator_type = profile->type;

    if (abort_requested != NULL)
    {
        *abort_requested = 0U;
    }

    memset(&event_sample, 0, sizeof(event_sample));
    ActuatorCalibration_Notify(progress_cb,
                               progress_context,
                               ACTUATOR_CAL_EVENT_START,
                               0U,
                               NULL,
                               ACTUATOR_CAL_STATUS_OK);

    ninety_velocity = calibration_velocity *
        (int32_t)ACTUATOR_CALIBRATION_ZERO_TO_90_SIGN;
    zero_velocity = -ninety_velocity;

    /* Establish physical 0 degrees first. This homing pass is deliberately not
     * included in the N statistical samples. */
    ActuatorCalibration_Notify(progress_cb,
                               progress_context,
                               ACTUATOR_CAL_EVENT_HOMING_ZERO,
                               0U,
                               NULL,
                               ACTUATOR_CAL_STATUS_OK);

    status = ActuatorCalibration_MoveToEnd(motor,
                                           profile->type,
                                           zero_velocity,
                                           abort_requested,
                                           &home_zero_raw,
                                           progress_cb,
                                           progress_context,
                                           0U);
    if (status != ACTUATOR_CAL_STATUS_OK)
    {
        goto calibration_failed;
    }

    event_sample.position_raw = home_zero_raw;
    ActuatorCalibration_Notify(progress_cb,
                               progress_context,
                               ACTUATOR_CAL_EVENT_ZERO_FOUND,
                               0U,
                               &event_sample,
                               ACTUATOR_CAL_STATUS_OK);

    vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_INTER_LEG_DELAY_MS));

    for (i = 0U; i < ACTUATOR_CALIBRATION_ITERATION_COUNT; i++)
    {
        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_MOVE_TO_90,
                                   i + 1U,
                                   NULL,
                                   ACTUATOR_CAL_STATUS_OK);

        status = ActuatorCalibration_MoveToEnd(motor,
                                               profile->type,
                                               ninety_velocity,
                                               abort_requested,
                                               &result->ninety_samples[i],
                                               progress_cb,
                                               progress_context,
                                               i + 1U);
        if (status != ACTUATOR_CAL_STATUS_OK)
        {
            goto calibration_failed;
        }

        event_sample.position_raw = result->ninety_samples[i];
        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_NINETY_FOUND,
                                   i + 1U,
                                   &event_sample,
                                   ACTUATOR_CAL_STATUS_OK);

        vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_INTER_LEG_DELAY_MS));

        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_MOVE_TO_ZERO,
                                   i + 1U,
                                   NULL,
                                   ACTUATOR_CAL_STATUS_OK);

        status = ActuatorCalibration_MoveToEnd(motor,
                                               profile->type,
                                               zero_velocity,
                                               abort_requested,
                                               &result->zero_samples[i],
                                               progress_cb,
                                               progress_context,
                                               i + 1U);
        if (status != ACTUATOR_CAL_STATUS_OK)
        {
            goto calibration_failed;
        }

        event_sample.position_raw = result->zero_samples[i];
        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_ZERO_FOUND,
                                   i + 1U,
                                   &event_sample,
                                   ACTUATOR_CAL_STATUS_OK);

        vTaskDelay(pdMS_TO_TICKS(ACTUATOR_CALIBRATION_INTER_LEG_DELAY_MS));
    }

    ActuatorCalibration_Notify(progress_cb,
                               progress_context,
                               ACTUATOR_CAL_EVENT_ANALYZE,
                               ACTUATOR_CALIBRATION_ITERATION_COUNT,
                               NULL,
                               ACTUATOR_CAL_STATUS_OK);

    status = ActuatorCalibration_Analyze(result);
    if (status != ACTUATOR_CAL_STATUS_OK)
    {
        goto calibration_failed;
    }

    ActuatorCalibration_Notify(progress_cb,
                               progress_context,
                               ACTUATOR_CAL_EVENT_COMPLETE,
                               ACTUATOR_CALIBRATION_ITERATION_COUNT,
                               NULL,
                               ACTUATOR_CAL_STATUS_OK);

    return ACTUATOR_CAL_STATUS_OK;

calibration_failed:
    (void)ActuatorCalibration_StopHoldRetry(motor);

    if (status == ACTUATOR_CAL_STATUS_ABORTED)
    {
        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_ABORTED,
                                   0U,
                                   NULL,
                                   status);
    }
    else
    {
        ActuatorCalibration_Notify(progress_cb,
                                   progress_context,
                                   ACTUATOR_CAL_EVENT_ERROR,
                                   0U,
                                   NULL,
                                   status);
    }

    return status;
}

tmc6460_status_t ActuatorCalibration_GetLastTmcError(void)
{
    return s_calibration_last_tmc_error;
}

uint32_t ActuatorCalibration_GetTmcRetryCount(void)
{
    return s_calibration_tmc_retry_count;
}

int32_t ActuatorCalibration_PositionToDegX100(
    const actuator_calibration_result_t *result,
    int32_t position_raw)
{
    int64_t numerator;

    if ((result == NULL) || (result->valid == 0U) ||
        (result->stroke_signed_counts == 0))
    {
        return 0;
    }

    numerator = ((int64_t)position_raw - (int64_t)result->zero_raw) * 9000LL;
    return (int32_t)(numerator / (int64_t)result->stroke_signed_counts);
}
