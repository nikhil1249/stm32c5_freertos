#include "app.h"
#include "bsp.h"
#include "hardware_config.h"
#include "tmc6460_motor.h"
#include "uart_iface.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#include <stdio.h>
#include <string.h>

#define APP_FEEDBACK_REFRESH_POSITION_SAMPLES    256U

/* Return the next RTOS period for a requested sample rate that is not an
 * integer divisor of the RTOS tick.  At 1000 Hz tick / 400 Hz sampling this
 * produces 2,3,2,3,... ticks, i.e. 2.5 ms average. */
static TickType_t APP_NextPositionPeriodTicks(uint32_t *phase)
{
    uint32_t total;
    TickType_t ticks;

    if (phase == NULL)
    {
        return (TickType_t)1U;
    }

    total = *phase + HW_RTOS_TICK_RATE_HZ;
    ticks = (TickType_t)(total / HW_TMC_POSITION_SAMPLE_RATE_HZ);
    *phase = total % HW_TMC_POSITION_SAMPLE_RATE_HZ;

    if (ticks == (TickType_t)0U)
    {
        ticks = (TickType_t)1U;
    }

    return ticks;
}

typedef enum
{
    APP_CMD_SELECT_PROFILE = 0,
    APP_CMD_RUN_CW,
    APP_CMD_RUN_CCW,
    APP_CMD_STOP_HOLD,
    APP_CMD_REFRESH_DIAGNOSTICS
} app_command_type_t;

typedef struct
{
    app_command_type_t type;
    actuator_type_t actuator_type;
} app_motor_command_t;

static tmc6460_t s_tmc_device;
static tmc6460_motor_t s_motor;
static QueueHandle_t s_motor_command_queue;

volatile app_status_t g_app_status = { 0 };

static void APP_DebugWrite(const char *text)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    if (text != NULL)
    {
        (void)UART_IF_Write(UART_IF_PORT_DEBUG,
                            (const uint8_t *)text,
                            (uint32_t)strlen(text),
                            HW_DEBUG_UART_TIMEOUT_MS);
    }
#else
    (void)text;
#endif
}

static void APP_SetCommandResult(tmc6460_status_t status,
                                 app_motor_state_t success_state,
                                 int32_t commanded_velocity)
{
    taskENTER_CRITICAL();
    g_app_status.tmc_status = status;
    g_app_status.command_count++;

    if (status == TMC6460_OK)
    {
        g_app_status.motor_state = success_state;
        g_app_status.commanded_velocity_raw = commanded_velocity;
    }
    else
    {
        g_app_status.motor_state = APP_MOTOR_STATE_ERROR;
        g_app_status.command_error_count++;
    }
    taskEXIT_CRITICAL();
}

static tmc6460_status_t APP_RefreshTmcFeedback(void)
{
    tmc6460_feedback_t feedback;
    tmc6460_status_t status;

    memset(&feedback, 0, sizeof(feedback));
    status = TMC6460_MotorReadFeedback(&s_motor, &feedback);

    taskENTER_CRITICAL();
    g_app_status.tmc_status = status;
    if (status == TMC6460_OK)
    {
        g_app_status.chip_status_flags = feedback.chip_status_flags;
        g_app_status.chip_events = feedback.chip_events;
        g_app_status.gate_driver_config = feedback.gate_driver_config;
        g_app_status.motor_motion_config = feedback.motor_motion_config;
        g_app_status.feedback_output_config = feedback.feedback_output_config;
        g_app_status.chip_inputs_raw = feedback.chip_inputs_raw;
        g_app_status.hall_raw = feedback.hall_raw;
        g_app_status.hall_logic = feedback.hall_logic;
        g_app_status.hall_count = feedback.hall_count;
        g_app_status.hall_events = feedback.hall_events;
        g_app_status.feedback_ch_b_raw = feedback.feedback_ch_b_raw;
        g_app_status.phi_e_raw = feedback.phi_e_raw;
        g_app_status.velocity_target_readback_raw = feedback.velocity_target_raw;
        g_app_status.velocity_actual_raw = feedback.velocity_actual_raw;
        g_app_status.position_raw = feedback.position_actual_raw;
        g_app_status.torque_actual_raw = feedback.torque_actual_raw;
        g_app_status.flux_actual_raw = feedback.flux_actual_raw;
    }
    else
    {
        g_app_status.diagnostic_error_count++;
    }
    taskEXIT_CRITICAL();

    return status;
}

static void APP_ProcessMotorCommand(const app_motor_command_t *command)
{
    const actuator_profile_t *profile;
    tmc6460_status_t status;
    uint32_t chip_id = 0U;

    if (command == NULL)
    {
        return;
    }

    switch (command->type)
    {
        case APP_CMD_SELECT_PROFILE:
            profile = ActuatorProfile_Get(command->actuator_type);
            if (profile == NULL)
            {
                APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                     APP_MOTOR_STATE_ERROR,
                                     0);
                break;
            }

            if (s_motor.initialized != 0U)
            {
                (void)TMC6460_MotorStopHold(&s_motor);
            }

            status = TMC6460_MotorConfigure(&s_motor,
                                            &profile->motor,
                                            HW_TMC_EXPECTED_CHIP_ID,
                                            &chip_id);

            taskENTER_CRITICAL();
            g_app_status.tmc_chip_id = chip_id;
            g_app_status.tmc_status = status;
            g_app_status.actuator_type = command->actuator_type;
            g_app_status.actuator_initialized =
                (status == TMC6460_OK) ? 1U : 0U;
            g_app_status.motor_state =
                (status == TMC6460_OK) ? APP_MOTOR_STATE_HOLD :
                                         APP_MOTOR_STATE_ERROR;
            g_app_status.commanded_velocity_raw = 0;
            g_app_status.command_count++;
            if (status != TMC6460_OK)
            {
                g_app_status.command_error_count++;
            }
            taskEXIT_CRITICAL();

            /* Even when configuration fails, read a snapshot so the debug
             * terminal shows Hall state / driver state / status flags. */
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_RUN_CW:
            status = TMC6460_MotorRunCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CW,
                                 (status == TMC6460_OK) ?
                                     s_motor.commanded_velocity_raw : 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_RUN_CCW:
            status = TMC6460_MotorRunCCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CCW,
                                 (status == TMC6460_OK) ?
                                     s_motor.commanded_velocity_raw : 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_STOP_HOLD:
            status = TMC6460_MotorStopHold(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_HOLD,
                                 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_REFRESH_DIAGNOSTICS:
            status = APP_RefreshTmcFeedback();
            taskENTER_CRITICAL();
            g_app_status.command_count++;
            if (status != TMC6460_OK)
            {
                g_app_status.command_error_count++;
            }
            taskEXIT_CRITICAL();
            break;

        default:
            APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                 APP_MOTOR_STATE_ERROR,
                                 0);
            break;
    }
}

static BaseType_t APP_QueueCommand(app_command_type_t type,
                                   actuator_type_t actuator_type)
{
    app_motor_command_t command;

    command.type = type;
    command.actuator_type = actuator_type;

    return xQueueSend(s_motor_command_queue, &command, pdMS_TO_TICKS(20U));
}

int32_t APP_Init(void)
{
    g_app_status.tmc_status = TMC6460_ERROR;
    g_app_status.actuator_type = ACTUATOR_TYPE_10KG;
    g_app_status.motor_state = APP_MOTOR_STATE_NOT_INITIALIZED;

    /* Transport-independent device context.  UART/SPI selection is handled
     * by tmc6460_transport.c using hardware_config.h. */
    TMC6460_Init(&s_tmc_device,
                 HW_TMC_COMM_TIMEOUT_MS);

    TMC6460_MotorInitContext(&s_motor, &s_tmc_device);

    s_motor_command_queue = xQueueCreate(HW_MOTOR_COMMAND_QUEUE_LENGTH,
                                          sizeof(app_motor_command_t));
    if (s_motor_command_queue == NULL)
    {
        return -1;
    }

    return 0;
}

void APP_HeartbeatTask(void)
{
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        BSP_LED_Toggle();
        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_LED_PERIOD_MS));
    }
}

void APP_MotorServiceTask(void)
{
    app_motor_command_t command;
    tmc6460_status_t status;
    int32_t position_raw;
    uint32_t feedback_divider = 0U;
    uint32_t sample_phase = 0U;
    TickType_t last_sample_wake;
    TickType_t sample_period_ticks;

    vTaskDelay(pdMS_TO_TICKS(HW_TMC_STARTUP_DELAY_MS));
    last_sample_wake = xTaskGetTickCount();

    for (;;)
    {
        /* Single-owner rule: only MotorServiceTask accesses the TMC6460
         * transport. Process all queued commands before the next sample. */
        while (xQueueReceive(s_motor_command_queue,
                             &command,
                             (TickType_t)0U) == pdPASS)
        {
            APP_ProcessMotorCommand(&command);

            /* A configuration or motion command can take several milliseconds.
             * Restart the periodic sampling phase so vTaskDelayUntil() never
             * tries to catch up with a stale schedule. */
            last_sample_wake = xTaskGetTickCount();
            sample_phase = 0U;
        }

        if (s_motor.initialized != 0U)
        {
            position_raw = 0;
            status = TMC6460_MotorReadPosition(&s_motor, &position_raw);

            taskENTER_CRITICAL();
            g_app_status.tmc_status = status;
            if (status == TMC6460_OK)
            {
                g_app_status.position_raw = position_raw;
                g_app_status.position_sample_count++;
            }
            else
            {
                g_app_status.position_error_count++;
            }
            taskEXIT_CRITICAL();

            if (status == TMC6460_OK)
            {
                feedback_divider++;
                if (feedback_divider >= APP_FEEDBACK_REFRESH_POSITION_SAMPLES)
                {
                    feedback_divider = 0U;
                    (void)APP_RefreshTmcFeedback();
                }
            }

            /* CRITICAL FIX: MotorService has priority 4.  Without an explicit
             * periodic block, fast SPI transfers can keep this task ready almost
             * continuously and starve the lower-priority DebugCommand and
             * Diagnostics tasks.  Rate-limit position acquisition using the
             * hardware_config.h macro. */
            sample_period_ticks = APP_NextPositionPeriodTicks(&sample_phase);
            vTaskDelayUntil(&last_sample_wake, sample_period_ticks);
        }
        else
        {
            /* No actuator is initialized: sleep until a command arrives instead
             * of polling the queue. */
            if (xQueueReceive(s_motor_command_queue,
                              &command,
                              portMAX_DELAY) == pdPASS)
            {
                APP_ProcessMotorCommand(&command);
                last_sample_wake = xTaskGetTickCount();
                sample_phase = 0U;
            }
        }
    }
}

void APP_DebugCommandTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    uint8_t ch;
    const actuator_profile_t *profile;

    if (UART_IF_StartBufferedRx(UART_IF_PORT_DEBUG) != UART_IF_OK)
    {
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }

    APP_DebugWrite("\r\nNG Actuator v10.4 selectable TMC UART/SPI transport\r\n"
                   "TMC interface: " HW_TMC_INTERFACE_NAME "\r\n"
                   "A=10kg  B=20kg  C=35kg\r\n"
                   "V=CW  W=CCW  Z=STOP/HOLD  R=REFRESH DIAG  ?=HELP\r\n"
                   "Run motion mode = 0x00002786.\r\n");

    for (;;)
    {
        if (UART_IF_ReadBuffered(UART_IF_PORT_DEBUG,
                                 &ch,
                                 1U,
                                 1000U) == 0U)
        {
            continue;
        }

        if ((ch >= (uint8_t)'a') && (ch <= (uint8_t)'z'))
        {
            ch = (uint8_t)(ch - ((uint8_t)'a' - (uint8_t)'A'));
        }

        profile = ActuatorProfile_FromCommand((char)ch);
        if (profile != NULL)
        {
            if (APP_QueueCommand(APP_CMD_SELECT_PROFILE, profile->type) == pdPASS)
            {
                APP_DebugWrite("PROFILE INIT REQUESTED\r\n");
            }
            else
            {
                APP_DebugWrite("ERR: COMMAND QUEUE FULL\r\n");
            }
            continue;
        }

        switch (ch)
        {
            case (uint8_t)'V':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'W':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CCW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CCW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'Z':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_STOP_HOLD,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("STOP/HOLD REQUESTED\r\n");
                }
                break;

            case (uint8_t)'R':
                if (APP_QueueCommand(APP_CMD_REFRESH_DIAGNOSTICS,
                                     g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("DIAG REFRESH REQUESTED\r\n");
                }
                break;

            case (uint8_t)'D':
            case (uint8_t)'E':
                APP_DebugWrite("D/E PROFILE RESERVED - ADD VALUES IN actuator_profile.c\r\n");
                break;

            case (uint8_t)'?':
            case (uint8_t)'H':
                APP_DebugWrite("A=10kg B=20kg C=35kg | V=CW W=CCW Z=HOLD R=DIAG\r\n"
                               "tmc=7 => driver not ON; tmc=9 => TMC 599Hz output-frequency shutdown.\r\n");
                break;

            case (uint8_t)'\r':
            case (uint8_t)'\n':
            case (uint8_t)' ':
                break;

            default:
                APP_DebugWrite("ERR: UNKNOWN COMMAND\r\n");
                break;
        }
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(1000U));
    }
#endif
}

void APP_DiagnosticsTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    char message[384];
    int length;
    uint32_t last_sample_count = 0U;
    uint32_t current_sample_count;
    uint32_t sample_rate_hz;
    uint32_t driver_on;
    uint32_t velocity_fail;
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        current_sample_count = g_app_status.position_sample_count;
        sample_rate_hz = ((current_sample_count - last_sample_count) * 1000U) /
                         HW_DIAG_PERIOD_MS;
        last_sample_count = current_sample_count;
        driver_on = ((g_app_status.chip_status_flags &
                      TMC6460_STATUS_GDRV_ON_MASK) != 0U) ? 1U : 0U;
        velocity_fail = (((g_app_status.chip_status_flags |
                            g_app_status.chip_events) &
                           TMC6460_STATUS_VEL_FAIL_MASK) != 0U) ? 1U : 0U;

        length = snprintf(message,
                          sizeof(message),
                          "STAT init=%u profile=%u state=%u tmc=%u chip=0x%08lX "
                          "cmd=%ld tgt=%ld vel=%ld pos=%ld posHz=%lu "
                          "hallRaw=%lu hallLog=%lu hallSec=%lu hallEvt=0x%08lX "
                          "fbB=0x%08lX phi=%lu drvOn=%lu vFail=%lu inRaw=0x%08lX "
                          "flags=0x%08lX events=0x%08lX gdrv=0x%08lX "
                          "motion=0x%08lX out=0x%08lX tq=%ld fl=%ld "
                          "posErr=%lu diagErr=%lu cmdErr=%lu\r\n",
                          (unsigned int)g_app_status.actuator_initialized,
                          (unsigned int)g_app_status.actuator_type,
                          (unsigned int)g_app_status.motor_state,
                          (unsigned int)g_app_status.tmc_status,
                          (unsigned long)g_app_status.tmc_chip_id,
                          (long)g_app_status.commanded_velocity_raw,
                          (long)g_app_status.velocity_target_readback_raw,
                          (long)g_app_status.velocity_actual_raw,
                          (long)g_app_status.position_raw,
                          (unsigned long)sample_rate_hz,
                          (unsigned long)g_app_status.hall_raw,
                          (unsigned long)g_app_status.hall_logic,
                          (unsigned long)g_app_status.hall_count,
                          (unsigned long)g_app_status.hall_events,
                          (unsigned long)g_app_status.feedback_ch_b_raw,
                          (unsigned long)g_app_status.phi_e_raw,
                          (unsigned long)driver_on,
                          (unsigned long)velocity_fail,
                          (unsigned long)g_app_status.chip_inputs_raw,
                          (unsigned long)g_app_status.chip_status_flags,
                          (unsigned long)g_app_status.chip_events,
                          (unsigned long)g_app_status.gate_driver_config,
                          (unsigned long)g_app_status.motor_motion_config,
                          (unsigned long)g_app_status.feedback_output_config,
                          (long)g_app_status.torque_actual_raw,
                          (long)g_app_status.flux_actual_raw,
                          (unsigned long)g_app_status.position_error_count,
                          (unsigned long)g_app_status.diagnostic_error_count,
                          (unsigned long)g_app_status.command_error_count);

        if (length > 0)
        {
            uint32_t tx_length = (uint32_t)length;
            if (tx_length >= sizeof(message))
            {
                tx_length = (uint32_t)(sizeof(message) - 1U);
            }

            (void)UART_IF_Write(UART_IF_PORT_DEBUG,
                                (const uint8_t *)message,
                                tx_length,
                                HW_DEBUG_UART_TIMEOUT_MS);
        }

        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#endif
}
