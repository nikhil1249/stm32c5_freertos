#include "tmc6460_motor.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stddef.h>

#define TMC6460_CONFIG_WRITE_GUARD_MS          2U

static uint32_t TMC6460_MotorPackLimit(int32_t limit_raw)
{
    uint32_t limit;

    if (limit_raw < 1)
    {
        limit_raw = 1;
    }
    else if (limit_raw > 65535)
    {
        limit_raw = 65535;
    }

    limit = (uint32_t)((uint16_t)limit_raw);
    return (limit << 16U) | limit;
}

static int32_t TMC6460_MotorAbs32(int32_t value)
{
    if (value >= 0)
    {
        return value;
    }

    if (value == (int32_t)0x80000000UL)
    {
        return 0x7FFFFFFF;
    }

    return -value;
}

static tmc6460_status_t TMC6460_MotorWriteConfig(tmc6460_motor_t *motor,
                                                  uint16_t address,
                                                  uint32_t value)
{
    tmc6460_status_t status;

    status = TMC6460_WriteRegister(motor->device, address, value);
    if (status == TMC6460_OK)
    {
        /* Keep a small guard between configuration writes.  This is not used
         * in the high-rate position acquisition path. */
        vTaskDelay(pdMS_TO_TICKS(TMC6460_CONFIG_WRITE_GUARD_MS));
    }

    return status;
}

static tmc6460_status_t TMC6460_MotorVerifyDriverOn(tmc6460_motor_t *motor)
{
    uint32_t flags = 0U;
    tmc6460_status_t status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_STATUS_FLAGS,
                                  &flags);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if ((flags & TMC6460_STATUS_GDRV_ON_MASK) == 0U)
    {
        motor->driver_enabled = 0U;
        return TMC6460_DRIVER_NOT_ENABLED;
    }

    motor->driver_enabled = 1U;
    return TMC6460_OK;
}

static tmc6460_status_t TMC6460_MotorEnsureDriverEnabled(tmc6460_motor_t *motor)
{
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    /* Read the real hardware state.  A fault can clear DRV_EN_BIT after our
     * software flag was set, so a cached flag alone is not sufficient. */
    status = TMC6460_MotorVerifyDriverOn(motor);
    if (status == TMC6460_OK)
    {
        return TMC6460_OK;
    }

    if (status != TMC6460_DRIVER_NOT_ENABLED)
    {
        return status;
    }

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_ENABLED);
    if (status != TMC6460_OK)
    {
        return status;
    }

    return TMC6460_MotorVerifyDriverOn(motor);
}

static tmc6460_status_t TMC6460_MotorVerifyRunState(tmc6460_motor_t *motor)
{
    uint32_t flags = 0U;
    uint32_t events = 0U;
    uint32_t gdrv = 0U;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_STATUS_FLAGS,
                                  &flags);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_EVENTS,
                                  &events);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_MCC_CONFIG_GDRV,
                                  &gdrv);
    if (status != TMC6460_OK) return status;

    if (((flags | events) & TMC6460_STATUS_VEL_FAIL_MASK) != 0U)
    {
        motor->driver_enabled = 0U;
        return TMC6460_VELOCITY_LIMIT_FAULT;
    }

    if (((flags & TMC6460_STATUS_GDRV_ON_MASK) == 0U) ||
        ((gdrv & TMC6460_GDRV_DRV_EN_BIT_MASK) == 0U))
    {
        motor->driver_enabled = 0U;
        return TMC6460_DRIVER_NOT_ENABLED;
    }

    motor->driver_enabled = 1U;
    return TMC6460_OK;
}

void TMC6460_MotorInitContext(tmc6460_motor_t *motor,
                              tmc6460_t *device)
{
    if (motor != NULL)
    {
        motor->device = device;
        motor->profile = NULL;
        motor->initialized = 0U;
        motor->driver_enabled = 0U;
        motor->commanded_velocity_raw = 0;
    }
}

tmc6460_status_t TMC6460_MotorConfigure(tmc6460_motor_t *motor,
                                        const tmc6460_motor_profile_t *profile,
                                        uint32_t expected_chip_id,
                                        uint32_t *chip_id_out)
{
    uint32_t chip_id = 0U;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    motor->initialized = 0U;
    motor->driver_enabled = 0U;
    motor->commanded_velocity_raw = 0;
    motor->profile = profile;

    status = TMC6460_ReadChipID(motor->device, &chip_id);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if (chip_id != expected_chip_id)
    {
        return TMC6460_INVALID_CHIP_ID;
    }

    if (chip_id_out != NULL)
    {
        *chip_id_out = chip_id;
    }

    /*
     * Preserve the already-proven Qt/TMC6460 register sequence exactly.
     * Do not replace these values with re-derived alternatives during basic
     * motor bring-up.  The hardware configuration shown by the working tool is
     * the reference baseline for this actuator.
     */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_CHIP_IO_MATRIX,
                                      TMC6460_VALUE_CHIP_IO_MATRIX);
    if (status != TMC6460_OK) return status;

    /* IO_PU_PD reset value is already 0x075800FF.  It is intentionally not
     * rewritten here because the working configuration did not write it. */

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_CHIP_IO_CONFIG,
                                      TMC6460_VALUE_CHIP_IO_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_ADC_CSA_GAIN,
                                      TMC6460_VALUE_MCC_ADC_CSA_GAIN);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_IDLE);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_DISABLED);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_PWM,
                                      TMC6460_VALUE_PWM_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_CONFIG,
                                      TMC6460_VALUE_PID_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_FLUX_COEFF,
                                      TMC6460_VALUE_FLUX_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_COEFF,
                                      TMC6460_VALUE_TORQUE_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_COEFF,
                                      TMC6460_VALUE_VELOCITY_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_UQ_UD_LIMITS,
                                      TMC6460_VALUE_UQ_UD_LIMITS);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(
                                          profile->run_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_CONF_CH_A,
                                      TMC6460_VALUE_FEEDBACK_CH_A);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_CONF_CH_B,
                                      TMC6460_VALUE_FEEDBACK_CH_B);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_VELOCITY_FRQ_CONF,
                                      TMC6460_VALUE_FEEDBACK_VELOCITY_FRQ_CONF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_VELOCITY_PER_CONF,
                                      TMC6460_VALUE_FEEDBACK_VELOCITY_PER_CONF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_VELOCITY_PER_FILTER,
                                      TMC6460_VALUE_FEEDBACK_VELOCITY_PER_FILTER);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FEEDBACK_OUTPUT_CONF,
                                      TMC6460_VALUE_FEEDBACK_OUTPUT_CONF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_LIMIT,
                                      (uint32_t)profile->maximum_velocity_raw);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      0U);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_HALL_MAP_CONFIG,
                                      TMC6460_VALUE_HALL_MAP_CONFIG);
    if (status != TMC6460_OK) return status;

    /* Enable the driver only after the static configuration is complete. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_ENABLED);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorVerifyDriverOn(motor);
    if (status != TMC6460_OK) return status;

    /* Do not make Hall validity a prerequisite for the proven Qt run path.
     * The Qt baseline uses its own motion/ramp configuration.  Raw Hall and
     * feedback values are still monitored by diagnostics. */

    status = TMC6460_ReadChipID(motor->device, &chip_id);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if (chip_id != expected_chip_id)
    {
        return TMC6460_INVALID_CHIP_ID;
    }

    /* Clear a previously latched velocity-frequency event. CHIP.EVENTS is W1C.
     * This makes the next V/W command diagnostic reflect only the new request. */
    status = TMC6460_WriteRegister(motor->device,
                                   TMC6460_REG_CHIP_EVENTS,
                                   TMC6460_EVENT_VEL_FAIL_MASK);
    if (status != TMC6460_OK) return status;

    motor->initialized = 1U;
    motor->commanded_velocity_raw = 0;
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_MotorSetVelocity(tmc6460_motor_t *motor,
                                          int32_t velocity_raw)
{
    tmc6460_status_t status;
    int32_t limit;

    if ((motor == NULL) || (motor->device == NULL) ||
        (motor->profile == NULL) || (motor->initialized == 0U))
    {
        return TMC6460_INVALID_PARAM;
    }

    if (velocity_raw == 0)
    {
        return TMC6460_MotorStopHold(motor);
    }

    limit = motor->profile->maximum_velocity_raw;
    if (TMC6460_MotorAbs32(velocity_raw) > limit)
    {
        velocity_raw = (velocity_raw > 0) ? limit : -limit;
    }

    /* CHIP.EVENTS is write-one-to-clear. Clear only the velocity-fail event
     * before a new motion request, so any bit-11 event observed afterwards
     * belongs to this command. */
    status = TMC6460_WriteRegister(motor->device,
                                   TMC6460_REG_CHIP_EVENTS,
                                   TMC6460_EVENT_VEL_FAIL_MASK);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorEnsureDriverEnabled(motor);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(
                                          motor->profile->run_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_RUN);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      (uint32_t)velocity_raw);
    if (status != TMC6460_OK) return status;

    /* The TMC6460 automatically clears DRV_EN_BIT if the 599 Hz electrical
     * output-frequency limit is exceeded. Give the hardware a few milliseconds
     * to react, then verify that the driver remained ON. */
    vTaskDelay(pdMS_TO_TICKS(3U));
    status = TMC6460_MotorVerifyRunState(motor);
    if (status != TMC6460_OK)
    {
        /* Leave the device in a benign zero-velocity command. Do not write the
         * torque/flux target to zero; preserve the application's hold policy. */
        (void)TMC6460_WriteRegister(motor->device,
                                    TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                    0U);
        motor->commanded_velocity_raw = 0;
        return status;
    }

    motor->commanded_velocity_raw = velocity_raw;
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_MotorRunCW(tmc6460_motor_t *motor)
{
    if ((motor == NULL) || (motor->profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    return TMC6460_MotorSetVelocity(motor,
                                    TMC6460_MotorAbs32(
                                        motor->profile->default_velocity_raw));
}

tmc6460_status_t TMC6460_MotorRunCCW(tmc6460_motor_t *motor)
{
    if ((motor == NULL) || (motor->profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    return TMC6460_MotorSetVelocity(motor,
                                    -TMC6460_MotorAbs32(
                                        motor->profile->default_velocity_raw));
}

tmc6460_status_t TMC6460_MotorStopHold(tmc6460_motor_t *motor)
{
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) ||
        (motor->profile == NULL) || (motor->initialized == 0U))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_MotorEnsureDriverEnabled(motor);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(
                                          motor->profile->hold_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_RUN);
    if (status != TMC6460_OK) return status;

    /* Deliberately do not zero the torque/flux target or disable the driver. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      0U);
    if (status == TMC6460_OK)
    {
        motor->commanded_velocity_raw = 0;
    }

    return status;
}

tmc6460_status_t TMC6460_MotorReadPosition(tmc6460_motor_t *motor,
                                           int32_t *position_raw)
{
    uint32_t value;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (position_raw == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_POSITION_ACTUAL,
                                  &value);
    if (status == TMC6460_OK)
    {
        *position_raw = (int32_t)value;
    }

    return status;
}

tmc6460_status_t TMC6460_MotorReadFeedback(tmc6460_motor_t *motor,
                                           tmc6460_feedback_t *feedback)
{
    uint32_t value;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (feedback == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_STATUS_FLAGS,
                                  &feedback->chip_status_flags);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_EVENTS,
                                  &feedback->chip_events);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_MCC_CONFIG_GDRV,
                                  &feedback->gate_driver_config);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                  &feedback->motor_motion_config);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FEEDBACK_OUTPUT_CONF,
                                  &feedback->feedback_output_config);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_INPUTS_RAW,
                                  &feedback->chip_inputs_raw);
    if (status != TMC6460_OK) return status;
    feedback->hall_raw =
        (feedback->chip_inputs_raw & TMC6460_INPUTS_HALL_RAW_MASK) >>
        TMC6460_INPUTS_HALL_RAW_SHIFT;
    feedback->hall_logic =
        (feedback->chip_inputs_raw & TMC6460_INPUTS_HALL_LOGIC_MASK) >>
        TMC6460_INPUTS_HALL_LOGIC_SHIFT;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_HALL_DIG_COUNT,
                                  &value);
    if (status != TMC6460_OK) return status;
    /* Rev.0 decoder sector is 0..5. */
    feedback->hall_count = value & 0x7U;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_HALL_DIG_EVENTS,
                                  &feedback->hall_events);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FEEDBACK_CH_B,
                                  &feedback->feedback_ch_b_raw);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FEEDBACK_PHI_E,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->phi_e_raw = value & 0xFFFFU;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->velocity_target_raw = (int32_t)value;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_VELOCITY_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->velocity_actual_raw = (int32_t)value;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_POSITION_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->position_actual_raw = (int32_t)value;

    /* Rev.0 packs torque and flux actual into a single 32-bit register. */
    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_TORQUE_FLUX_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->torque_actual_raw = (int32_t)((int16_t)(value >> 16U));
    feedback->flux_actual_raw = (int32_t)((int16_t)(value & 0xFFFFU));

    return TMC6460_OK;
}
