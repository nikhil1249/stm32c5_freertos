# NG Actuator Firmware Architecture and Auto-Calibration Design

## 1. Baseline and scope

This version is derived from the verified `NG_Actuator_Industry_Architecture_IAR_v10_4_MotorTaskFix` benchmark. The benchmark behavior is intentionally preserved:

- STM32C562RE, IAR EWARM, FreeRTOS.
- TMC6460 host transport selectable by `HW_TMC_UART_ENABLE` / `HW_TMC_SPI_ENABLE`.
- SPI2 benchmark mapping: PB12 CSN, PB13 SCK, PB14 MISO, PB15 MOSI, external active-low CSN, mode 1, 4.5 MHz.
- Debug USART2 on ST-LINK VCP.
- TMC6460 run motion value `0x00002786` and idle/configuration value `0x00002386`.
- `V` = CW, `W` = CCW, `Z` = velocity zero + non-zero hold limit + gate driver kept enabled.
- Runtime position sampling limited to 400 Hz so the priority-4 MotorService task does not starve lower-priority tasks.

The v11 addition is automatic mechanical end calibration using debug command `G`.

## 2. Layered architecture

```text
+------------------------------------------------------------------+
|                         Application Layer                         |
|                                                                  |
|  app.c              actuator_profile.c       actuator_calibration.c
|  command routing    actuator types/limits    calibration algorithm |
+------------------------------+-----------------------------------+
                               |
                               v
+------------------------------------------------------------------+
|                      TMC6460 Middleware                           |
|                                                                  |
|  tmc6460_motor.c    motor configure/run/hold/read motion sample  |
|  tmc6460.c          generic 32-bit register access               |
|  tmc6460_transport  UART/SPI framing + transport selection       |
+------------------------------+-----------------------------------+
                               |
                 +-------------+-------------+
                 |                           |
                 v                           v
          +-------------+              +-------------+
          |  UART_IF    |              |   SPI_IF    |
          | IRQ + RTOS  |              | IRQ + RTOS  |
          +------+------+              +------+------+ 
                 |                            |
                 +-------------+--------------+
                               v
+------------------------------------------------------------------+
|                         BSP / HAL Layer                           |
| clock, GPIO, USART1/2, SPI2, external CSN, IRQ priorities        |
+------------------------------+-----------------------------------+
                               |
                               v
                         STM32C562RE
                               |
                               v
                            TMC6460
```

### Ownership rule

Only `MotorServiceTask` performs TMC6460 register transactions. This remains true during calibration. The calibration module is called synchronously from `MotorServiceTask`; it yields with FreeRTOS delays while moving/sampling, so DebugCommand, Diagnostics and Heartbeat continue running.

## 3. FreeRTOS task architecture

| Task | Priority | Responsibility |
|---|---:|---|
| MotorService | 4 | Sole TMC6460 owner, command execution, 400 Hz runtime position sampling, runs calibration state sequence |
| DebugCommand | 3 | USART2 command RX, pushes normal commands to MotorService queue, can set calibration abort flag |
| Heartbeat | 1 | PA5 heartbeat |
| Diagnostics | 1 | Periodic cached status output; never touches the TMC bus directly |

Normal runtime position polling remains 400 Hz. Calibration uses a dedicated 100 Hz motion sample rate because endpoint detection requires deterministic low-rate filtering rather than maximum bus throughput.

## 4. Debug command set

| Character | Action |
|---|---|
| A | Select/configure 10 kg actuator |
| B | Select/configure 20 kg actuator |
| C | Select/configure 35 kg actuator |
| V | CW run |
| W | CCW run |
| Z | Stop/hold; during calibration it requests abort |
| G | Automatic 0 degree / 90 degree calibration |
| R | Refresh diagnostic snapshot |
| H or ? | Help |

`G` is accepted only after an actuator profile has been initialized successfully.

## 5. Calibration objective

The actuator has mechanical end stops corresponding to:

- CCW end = physical 0 degrees.
- CW end = physical 90 degrees.

The controller's Hall-derived `POSITION_ACTUAL` is incremental. Therefore calibration determines:

1. Current-session raw 0 degree endpoint.
2. Current-session raw 90 degree endpoint.
3. Signed 0-to-90 stroke counts.
4. Absolute stroke counts.
5. Direction sign of position count growth.
6. Endpoint repeatability/spread.

The reusable compile-time quantity is primarily `STROKE_COUNTS` plus `DIRECTION_SIGN`. Raw absolute endpoint numbers are not guaranteed to be identical after a power cycle. At boot, a homing operation is still required to establish a new runtime zero reference before converting position to absolute degrees.

## 6. Calibration configuration

Calibration policy is intentionally stored in `config/actuator_calibration_config.h`, not `hardware_config.h`. `hardware_config.h` remains the single STM32C5 board/peripheral configuration file.

Main calibration macro:

```c
#define ACTUATOR_CALIBRATION_ITERATION_COUNT 5U
```

Other key values:

```c
#define ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ        100U
#define ACTUATOR_CALIBRATION_STARTUP_BLANKING_MS   300U
#define ACTUATOR_CALIBRATION_STALL_CONFIRM_MS      250U
#define ACTUATOR_CALIBRATION_POSITION_DELTA_COUNTS 8L
#define ACTUATOR_CALIBRATION_MAX_LEG_TIME_MS       30000U
#define ACTUATOR_CALIBRATION_SETTLE_TIME_MS        150U
#define ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES  16U
```

Low calibration velocity is separately configurable for each actuator type. Default is 250000 raw for 10/20/35 kg in this release.

## 7. Calibration state sequence

```text
G received
   |
   +--> verify actuator initialized
   |
   +--> CAL START
   |
   +--> CCW low speed ------------------------------+
   |                                                |
   |       detect stable mechanical stop            |
   |                                                v
   +<-------------------------- HOME physical 0 deg
   |
   |   Initial homing is NOT counted in statistics
   |
   +--> for iteration = 1..N
          |
          +--> CW low speed -> detect stop -> HOLD -> capture 90 deg
          |
          +--> delay
          |
          +--> CCW low speed -> detect stop -> HOLD -> capture 0 deg
          |
          +--> delay
   |
   +--> analyze N zero samples + N ninety samples
   |
   +--> median endpoints
   +--> endpoint spread
   +--> stroke min/max/average
   +--> signed/absolute stroke
   +--> repeatability validation
   |
   +--> COMPLETE; actuator remains held at physical 0 deg
```

## 8. End-stop detection algorithm

The calibration deliberately approaches each mechanical stop at low velocity. A stop is accepted only after the startup blanking interval and after a stable condition persists for the full confirmation time.

For each 100 Hz sample:

```text
position_delta = abs(position[n] - position[n-1])
velocity_low   = abs(actual_velocity) <= threshold
position_stable= position_delta <= configured count threshold
```

Default endpoint decision has two paths:

```text
FAST confirmation:     position_stable AND velocity_low for 250 ms
ROBUST fallback:       position_stable continuously for 600 ms
```

The code also supports actuator-specific torque corroboration. If a non-zero `ACTUATOR_CAL_xx_TORQUE_STALL_RAW` is configured, the condition becomes:

```text
position_stable AND (velocity_low OR torque_high)
```

Torque thresholds default to zero (disabled) until validated for each mechanism. This avoids false end detection caused by normal load torque.

The stable condition must remain true for `ACTUATOR_CALIBRATION_STALL_CONFIRM_MS` (250 ms by default), not merely one sample.

## 9. Endpoint capture

When an end is detected:

1. `TMC6460_MotorStopHold()` is called.
2. Gate driver remains enabled.
3. Velocity target becomes zero.
4. Hold torque/flux limit remains non-zero.
5. Firmware waits for mechanical settle time.
6. Firmware averages `ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES` position reads.

This avoids using the first impacted/bouncing sample as the endpoint.

## 10. Statistical result

For each end, v11 stores all N samples and calculates:

- Arithmetic average.
- Median (used as the recommended endpoint).
- Min-to-max spread.

For every iteration it also calculates stroke magnitude:

```text
stroke[i] = abs(position90[i] - position0[i])
```

The final result includes:

- `zero_raw` = median zero endpoint.
- `ninety_raw` = median 90 endpoint.
- `stroke_signed_counts` = `ninety_raw - zero_raw`.
- `stroke_counts` = absolute signed stroke.
- `direction_sign` = +1 or -1.
- zero/90 spread.
- stroke min/max/average.

Calibration fails as unstable if endpoint or stroke variation exceeds the configured percentage tolerance.

## 11. Generated compile-time values

After a successful calibration, the debug UART prints ready-to-paste macros, for example:

```c
#define ACT_CAL_10KG_VALID 1U
#define ACT_CAL_10KG_ZERO_RAW_REFERENCE -12530L
#define ACT_CAL_10KG_NINETY_RAW_REFERENCE 2867412L
#define ACT_CAL_10KG_STROKE_COUNTS 2879942UL
#define ACT_CAL_10KG_DIRECTION_SIGN 1L
```

Paste them into `config/actuator_calibration_config.h` after validating the result on the bench.

Important: `ZERO_RAW_REFERENCE` and `NINETY_RAW_REFERENCE` are lab/session references. They must not be treated as absolute retained position after reset. Use stored stroke counts only after homing the actuator to 0 degrees in the current boot session.

## 12. Position-to-angle conversion

After `G` succeeds in the current session:

```text
angle_deg_x100 =
    (position_raw - zero_raw) * 9000 / stroke_signed_counts
```

The diagnostic field `angle=` therefore reports values such as:

```text
0.00
45.13
90.02
```

The function does not clamp the result so that mechanical overtravel or reference errors remain visible during validation.

## 13. Safety behavior

- Calibration uses low velocity.
- Every leg has a 30 second timeout.
- Any TMC communication failure stops the calibration and requests HOLD.
- `Z` during calibration sets an abort flag; the calibration loop checks it every sample and immediately transitions to HOLD.
- Normal A/B/C/V/W/G/R commands are rejected while calibration is active so they cannot queue behind a long calibration operation.
- The calibration path never deliberately writes torque/flux target to zero.
- The gate driver remains enabled in hold unless the TMC itself reports a fault.

Because calibration intentionally finds physical hard stops, first validation should be performed with conservative supply/current limits and monitored hardware.

## 14. Calibration status in diagnostics

Additional fields are appended to the existing `STAT` line:

```text
calAct=1       calibration currently running
calValid=0/1   valid result available in current session
calSt=N        calibration status enum
calIt=N        current/recent iteration
cal0=...       most recent/final zero endpoint
cal90=...      most recent/final ninety endpoint
stroke=...     final absolute stroke counts
angle=xx.xx    current-session calculated angle
```

Calibration status values:

| Value | Meaning |
|---:|---|
| 0 | OK |
| 1 | Invalid parameter |
| 2 | Actuator not initialized |
| 3 | TMC communication/error |
| 4 | Leg timeout |
| 5 | Repeatability/consistency failure |
| 6 | User abort |

## 15. Source tree ownership

```text
project/
  config/
    hardware_config.h                 STM32C5 hardware/RTOS only
    actuator_calibration_config.h     calibration policy/results

  bsp/
    bsp.c/h                           GPIO/RCC/UART/SPI hardware

  drivers/
    uart/uart_iface.c/h               generic interrupt UART
    spi/spi_iface.c/h                 generic interrupt SPI + external CS

  middleware/tmc6460/
    tmc6460_transport.c/h             UART/SPI TMC protocol transport
    tmc6460.c/h                       register API
    tmc6460_registers.h               register addresses + proven values
    tmc6460_motor.c/h                 configure/run/hold/motion sampling

  application/
    actuator_profile.c/h              actuator type parameters
    actuator_calibration.c/h          auto-calibration algorithm
    app.c/h                           RTOS-facing application service

  generated/middleware/
    mx_freertos_app.c/h               task creation only
```

## 16. Bench validation procedure

1. Build and flash v11.
2. Confirm normal v10.4 behavior first: `A`, `V`, `Z`, `W`, `Z`.
3. Return to a safe mid position if needed.
4. Send `A` (or B/C) to initialize selected actuator.
5. Send `G` once.
6. Observe `CAL:` messages and mechanical movement.
7. Confirm initial CCW homing reaches physical 0 degrees.
8. Confirm each iteration travels 0 -> 90 -> 0.
9. Confirm no unexpected high-speed impacts.
10. Confirm final output reports five samples per endpoint and prints macros.
11. Check endpoint spread and stroke spread are acceptably small.
12. Manually move after calibration and confirm `angle=` tracks approximately 0..90 degrees.
13. Copy validated result macros into `actuator_calibration_config.h` if desired.

## 17. Future extensions

This design intentionally leaves room for:

- boot-time homing using compiled stroke values;
- soft-stop/creep start derived as a percentage/count distance from each end;
- flash/NVM persistence instead of manually copied macros;
- actuator-specific torque-based hard-stop confirmation;
- automatic calibration data CRC/versioning;
- supervisory-controller command instead of debug UART `G`;
- performance cycling between calibrated software limits.
