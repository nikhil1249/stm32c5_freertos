#include "tmc6460_transport.h"
#include "hardware_config.h"
#include "uart_iface.h"
#include "spi_iface.h"

#include <stddef.h>

#define TMC6460_MAX_REGISTER_ADDRESS          0x03FFU

/* UART framing ------------------------------------------------------------- */
#define TMC6460_UART_READ_TX_SIZE             2U
#define TMC6460_UART_READ_RX_SIZE             6U
#define TMC6460_UART_WRITE_TX_SIZE            6U
#define TMC6460_UART_WRITE_RX_SIZE            5U
#define TMC6460_UART_BASE_HEADER              0x42U
#define TMC6460_UART_WRITE_BIT                0x08U

/* SPI framing -------------------------------------------------------------- */
#define TMC6460_SPI_FRAME_SIZE                6U
#define TMC6460_SPI_WRITE_BIT                 0x80U
#define TMC6460_SPI_ADDR_HIGH_MASK            0x03U

#if (HW_TMC_UART_ENABLE != 0U)
static uint8_t TMC6460_UART_GetHeader(uint16_t address, uint8_t write)
{
    uint8_t header = (uint8_t)(TMC6460_UART_BASE_HEADER |
                               ((address >> 4U) & 0x30U));

    if (write != 0U)
    {
        header |= TMC6460_UART_WRITE_BIT;
    }

    return header;
}

static tmc6460_transport_status_t TMC6460_FromUartStatus(uart_if_status_t status)
{
    switch (status)
    {
        case UART_IF_OK:            return TMC6460_TRANSPORT_OK;
        case UART_IF_BUSY:          return TMC6460_TRANSPORT_BUSY;
        case UART_IF_TIMEOUT:       return TMC6460_TRANSPORT_TIMEOUT;
        case UART_IF_INVALID_PARAM: return TMC6460_TRANSPORT_INVALID_PARAM;
        default:                    return TMC6460_TRANSPORT_ERROR;
    }
}
#endif

#if (HW_TMC_SPI_ENABLE != 0U)
static tmc6460_transport_status_t TMC6460_FromSpiStatus(spi_if_status_t status)
{
    switch (status)
    {
        case SPI_IF_OK:            return TMC6460_TRANSPORT_OK;
        case SPI_IF_BUSY:          return TMC6460_TRANSPORT_BUSY;
        case SPI_IF_TIMEOUT:       return TMC6460_TRANSPORT_TIMEOUT;
        case SPI_IF_INVALID_PARAM: return TMC6460_TRANSPORT_INVALID_PARAM;
        default:                   return TMC6460_TRANSPORT_ERROR;
    }
}

static void TMC6460_SPI_BuildFrame(uint16_t address,
                                   uint8_t write,
                                   uint32_t value,
                                   uint8_t frame[TMC6460_SPI_FRAME_SIZE])
{
    frame[0] = (uint8_t)(((write != 0U) ? TMC6460_SPI_WRITE_BIT : 0U) |
                         ((address >> 8U) & TMC6460_SPI_ADDR_HIGH_MASK));
    frame[1] = (uint8_t)(address & 0xFFU);
    frame[2] = (uint8_t)((value >> 24U) & 0xFFU);
    frame[3] = (uint8_t)((value >> 16U) & 0xFFU);
    frame[4] = (uint8_t)((value >> 8U) & 0xFFU);
    frame[5] = (uint8_t)(value & 0xFFU);
}

static uint16_t TMC6460_SPI_ResponseAddress(const uint8_t response[TMC6460_SPI_FRAME_SIZE])
{
    return (uint16_t)((((uint16_t)response[0] & TMC6460_SPI_ADDR_HIGH_MASK) << 8U) |
                      (uint16_t)response[1]);
}

static uint32_t TMC6460_SPI_ResponseData(const uint8_t response[TMC6460_SPI_FRAME_SIZE])
{
    return ((uint32_t)response[2] << 24U) |
           ((uint32_t)response[3] << 16U) |
           ((uint32_t)response[4] << 8U)  |
           ((uint32_t)response[5]);
}
#endif

tmc6460_transport_status_t TMC6460_TransportReadRegister(uint16_t address,
                                                         uint32_t *value,
                                                         uint32_t timeout_ms)
{
    if ((value == NULL) || (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_TRANSPORT_INVALID_PARAM;
    }

#if (HW_TMC_UART_ENABLE != 0U)
    {
        uint8_t tx[TMC6460_UART_READ_TX_SIZE];
        uint8_t rx[TMC6460_UART_READ_RX_SIZE];
        uart_if_status_t uart_status;

        tx[0] = TMC6460_UART_GetHeader(address, 0U);
        tx[1] = (uint8_t)(address & 0xFFU);

        uart_status = UART_IF_WriteRead(UART_IF_PORT_TMC,
                                        tx,
                                        sizeof(tx),
                                        rx,
                                        sizeof(rx),
                                        timeout_ms);
        if (uart_status != UART_IF_OK)
        {
            return TMC6460_FromUartStatus(uart_status);
        }

        if ((rx[0] != tx[0]) || (rx[1] != tx[1]))
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        *value = ((uint32_t)rx[2] << 24U) |
                 ((uint32_t)rx[3] << 16U) |
                 ((uint32_t)rx[4] << 8U)  |
                 ((uint32_t)rx[5]);

        return TMC6460_TRANSPORT_OK;
    }
#else
    {
        uint8_t request[TMC6460_SPI_FRAME_SIZE];
        uint8_t first_response[TMC6460_SPI_FRAME_SIZE];
        uint8_t read_response[TMC6460_SPI_FRAME_SIZE];
        spi_if_status_t spi_status;

        /* SPI is pipelined: the reply to a request appears during the NEXT
         * 48-bit datagram. Send the same read request twice and use the second
         * response. Example: address 0x140 -> 01 40 00 00 00 00. */
        TMC6460_SPI_BuildFrame(address, 0U, 0U, request);

        spi_status = SPI_IF_Transfer(SPI_IF_PORT_TMC,
                                     request,
                                     first_response,
                                     sizeof(request),
                                     timeout_ms);
        if (spi_status != SPI_IF_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        spi_status = SPI_IF_Transfer(SPI_IF_PORT_TMC,
                                     request,
                                     read_response,
                                     sizeof(request),
                                     timeout_ms);
        if (spi_status != SPI_IF_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        if (TMC6460_SPI_ResponseAddress(read_response) != address)
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        *value = TMC6460_SPI_ResponseData(read_response);
        return TMC6460_TRANSPORT_OK;
    }
#endif
}

tmc6460_transport_status_t TMC6460_TransportWriteRegister(uint16_t address,
                                                          uint32_t value,
                                                          uint32_t timeout_ms)
{
    if (address > TMC6460_MAX_REGISTER_ADDRESS)
    {
        return TMC6460_TRANSPORT_INVALID_PARAM;
    }

#if (HW_TMC_UART_ENABLE != 0U)
    {
        uint8_t tx[TMC6460_UART_WRITE_TX_SIZE];
        uint8_t rx[TMC6460_UART_WRITE_RX_SIZE];
        uart_if_status_t uart_status;

        tx[0] = TMC6460_UART_GetHeader(address, 1U);
        tx[1] = (uint8_t)(address & 0xFFU);
        tx[2] = (uint8_t)((value >> 24U) & 0xFFU);
        tx[3] = (uint8_t)((value >> 16U) & 0xFFU);
        tx[4] = (uint8_t)((value >> 8U) & 0xFFU);
        tx[5] = (uint8_t)(value & 0xFFU);

        /* Normal UART writes produce a five-byte channel-7 response on the
         * reset/default TMC6460 configuration. Consume it before returning. */
        uart_status = UART_IF_WriteRead(UART_IF_PORT_TMC,
                                        tx,
                                        sizeof(tx),
                                        rx,
                                        sizeof(rx),
                                        timeout_ms);
        if (uart_status != UART_IF_OK)
        {
            return TMC6460_FromUartStatus(uart_status);
        }

        if ((rx[0] & 0x8FU) != 0x0FU)
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        return TMC6460_TRANSPORT_OK;
    }
#else
    {
        uint8_t write_request[TMC6460_SPI_FRAME_SIZE];
        uint8_t followup_read[TMC6460_SPI_FRAME_SIZE];
        uint8_t ignored_response[TMC6460_SPI_FRAME_SIZE];
        uint8_t write_response[TMC6460_SPI_FRAME_SIZE];
        spi_if_status_t spi_status;

        /* SPI write example from the data sheet:
         * address 0x0C3, value 2 -> 80 C3 00 00 00 02. */
        TMC6460_SPI_BuildFrame(address, 1U, value, write_request);

        /* A second command is required to clock out the response to the write.
         * Use a harmless read of the same register. The response received
         * during this second frame is the read-after-write response. */
        TMC6460_SPI_BuildFrame(address, 0U, 0U, followup_read);

        spi_status = SPI_IF_Transfer(SPI_IF_PORT_TMC,
                                     write_request,
                                     ignored_response,
                                     sizeof(write_request),
                                     timeout_ms);
        if (spi_status != SPI_IF_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        spi_status = SPI_IF_Transfer(SPI_IF_PORT_TMC,
                                     followup_read,
                                     write_response,
                                     sizeof(followup_read),
                                     timeout_ms);
        if (spi_status != SPI_IF_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        if (TMC6460_SPI_ResponseAddress(write_response) != address)
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        /* Do not require response data == requested value: W1C, self-clearing,
         * and hardware-modified registers can legitimately read back different
         * data immediately after a write. */
        return TMC6460_TRANSPORT_OK;
    }
#endif
}
