#ifndef TMC6460_MOTOR_H
#define TMC6460_MOTOR_H

#include "tmc6460.h"
#include <stdint.h>

/* Device-independent actuator parameters consumed by the TMC6460 middleware.
 * The application may embed this structure in a larger product profile. */
typedef struct
{
    int32_t run_torque_flux_limit_raw;
    int32_t hold_torque_flux_limit_raw;
    int32_t maximum_torque_flux_limit_raw;
    int32_t default_velocity_raw;
    int32_t maximum_velocity_raw;
} tmc6460_motor_profile_t;

typedef struct
{
    tmc6460_t *device;
    const tmc6460_motor_profile_t *profile;
    uint8_t initialized;
    uint8_t driver_enabled;
    int32_t commanded_velocity_raw;
} tmc6460_motor_t;

typedef struct
{
    uint32_t chip_status_flags;
    uint32_t chip_events;
    int32_t velocity_actual_raw;
    int32_t position_actual_raw;
    int32_t torque_actual_raw;
    int32_t flux_actual_raw;
} tmc6460_feedback_t;

void TMC6460_MotorInitContext(tmc6460_motor_t *motor,
                              tmc6460_t *device);

tmc6460_status_t TMC6460_MotorConfigure(tmc6460_motor_t *motor,
                                        const tmc6460_motor_profile_t *profile,
                                        uint32_t expected_chip_id,
                                        uint32_t *chip_id_out);

tmc6460_status_t TMC6460_MotorSetVelocity(tmc6460_motor_t *motor,
                                          int32_t velocity_raw);

tmc6460_status_t TMC6460_MotorRunCW(tmc6460_motor_t *motor);
tmc6460_status_t TMC6460_MotorRunCCW(tmc6460_motor_t *motor);

/* Controlled hold: velocity=0, non-zero hold torque/flux limit, driver enabled.
 * This function intentionally does NOT write FOC_PID_TORQUE_FLUX_TARGET=0. */
tmc6460_status_t TMC6460_MotorStopHold(tmc6460_motor_t *motor);

tmc6460_status_t TMC6460_MotorReadPosition(tmc6460_motor_t *motor,
                                           int32_t *position_raw);

tmc6460_status_t TMC6460_MotorReadFeedback(tmc6460_motor_t *motor,
                                           tmc6460_feedback_t *feedback);

#endif /* TMC6460_MOTOR_H */
