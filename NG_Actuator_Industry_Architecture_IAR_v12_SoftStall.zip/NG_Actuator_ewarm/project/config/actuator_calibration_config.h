#ifndef ACTUATOR_CALIBRATION_CONFIG_H
#define ACTUATOR_CALIBRATION_CONFIG_H

/*
 * NG Actuator automatic end calibration configuration.
 *
 * This file is intentionally separate from hardware_config.h.  The latter is
 * reserved for STM32C5 board/peripheral/RTOS settings.  These values describe
 * actuator calibration policy and the compile-time results produced by a
 * successful G calibration run.
 */

/* -------------------------------------------------------------------------- */
/* Calibration procedure                                                      */
/* -------------------------------------------------------------------------- */

/* Number of complete 0 -> 90 -> 0 measurement cycles after the initial home. */
#define ACTUATOR_CALIBRATION_ITERATION_COUNT          5U

/* Dedicated calibration sampling rate. Normal runtime position sampling stays
 * at HW_TMC_POSITION_SAMPLE_RATE_HZ (400 Hz in the v10.4 benchmark). */
#define ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ           100U

/* A single transient SPI/UART error must not abort a multi-cycle calibration.
 * Each calibration TMC operation is retried this many additional times.
 * v10.4 proved the SPI transport; this is resilience against an occasional
 * runtime timeout/noise event while the motor is energized. */
#define ACTUATOR_CALIBRATION_TMC_RETRY_COUNT           3U
#define ACTUATOR_CALIBRATION_TMC_RETRY_DELAY_MS        2U

/* Low calibration velocities. Positive velocity is the existing V/CW
 * direction and is defined as physical 0 -> 90 degrees.  Negative is W/CCW
 * and homes toward physical 0 degrees. */
#define ACTUATOR_CAL_10KG_VELOCITY_RAW                250000L
#define ACTUATOR_CAL_20KG_VELOCITY_RAW                250000L
#define ACTUATOR_CAL_35KG_VELOCITY_RAW                250000L

/* Optional torque corroboration. 0 disables torque as an end criterion.
 * If a validated torque threshold becomes available for an actuator, set it
 * here; endpoint detection then accepts position-stable AND
 * (velocity-low OR torque-high). */
#define ACTUATOR_CAL_10KG_TORQUE_STALL_RAW             0L
#define ACTUATOR_CAL_20KG_TORQUE_STALL_RAW             0L
#define ACTUATOR_CAL_35KG_TORQUE_STALL_RAW             0L

/* Ignore stall criteria immediately after starting a leg. */
#define ACTUATOR_CALIBRATION_STARTUP_BLANKING_MS      300U

/* Both low position movement and low velocity must persist for this time
 * before a mechanical end is accepted. */
#define ACTUATOR_CALIBRATION_STALL_CONFIRM_MS         250U
/* Fallback: if position is continuously stable for this longer period,
 * accept the end even if velocity feedback is noisy/non-zero. */
#define ACTUATOR_CALIBRATION_POSITION_ONLY_CONFIRM_MS 600U

/* Maximum allowed position change between two calibration samples while
 * declaring the shaft stationary. Tune only if actual position is noisy. */
#define ACTUATOR_CALIBRATION_POSITION_DELTA_COUNTS    8L

/* Velocity is considered stopped below this percentage of the commanded
 * calibration velocity. */
#define ACTUATOR_CALIBRATION_VELOCITY_STOP_PERCENT    12U
#define ACTUATOR_CALIBRATION_VELOCITY_STOP_MIN_RAW    1000L

/* Hard protection against a missing end-stop / wrong direction / disconnected
 * mechanics.  Must exceed the slowest expected full-stroke time. */
#define ACTUATOR_CALIBRATION_MAX_LEG_TIME_MS          30000U

/* After stall is detected, command Z-style hold, wait for mechanics to settle,
 * then average several position reads to capture the endpoint. */
#define ACTUATOR_CALIBRATION_SETTLE_TIME_MS           150U
#define ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES     16U
#define ACTUATOR_CALIBRATION_INTER_LEG_DELAY_MS       250U

/* Result quality checks. */
#define ACTUATOR_CALIBRATION_MIN_STROKE_COUNTS        1000UL
#define ACTUATOR_CALIBRATION_MAX_SPREAD_PERCENT       2U
#define ACTUATOR_CALIBRATION_MIN_ALLOWED_SPREAD       64UL

/* Direction convention used throughout the application. */
#define ACTUATOR_CALIBRATION_ZERO_TO_90_SIGN          1L

/* -------------------------------------------------------------------------- */
/* Compile-time calibration result placeholders                               */
/* -------------------------------------------------------------------------- */
/*
 * A successful G command prints ready-to-paste #define values for the selected
 * actuator.  The raw ZERO/NINETY values are useful as a same-session/lab
 * reference only: Hall-derived POSITION_ACTUAL is incremental and can start at
 * a different raw value after a power cycle.  STROKE_COUNTS and DIRECTION_SIGN
 * are the reusable calibration constants.  At boot, home to 0 degrees before
 * using the stored stroke to establish an absolute software angle.
 */

#define ACT_CAL_10KG_VALID                            0U
#define ACT_CAL_10KG_ZERO_RAW_REFERENCE               0L
#define ACT_CAL_10KG_NINETY_RAW_REFERENCE             0L
#define ACT_CAL_10KG_STROKE_COUNTS                    0UL
#define ACT_CAL_10KG_DIRECTION_SIGN                   1L

#define ACT_CAL_20KG_VALID                            0U
#define ACT_CAL_20KG_ZERO_RAW_REFERENCE               0L
#define ACT_CAL_20KG_NINETY_RAW_REFERENCE             0L
#define ACT_CAL_20KG_STROKE_COUNTS                    0UL
#define ACT_CAL_20KG_DIRECTION_SIGN                   1L

#define ACT_CAL_35KG_VALID                            0U
#define ACT_CAL_35KG_ZERO_RAW_REFERENCE               0L
#define ACT_CAL_35KG_NINETY_RAW_REFERENCE             0L
#define ACT_CAL_35KG_STROKE_COUNTS                    0UL
#define ACT_CAL_35KG_DIRECTION_SIGN                   1L

/* Compile-time sanity checks. */
#if (ACTUATOR_CALIBRATION_ITERATION_COUNT < 2U)
#error "Use at least two calibration iterations. Five is recommended."
#endif

#if ((ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ == 0U) || \
     (ACTUATOR_CALIBRATION_SAMPLE_RATE_HZ > 1000U))
#error "Invalid actuator calibration sample rate."
#endif

#if (ACTUATOR_CALIBRATION_ENDPOINT_AVG_SAMPLES == 0U)
#error "Endpoint averaging needs at least one sample."
#endif

#endif /* ACTUATOR_CALIBRATION_CONFIG_H */
