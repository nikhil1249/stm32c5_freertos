#include "tmc6460_motor.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stddef.h>

#define TMC6460_CONFIG_WRITE_GUARD_MS          2U

static uint32_t TMC6460_MotorPackLimit(int32_t limit_raw)
{
    uint32_t limit;

    if (limit_raw < 1)
    {
        limit_raw = 1;
    }
    else if (limit_raw > 65535)
    {
        limit_raw = 65535;
    }

    limit = (uint32_t)((uint16_t)limit_raw);
    return (limit << 16U) | limit;
}

static int32_t TMC6460_MotorAbs32(int32_t value)
{
    if (value >= 0)
    {
        return value;
    }

    if (value == (int32_t)0x80000000UL)
    {
        return 0x7FFFFFFF;
    }

    return -value;
}

static tmc6460_status_t TMC6460_MotorWriteConfig(tmc6460_motor_t *motor,
                                                  uint16_t address,
                                                  uint32_t value)
{
    tmc6460_status_t status;

    status = TMC6460_WriteRegister(motor->device, address, value);
    if (status == TMC6460_OK)
    {
        /* Preserve the proven Qt configuration pacing. */
        vTaskDelay(pdMS_TO_TICKS(TMC6460_CONFIG_WRITE_GUARD_MS));
    }

    return status;
}

static tmc6460_status_t TMC6460_MotorEnsureDriverEnabled(tmc6460_motor_t *motor)
{
    tmc6460_status_t status;

    if (motor->driver_enabled != 0U)
    {
        return TMC6460_OK;
    }

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_ENABLED);
    if (status == TMC6460_OK)
    {
        motor->driver_enabled = 1U;
    }

    return status;
}

void TMC6460_MotorInitContext(tmc6460_motor_t *motor,
                              tmc6460_t *device)
{
    if (motor != NULL)
    {
        motor->device = device;
        motor->profile = NULL;
        motor->initialized = 0U;
        motor->driver_enabled = 0U;
        motor->commanded_velocity_raw = 0;
    }
}

tmc6460_status_t TMC6460_MotorConfigure(tmc6460_motor_t *motor,
                                        const tmc6460_motor_profile_t *profile,
                                        uint32_t expected_chip_id,
                                        uint32_t *chip_id_out)
{
    uint32_t chip_id = 0U;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    motor->initialized = 0U;
    motor->driver_enabled = 0U;
    motor->commanded_velocity_raw = 0;
    motor->profile = profile;

    status = TMC6460_ReadChipID(motor->device, &chip_id);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if (chip_id != expected_chip_id)
    {
        return TMC6460_INVALID_CHIP_ID;
    }

    if (chip_id_out != NULL)
    {
        *chip_id_out = chip_id;
    }

    /* Keep gate driver disabled while applying the static configuration. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_DISABLED);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_CHIP_IO_CONFIG,
                                      TMC6460_VALUE_CHIP_IO_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_ADC_CSA_GAIN,
                                      TMC6460_VALUE_MCC_ADC_CSA_GAIN);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_VELOCITY);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_PWM,
                                      TMC6460_VALUE_PWM_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_CONFIG,
                                      TMC6460_VALUE_PID_CONFIG);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_FLUX_COEFF,
                                      TMC6460_VALUE_FLUX_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_COEFF,
                                      TMC6460_VALUE_TORQUE_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_COEFF,
                                      TMC6460_VALUE_VELOCITY_COEFF);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_UQ_UD_LIMITS,
                                      TMC6460_VALUE_UQ_UD_LIMITS);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(profile->run_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_LIMIT,
                                      (uint32_t)profile->maximum_velocity_raw);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_A,
                                      TMC6460_VALUE_FEEDBACK_CH_A);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_B,
                                      TMC6460_VALUE_FEEDBACK_CH_B);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_FEEDBACK_CONFIG_VELOCITY,
                                      TMC6460_VALUE_FEEDBACK_VELOCITY);
    if (status != TMC6460_OK) return status;

    /* Explicitly command zero speed before enabling the gate driver. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      0U);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_GDRV,
                                      TMC6460_VALUE_GDRV_ENABLED);
    if (status != TMC6460_OK) return status;

    motor->driver_enabled = 1U;

    /* Match the Qt end state: velocity mode, zero target, non-zero run limit. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      0U);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadChipID(motor->device, &chip_id);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if (chip_id != expected_chip_id)
    {
        return TMC6460_INVALID_CHIP_ID;
    }

    motor->initialized = 1U;
    motor->commanded_velocity_raw = 0;
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_MotorSetVelocity(tmc6460_motor_t *motor,
                                          int32_t velocity_raw)
{
    tmc6460_status_t status;
    int32_t limit;

    if ((motor == NULL) || (motor->device == NULL) ||
        (motor->profile == NULL) || (motor->initialized == 0U))
    {
        return TMC6460_INVALID_PARAM;
    }

    if (velocity_raw == 0)
    {
        return TMC6460_MotorStopHold(motor);
    }

    limit = motor->profile->maximum_velocity_raw;
    if (TMC6460_MotorAbs32(velocity_raw) > limit)
    {
        velocity_raw = (velocity_raw > 0) ? limit : -limit;
    }

    status = TMC6460_MotorEnsureDriverEnabled(motor);
    if (status != TMC6460_OK) return status;

    /* Qt core logic applies run torque/flux ceiling before every non-zero run. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(
                                          motor->profile->run_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_VELOCITY);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      (uint32_t)velocity_raw);
    if (status == TMC6460_OK)
    {
        motor->commanded_velocity_raw = velocity_raw;
    }

    return status;
}

tmc6460_status_t TMC6460_MotorRunCW(tmc6460_motor_t *motor)
{
    if ((motor == NULL) || (motor->profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    return TMC6460_MotorSetVelocity(motor,
                                    TMC6460_MotorAbs32(
                                        motor->profile->default_velocity_raw));
}

tmc6460_status_t TMC6460_MotorRunCCW(tmc6460_motor_t *motor)
{
    if ((motor == NULL) || (motor->profile == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    return TMC6460_MotorSetVelocity(motor,
                                    -TMC6460_MotorAbs32(
                                        motor->profile->default_velocity_raw));
}

tmc6460_status_t TMC6460_MotorStopHold(tmc6460_motor_t *motor)
{
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) ||
        (motor->profile == NULL) || (motor->initialized == 0U))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_MotorEnsureDriverEnabled(motor);
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS,
                                      TMC6460_MotorPackLimit(
                                          motor->profile->hold_torque_flux_limit_raw));
    if (status != TMC6460_OK) return status;

    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_MCC_CONFIG_MOTOR_MOTION,
                                      TMC6460_VALUE_MOTOR_MOTION_VELOCITY);
    if (status != TMC6460_OK) return status;

    /* Deliberately no FOC_PID_TORQUE_FLUX_TARGET=0 write here. */
    status = TMC6460_MotorWriteConfig(motor,
                                      TMC6460_REG_FOC_PID_VELOCITY_TARGET,
                                      0U);
    if (status == TMC6460_OK)
    {
        motor->commanded_velocity_raw = 0;
    }

    return status;
}

tmc6460_status_t TMC6460_MotorReadPosition(tmc6460_motor_t *motor,
                                           int32_t *position_raw)
{
    uint32_t value;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (position_raw == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_POSITION_ACTUAL,
                                  &value);
    if (status == TMC6460_OK)
    {
        *position_raw = (int32_t)value;
    }

    return status;
}

tmc6460_status_t TMC6460_MotorReadFeedback(tmc6460_motor_t *motor,
                                           tmc6460_feedback_t *feedback)
{
    uint32_t value;
    tmc6460_status_t status;

    if ((motor == NULL) || (motor->device == NULL) || (feedback == NULL))
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_STATUS_FLAGS,
                                  &feedback->chip_status_flags);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_CHIP_EVENTS,
                                  &feedback->chip_events);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_VELOCITY_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->velocity_actual_raw = (int32_t)value;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_POSITION_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->position_actual_raw = (int32_t)value;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_TORQUE_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->torque_actual_raw = (int32_t)value;

    status = TMC6460_ReadRegister(motor->device,
                                  TMC6460_REG_FOC_PID_FLUX_ACTUAL,
                                  &value);
    if (status != TMC6460_OK) return status;
    feedback->flux_actual_raw = (int32_t)value;

    return TMC6460_OK;
}
