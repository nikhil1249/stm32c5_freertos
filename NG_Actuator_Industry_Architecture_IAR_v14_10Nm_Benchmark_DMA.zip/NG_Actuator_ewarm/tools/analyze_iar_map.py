#!/usr/bin/env python3
"""Small IAR .map analyzer for NG_Actuator.
Usage: python analyze_iar_map.py path/to/NG_Actuator.map
"""
import re, sys, json
from pathlib import Path

def num(s):
    return int(s.replace(',',''))

def main():
    if len(sys.argv) < 2:
        print('Usage: analyze_iar_map.py <file.map> [out.json]')
        return 2
    path=Path(sys.argv[1])
    text=path.read_text(errors='ignore')
    result={'map_file':str(path)}
    # Common IAR summary: "Grand Total:  30 808  1 337  27 054"
    m=re.search(r'Grand Total:\s*([0-9, ]+)\s+([0-9, ]+)\s+([0-9, ]+)', text)
    if m:
        vals=[num(x) for x in m.groups()]
        result['ro_code_bytes'],result['ro_data_bytes'],result['rw_data_bytes']=vals
        result['flash_image_bytes']=vals[0]+vals[1]
        result['ram_link_bytes']=vals[2]
    else:
        # Alternate line-oriented IAR summaries.
        for key,label in [('ro_code_bytes','ro code'),('ro_data_bytes','ro data'),('rw_data_bytes','rw data')]:
            mm=re.search(r'([0-9][0-9,]*)\s+bytes?\s+'+re.escape(label), text, re.I)
            if mm: result[key]=num(mm.group(1))
        if 'ro_code_bytes' in result:
            result['flash_image_bytes']=result.get('ro_code_bytes',0)+result.get('ro_data_bytes',0)
        if 'rw_data_bytes' in result: result['ram_link_bytes']=result['rw_data_bytes']
    # Project hardware capacities.
    result['flash_capacity_bytes']=512*1024
    result['ram_capacity_bytes']=128*1024
    if 'flash_image_bytes' in result:
        result['flash_percent']=round(100*result['flash_image_bytes']/result['flash_capacity_bytes'],2)
        result['flash_free_bytes']=result['flash_capacity_bytes']-result['flash_image_bytes']
    if 'ram_link_bytes' in result:
        result['ram_percent']=round(100*result['ram_link_bytes']/result['ram_capacity_bytes'],2)
        result['ram_free_bytes']=result['ram_capacity_bytes']-result['ram_link_bytes']

    print('\nIAR MEMORY SUMMARY')
    print('------------------')
    for k in ['ro_code_bytes','ro_data_bytes','rw_data_bytes','flash_image_bytes','flash_percent','ram_link_bytes','ram_percent']:
        if k in result: print(f'{k:22s}: {result[k]}')
    print('\nNote: rw_data includes statically reserved FreeRTOS heap. Runtime command M shows actual heap consumption and stack high-water marks.')
    if len(sys.argv)>2:
        Path(sys.argv[2]).write_text(json.dumps(result,indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())
