# Build and first motor test

1. Open `NG_Actuator.eww` in IAR Embedded Workbench.
2. Select the Debug configuration.
3. Project -> Rebuild All.
4. Flash the NUCLEO-C562RE.
5. Open the ST-LINK Virtual COM port at **115200, 8-N-1**.
6. Power the TMC6460/motor using the already-validated wiring and a conservative
   current limit.
7. Send `A`, `B`, or `C`. Wait for the periodic status to show `init=1` and
   `tmc=0`.
8. Send `V` for CW, `W` for CCW, and `Z` for controlled zero-speed hold.

Current verified profile mapping:

| Command | Profile | Run limit | Hold limit | Max torque/flux ceiling | Basic velocity |
|---|---:|---:|---:|---:|---:|
| A | 10 kg | 1000 | 1200 | 1200 | 1,000,000 |
| B | 20 kg | 1500 | 1500 | 2000 | 1,000,000 |
| C | 35 kg | 2500 | 2000 | 2500 | 1,000,000 |

`D`/`E` are intentionally not assigned unverified motor parameters.

The basic bring-up does not yet automatically stop at the mechanical end. Use
`Z` before reaching the end during the first test. End-stop/stall logic should be
ported only after CW/CCW/hold and position feedback are confirmed.

## v5 UART write-response fix

The TMC6460 enables UART RTMI channel 7 after reset, so a normal register write
returns a 5-byte response. The direct STM32 transport must consume this reply.
Leaving it unread causes the next register read (for example CHIP_ID or
POSITION_ACTUAL) to start with stale write-response bytes and can produce UART
overrun/TMC errors. `TMC6460_WriteRegister()` now uses `UART_IF_WriteRead()` to
receive and validate the 5-byte response for every write.

## v6 TMC6460 Rev.0 register-map correction

This build corrects the released TMC6460 Rev.0 register map and the digital-Hall
feedback path used by the STM32 port.

Key corrections:
- CHIP.STATUS_FLAGS = 0x009, CHIP.EVENTS = 0x00A.
- FOC.PID_TORQUE_FLUX_ACTUAL = 0x153.
- FOC.PID_VELOCITY_ACTUAL = 0x154.
- FOC.PID_POSITION_ACTUAL = 0x155.
- FEEDBACK.PHI_E_OFFSET = 0x242 (do not write velocity filter data here).
- Added Hall mapping, velocity meter configuration and FEEDBACK.OUTPUT_CONF.
- Channel A is used for Hall electrical angle (phi_e).
- Channel B uses HALL_FREE and is selected for velocity and position.
- Initialization verifies HALL.DIG_COUNT and real GDRV_ON_STATE.

Debug terminal status fields:
- hall must be 1..6 when the shaft is rotated.
- drvOn must be 1 before V/W is accepted successfully.
- tmc=7 means the TMC power stage did not enter driver-on state.
- tmc=8 means an invalid Hall state (000/111) was detected.
- R requests an immediate diagnostic snapshot.

## Rev.0 v7 bring-up notes

This project targets the released TMC6460 Rev.0 register map (May 2026).

Key corrections in v7:

- Closed-loop velocity mode uses `MCC_CONFIG.MOTOR_MOTION = 0x00000786` for
  BLDC, six pole-pairs, `MOTION_MODE=VELOCITY`, ramper disabled, and feedback
  `PHI_E` selected by `FEEDBACK.OUTPUT_CONF`.
- `HALL.DIG_COUNT` is treated as a decoded Hall sector `0..5`, not as the raw
  three-bit Hall pin pattern.
- `CHIP.INPUTS_RAW` is used to observe both physical and post-processing Hall
  levels. `000` and `111` are rejected as invalid Hall states.
- `CHIP.IO_MATRIX=0` and `CHIP.IO_PU_PD=0x075800FF` are explicitly written so
  the Hall pin routing and pull-ups do not depend on previous tool sessions.
- Diagnostics show `hallRaw`, `hallLog`, `hallSec`, `hallEvt`, `fbB`, `inRaw`,
  `motion`, and the existing drive/status values.

First hardware test after flashing:

1. Power-cycle the TMC6460 and STM32 board.
2. Send `A` on the debug UART.
3. Before sending `V` or `W`, rotate the motor shaft by hand and use `R` to
   refresh diagnostics. `hallRaw`/`hallLog` must never be permanently `0` or
   `7`, `hallSec` must move through `0..5`, and position/`fbB` must change.
4. Verify `motion=0x00000786` and `drvOn=1`.
5. Only then test `V`, `Z`, and `W` with a current-limited supply.
