#include "app.h"
#include "actuator_calibration.h"
#include "actuator_soft_stall.h"
#include "actuator_reference.h"
#include "bsp.h"
#include "hardware_config.h"
#include "tmc6460_motor.h"
#include "uart_iface.h"
#include "runtime_memory.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#include <stdio.h>
#include <string.h>

#define APP_FEEDBACK_REFRESH_POSITION_SAMPLES    256U

/* Return the next RTOS period for a requested sample rate that is not an
 * integer divisor of the RTOS tick. At 1000 Hz tick / 400 Hz sampling this
 * produces 2,3,2,3,... ticks, i.e. 2.5 ms average. */
static TickType_t APP_NextPositionPeriodTicks(uint32_t *phase)
{
    uint32_t total;
    TickType_t ticks;

    if (phase == NULL)
    {
        return (TickType_t)1U;
    }

    total = *phase + HW_RTOS_TICK_RATE_HZ;
    ticks = (TickType_t)(total / HW_TMC_POSITION_SAMPLE_RATE_HZ);
    *phase = total % HW_TMC_POSITION_SAMPLE_RATE_HZ;

    if (ticks == (TickType_t)0U)
    {
        ticks = (TickType_t)1U;
    }

    return ticks;
}

typedef enum
{
    APP_CMD_SELECT_PROFILE = 0,
    APP_CMD_RUN_CW,
    APP_CMD_RUN_CCW,
    APP_CMD_STOP_HOLD,
    APP_CMD_REFRESH_DIAGNOSTICS,
    APP_CMD_AUTO_CALIBRATE,
    APP_CMD_SOFT_CW,
    APP_CMD_SOFT_CCW
} app_command_type_t;

typedef struct
{
    app_command_type_t type;
    actuator_type_t actuator_type;
} app_motor_command_t;

static tmc6460_t s_tmc_device;
static tmc6460_motor_t s_motor;
static QueueHandle_t s_motor_command_queue;

static actuator_calibration_result_t s_calibration_result;
static actuator_reference_t s_actuator_reference;
static volatile uint8_t s_calibration_abort_requested = 0U;

static actuator_soft_stall_result_t s_soft_stall_result;
static volatile uint8_t s_soft_stall_abort_requested = 0U;

volatile app_status_t g_app_status = { 0 };

/* FreeRTOS stack-overflow diagnostics. configCHECK_FOR_STACK_OVERFLOW=2. */
volatile uint32_t g_freertos_stack_overflow_detected = 0U;
volatile TaskHandle_t g_freertos_stack_overflow_task = NULL;

/* Do not place a large printf buffer on the MotorService task stack. The soft
 * progress callback is called synchronously from the high-priority motor task.
 * It is the only writer of this buffer, so static storage is safe here. */
static char s_soft_progress_message[280];

/* Calibration logging also executes from MotorServiceTask. Keep these buffers
 * out of the task stack so G uses essentially the same stack depth as the
 * proven v11.1 calibration engine. */
static char s_cal_progress_message[192];
static char s_cal_define_message[256];
static TickType_t s_cal_last_alive_tick = 0U;

static void APP_UpdateMotorStackWatermark(void)
{
    UBaseType_t stack_free_words = uxTaskGetStackHighWaterMark(NULL);

    g_app_status.motor_stack_min_free_words = (uint32_t)stack_free_words;
    g_app_status.motor_stack_margin_low =
        (stack_free_words < (UBaseType_t)HW_TASK_MOTOR_STACK_WARN_WORDS) ? 1U : 0U;
}

static void APP_DebugWrite(const char *text)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    if (text != NULL)
    {
        (void)UART_IF_Write(UART_IF_PORT_DEBUG,
                            (const uint8_t *)text,
                            (uint32_t)strlen(text),
                            HW_DEBUG_UART_TIMEOUT_MS);
    }
#else
    (void)text;
#endif
}

static void APP_UpdateAngleFromPosition(int32_t position_raw)
{
    if (s_actuator_reference.runtime_anchor_valid != 0U)
    {
        g_app_status.angle_deg_x100 =
            ActuatorReference_PositionToDegX100(&s_actuator_reference,
                                                position_raw);
    }
    else
    {
        g_app_status.angle_deg_x100 = 0;
    }
}

static void APP_UpdateReferenceStatus(void)
{
    g_app_status.calibration_params_loaded =
        s_actuator_reference.calibration_available;
    g_app_status.position_reference_valid =
        s_actuator_reference.runtime_anchor_valid;
    g_app_status.reference_zero_raw =
        s_actuator_reference.runtime_zero_raw;
    g_app_status.reference_ninety_raw =
        s_actuator_reference.runtime_ninety_raw;

    g_app_status.calibration_valid =
        s_actuator_reference.calibration_available;
    g_app_status.calibration_stroke_counts =
        s_actuator_reference.stroke_counts;

    if (s_actuator_reference.runtime_anchor_valid != 0U)
    {
        g_app_status.calibration_zero_raw =
            s_actuator_reference.runtime_zero_raw;
        g_app_status.calibration_ninety_raw =
            s_actuator_reference.runtime_ninety_raw;
        g_app_status.calibration_stroke_signed_counts =
            s_actuator_reference.direction_sign *
            (int32_t)s_actuator_reference.stroke_counts;
    }
}

static void APP_SetCommandResult(tmc6460_status_t status,
                                 app_motor_state_t success_state,
                                 int32_t commanded_velocity)
{
    taskENTER_CRITICAL();
    g_app_status.tmc_status = status;
    g_app_status.command_count++;

    if (status == TMC6460_OK)
    {
        g_app_status.motor_state = success_state;
        g_app_status.commanded_velocity_raw = commanded_velocity;
    }
    else
    {
        g_app_status.motor_state = APP_MOTOR_STATE_ERROR;
        g_app_status.command_error_count++;
    }
    taskEXIT_CRITICAL();
}

static tmc6460_status_t APP_RefreshTmcFeedback(void)
{
    tmc6460_feedback_t feedback;
    tmc6460_status_t status;

    memset(&feedback, 0, sizeof(feedback));
    status = TMC6460_MotorReadFeedback(&s_motor, &feedback);

    taskENTER_CRITICAL();
    g_app_status.tmc_status = status;
    if (status == TMC6460_OK)
    {
        g_app_status.chip_status_flags = feedback.chip_status_flags;
        g_app_status.chip_events = feedback.chip_events;
        g_app_status.gate_driver_config = feedback.gate_driver_config;
        g_app_status.motor_motion_config = feedback.motor_motion_config;
        g_app_status.feedback_output_config = feedback.feedback_output_config;
        g_app_status.chip_inputs_raw = feedback.chip_inputs_raw;
        g_app_status.hall_raw = feedback.hall_raw;
        g_app_status.hall_logic = feedback.hall_logic;
        g_app_status.hall_count = feedback.hall_count;
        g_app_status.hall_events = feedback.hall_events;
        g_app_status.feedback_ch_b_raw = feedback.feedback_ch_b_raw;
        g_app_status.phi_e_raw = feedback.phi_e_raw;
        g_app_status.velocity_target_readback_raw = feedback.velocity_target_raw;
        g_app_status.velocity_actual_raw = feedback.velocity_actual_raw;
        g_app_status.position_raw = feedback.position_actual_raw;
        g_app_status.torque_actual_raw = feedback.torque_actual_raw;
        g_app_status.flux_actual_raw = feedback.flux_actual_raw;
        APP_UpdateAngleFromPosition(feedback.position_actual_raw);
    }
    else
    {
        g_app_status.diagnostic_error_count++;
    }
    taskEXIT_CRITICAL();

    return status;
}

static void APP_PrintCalibrationDefines(const actuator_profile_t *profile,
                                        const actuator_calibration_result_t *result)
{
    char *message = s_cal_define_message;
    const char *prefix;

    if ((profile == NULL) || (result == NULL) || (result->valid == 0U))
    {
        return;
    }

    switch (profile->type)
    {
        case ACTUATOR_TYPE_10KG:
            prefix = "10KG";
            break;

        case ACTUATOR_TYPE_20KG:
            prefix = "20KG";
            break;

        case ACTUATOR_TYPE_35KG:
            prefix = "35KG";
            break;

        default:
            prefix = "UNKNOWN";
            break;
    }

    APP_DebugWrite("\r\n=== CALIBRATION RESULT - COPY TO actuator_calibration_config.h ===\r\n");

    (void)snprintf(message,
                   sizeof(s_cal_define_message),
                   "#define ACT_CAL_%s_VALID 1U\r\n",
                   prefix);
    APP_DebugWrite(message);

    (void)snprintf(message,
                   sizeof(s_cal_define_message),
                   "#define ACT_CAL_%s_ZERO_RAW_REFERENCE %ldL\r\n",
                   prefix,
                   (long)result->zero_raw);
    APP_DebugWrite(message);

    (void)snprintf(message,
                   sizeof(s_cal_define_message),
                   "#define ACT_CAL_%s_NINETY_RAW_REFERENCE %ldL\r\n",
                   prefix,
                   (long)result->ninety_raw);
    APP_DebugWrite(message);

    (void)snprintf(message,
                   sizeof(s_cal_define_message),
                   "#define ACT_CAL_%s_STROKE_COUNTS %luUL\r\n",
                   prefix,
                   (unsigned long)result->stroke_counts);
    APP_DebugWrite(message);

    (void)snprintf(message,
                   sizeof(s_cal_define_message),
                   "#define ACT_CAL_%s_DIRECTION_SIGN %ldL\r\n",
                   prefix,
                   (long)result->direction_sign);
    APP_DebugWrite(message);

    APP_DebugWrite("NOTE: ZERO/NINETY raw are current-session references. Re-home after power-up; stroke counts are reusable.\r\n"
                   "===================================================================\r\n\r\n");
}

static void APP_CalibrationProgress(
    const actuator_calibration_progress_t *progress,
    void *context)
{
    char *message = s_cal_progress_message;
    const actuator_profile_t *profile = (const actuator_profile_t *)context;

    if (progress == NULL)
    {
        return;
    }

    /* Calibration callbacks execute on MotorServiceTask. Track remaining stack
     * during G as well, not only between normal 400 Hz samples. */
    APP_UpdateMotorStackWatermark();

    taskENTER_CRITICAL();
    g_app_status.calibration_status = (uint32_t)progress->status;
    g_app_status.calibration_iteration = progress->iteration;

    if (progress->event == ACTUATOR_CAL_EVENT_SAMPLE)
    {
        g_app_status.position_raw = progress->position_raw;
        g_app_status.velocity_actual_raw = progress->velocity_raw;
        g_app_status.torque_actual_raw = progress->torque_raw;
        g_app_status.position_sample_count++;
        APP_UpdateAngleFromPosition(progress->position_raw);
    }
    else if (progress->event == ACTUATOR_CAL_EVENT_ZERO_FOUND)
    {
        g_app_status.calibration_zero_raw = progress->position_raw;
    }
    else if (progress->event == ACTUATOR_CAL_EVENT_NINETY_FOUND)
    {
        g_app_status.calibration_ninety_raw = progress->position_raw;
    }
    taskEXIT_CRITICAL();

    switch (progress->event)
    {
        case ACTUATOR_CAL_EVENT_START:
            s_cal_last_alive_tick = xTaskGetTickCount();
            APP_DebugWrite("CAL: START - low-speed hard-end calibration\r\n");
            break;

        case ACTUATOR_CAL_EVENT_HOMING_ZERO:
            APP_DebugWrite("CAL: HOMING CCW -> physical 0 deg (if already at 0deg there may be no visible motion)\r\n");
            break;

        case ACTUATOR_CAL_EVENT_ZERO_FOUND:
            if (progress->iteration == 0U)
            {
                (void)snprintf(message,
                               sizeof(s_cal_progress_message),
                               "CAL: HOME 0deg found pos=%ld\r\n",
                               (long)progress->position_raw);
            }
            else
            {
                (void)snprintf(message,
                               sizeof(s_cal_progress_message),
                               "CAL: ITER %lu 0deg pos=%ld\r\n",
                               (unsigned long)progress->iteration,
                               (long)progress->position_raw);
            }
            APP_DebugWrite(message);
            break;

        case ACTUATOR_CAL_EVENT_MOVE_TO_90:
            (void)snprintf(message,
                           sizeof(s_cal_progress_message),
                           "CAL: ITER %lu CW -> 90deg\r\n",
                           (unsigned long)progress->iteration);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_CAL_EVENT_NINETY_FOUND:
            (void)snprintf(message,
                           sizeof(s_cal_progress_message),
                           "CAL: ITER %lu 90deg pos=%ld\r\n",
                           (unsigned long)progress->iteration,
                           (long)progress->position_raw);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_CAL_EVENT_MOVE_TO_ZERO:
            (void)snprintf(message,
                           sizeof(s_cal_progress_message),
                           "CAL: ITER %lu CCW -> 0deg\r\n",
                           (unsigned long)progress->iteration);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_CAL_EVENT_ANALYZE:
            APP_DebugWrite("CAL: ANALYZING endpoint repeatability\r\n");
            break;

        case ACTUATOR_CAL_EVENT_COMPLETE:
            (void)snprintf(message,
                           sizeof(s_cal_progress_message),
                           "CAL: COMPLETE - actuator is held at 0deg (TMC retries=%lu)\r\n",
                           (unsigned long)ActuatorCalibration_GetTmcRetryCount());
            APP_DebugWrite(message);
            if (profile != NULL)
            {
                APP_PrintCalibrationDefines(profile, &s_calibration_result);
            }
            break;

        case ACTUATOR_CAL_EVENT_ABORTED:
            APP_DebugWrite("CAL: ABORTED - motor returned to HOLD\r\n");
            break;

        case ACTUATOR_CAL_EVENT_ERROR:
            (void)snprintf(message,
                           sizeof(s_cal_progress_message),
                           "CAL: ERROR status=%u lastTmc=%u retries=%lu - motor returned to HOLD\r\n",
                           (unsigned int)progress->status,
                           (unsigned int)ActuatorCalibration_GetLastTmcError(),
                           (unsigned long)ActuatorCalibration_GetTmcRetryCount());
            APP_DebugWrite(message);
            break;

        case ACTUATOR_CAL_EVENT_SAMPLE:
            if ((xTaskGetTickCount() - s_cal_last_alive_tick) >=
                pdMS_TO_TICKS(ACTUATOR_CALIBRATION_PROGRESS_PRINT_MS))
            {
                s_cal_last_alive_tick = xTaskGetTickCount();
                (void)snprintf(message, sizeof(s_cal_progress_message),
                               "CAL: RUN it=%lu pos=%ld vel=%ld tq=%ld\r\n",
                               (unsigned long)progress->iteration,
                               (long)progress->position_raw,
                               (long)progress->velocity_raw,
                               (long)progress->torque_raw);
                APP_DebugWrite(message);
            }
            break;

        default:
            break;
    }
}

static int32_t APP_GetSoftCreepVelocityForProfile(actuator_type_t type)
{
    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            return (int32_t)ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW;
        case ACTUATOR_TYPE_20KG:
            return (int32_t)ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW;
        case ACTUATOR_TYPE_35KG:
            return (int32_t)ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW;
        default:
            return 0;
    }
}

static void APP_PrintSoftStallConfig(void)
{
    char message[420];
    const actuator_profile_t *profile;
    int32_t creep_velocity;

    profile = ActuatorProfile_Get(g_app_status.actuator_type);
    creep_velocity = (profile != NULL) ?
        APP_GetSoftCreepVelocityForProfile(profile->type) : 0;

    (void)snprintf(message,
                   sizeof(message),
                   "SOFT CFG: sample=%luHz depart=%lu.%02lu%% creepStart=%lu.%02lu%% contactArm=%lu.%02lu%% "
                   "cruise=%lu%% creep=%ld raw boostStep=%ld boostMax=%ld "
                   "contact=%lums overshoot=%lu.%02lu%%\r\n",
                   (unsigned long)ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ,
                   (unsigned long)(ACTUATOR_SOFT_STALL_DEPARTURE_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_DEPARTURE_PERCENT_X100 % 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 % 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 % 100U),
                   (unsigned long)ACTUATOR_SOFT_STALL_CRUISE_VELOCITY_PERCENT,
                   (long)creep_velocity,
                   (long)ACTUATOR_SOFT_STALL_CREEP_BOOST_STEP_RAW,
                   (long)ACTUATOR_SOFT_STALL_CREEP_BOOST_MAX_RAW,
                   (unsigned long)ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS,
                   (unsigned long)(ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 % 100U));
    APP_DebugWrite(message);

    if (s_actuator_reference.calibration_available != 0U)
    {
        (void)snprintf(message,
                       sizeof(message),
                       "SOFT CAL: STORED VALID stroke=%lu dirSign=%ld anchor=%u "
                       "session0=%ld session90=%ld | X/Y enabled immediately. "
                       "If anchor=0 the first X/Y performs soft reference search.\r\n",
                       (unsigned long)s_actuator_reference.stroke_counts,
                       (long)s_actuator_reference.direction_sign,
                       (unsigned int)s_actuator_reference.runtime_anchor_valid,
                       (long)s_actuator_reference.runtime_zero_raw,
                       (long)s_actuator_reference.runtime_ninety_raw);
    }
    else
    {
        (void)snprintf(message,
                       sizeof(message),
                       "SOFT CAL: NO STORED PARAMETERS. Run G once, copy printed "
                       "ACT_CAL_x_* macros into actuator_calibration_config.h and rebuild.\r\n");
    }
    APP_DebugWrite(message);
}

static void APP_SoftStallProgress(const actuator_soft_stall_progress_t *progress,
                                  void *context)
{
    char *message = s_soft_progress_message;
    const char *dir_name;
    const actuator_profile_t *profile = (const actuator_profile_t *)context;

    if (progress == NULL)
    {
        return;
    }

    dir_name = (progress->direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ?
        "CW" : "CCW";

    taskENTER_CRITICAL();
    g_app_status.soft_stall_status = (uint32_t)progress->status;
    g_app_status.soft_stall_stage = (uint32_t)progress->stage;
    g_app_status.soft_stall_direction = (int32_t)progress->direction;
    g_app_status.soft_stall_creep_start_raw = progress->creep_start_raw;
    g_app_status.soft_stall_target_raw = progress->target_end_raw;
    g_app_status.soft_stall_distance_to_end = progress->distance_to_end_counts;
    g_app_status.soft_stall_retry_count = ActuatorSoftStall_GetTmcRetryCount();
    g_app_status.commanded_velocity_raw = progress->commanded_velocity_raw;

    if ((progress->event == ACTUATOR_SOFT_STALL_EVENT_CONTACT) ||
        (progress->event == ACTUATOR_SOFT_STALL_EVENT_REFERENCE_ESTABLISHED) ||
        (progress->event == ACTUATOR_SOFT_STALL_EVENT_COMPLETE))
    {
        g_app_status.soft_stall_contact_confirmed = 1U;
    }

    if (progress->stage == ACTUATOR_SOFT_STALL_STAGE_HOLD)
    {
        g_app_status.commanded_velocity_raw = 0;
    }

    if (progress->event == ACTUATOR_SOFT_STALL_EVENT_SAMPLE)
    {
        g_app_status.position_raw = progress->position_raw;
        g_app_status.velocity_actual_raw = progress->velocity_raw;
        g_app_status.torque_actual_raw = progress->torque_raw;
        g_app_status.position_sample_count++;
        APP_UpdateAngleFromPosition(progress->position_raw);
    }
    taskEXIT_CRITICAL();

    switch (progress->event)
    {
        case ACTUATOR_SOFT_STALL_EVENT_START:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: START %s pos=%ld creepAt=%ld target=%ld\r\n",
                           dir_name,
                           (long)progress->position_raw,
                           (long)progress->creep_start_raw,
                           (long)progress->target_end_raw);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_REFERENCE_SEARCH:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s FIRST-BOOT REFERENCE SEARCH vel=%ld - no G required\r\n",
                           dir_name,
                           (long)progress->commanded_velocity_raw);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_REFERENCE_ESTABLISHED:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s REFERENCE ESTABLISHED at pos=%ld -> HOLD\r\n",
                           dir_name,
                           (long)progress->position_raw);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_DEPARTURE:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s DEPARTURE vel=%ld for %lu.%02lu%% stroke, then cruise\r\n",
                           dir_name,
                           (long)progress->commanded_velocity_raw,
                           (unsigned long)(ACTUATOR_SOFT_STALL_DEPARTURE_PERCENT_X100 / 100U),
                           (unsigned long)(ACTUATOR_SOFT_STALL_DEPARTURE_PERCENT_X100 % 100U));
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_CRUISE:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s CRUISE active; creep at %lu.%02lu%% stroke\r\n",
                           dir_name,
                           (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 / 100U),
                           (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 % 100U));
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_CREEP:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s CREEP pos=%ld target=%ld vel=%ld; contact arms at %lu.%02lu%%\r\n",
                           dir_name,
                           (long)progress->position_raw,
                           (long)progress->target_end_raw,
                           (long)progress->commanded_velocity_raw,
                           (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 / 100U),
                           (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 % 100U));
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_CREEP_BOOST:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s PRE-END LOAD STALL -> creep boost to %ld raw\r\n",
                           dir_name,
                           (long)progress->commanded_velocity_raw);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_CONTACT:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s CONTACT pos=%ld dEnd=%ld posStable=%u velLow=%u -> HOLD\r\n",
                           dir_name,
                           (long)progress->position_raw,
                           (long)progress->distance_to_end_counts,
                           (unsigned int)progress->position_stable,
                           (unsigned int)progress->velocity_low);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_COMPLETE:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: %s COMPLETE final=%ld ref=%u retries=%lu boosts=%lu\r\n",
                           dir_name,
                           (long)s_soft_stall_result.final_position_raw,
                           (unsigned int)s_actuator_reference.runtime_anchor_valid,
                           (unsigned long)ActuatorSoftStall_GetTmcRetryCount(),
                           (unsigned long)s_soft_stall_result.creep_boost_count);
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_ABORTED:
            APP_DebugWrite("SOFT: ABORTED -> HOLD\r\n");
            break;

        case ACTUATOR_SOFT_STALL_EVENT_ERROR:
            (void)snprintf(message, sizeof(s_soft_progress_message),
                           "SOFT: ERROR status=%u lastTmc=%u retries=%lu -> HOLD\r\n",
                           (unsigned int)progress->status,
                           (unsigned int)ActuatorSoftStall_GetLastTmcError(),
                           (unsigned long)ActuatorSoftStall_GetTmcRetryCount());
            APP_DebugWrite(message);
            break;

        case ACTUATOR_SOFT_STALL_EVENT_SAMPLE:
        default:
            (void)profile;
            break;
    }
}

static void APP_ProcessMotorCommand(const app_motor_command_t *command)
{
    const actuator_profile_t *profile;
    tmc6460_status_t status;
    actuator_calibration_status_t cal_status;
    actuator_soft_stall_status_t soft_status;
    actuator_soft_stall_direction_t soft_direction;
    uint32_t chip_id = 0U;

    if (command == NULL)
    {
        return;
    }

    switch (command->type)
    {
        case APP_CMD_SELECT_PROFILE:
            profile = ActuatorProfile_Get(command->actuator_type);
            if (profile == NULL)
            {
                APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                     APP_MOTOR_STATE_ERROR,
                                     0);
                break;
            }

            if (s_motor.initialized != 0U)
            {
                (void)TMC6460_MotorStopHold(&s_motor);
            }

            status = TMC6460_MotorConfigure(&s_motor,
                                            &profile->motor,
                                            HW_TMC_EXPECTED_CHIP_ID,
                                            &chip_id);

            memset(&s_calibration_result, 0, sizeof(s_calibration_result));
            memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));
            ActuatorReference_Clear(&s_actuator_reference);
            if (status == TMC6460_OK)
            {
                (void)ActuatorReference_LoadCompileTime(command->actuator_type,
                                                        &s_actuator_reference);
            }
            s_soft_stall_abort_requested = 0U;

            taskENTER_CRITICAL();
            g_app_status.tmc_chip_id = chip_id;
            g_app_status.tmc_status = status;
            g_app_status.actuator_type = command->actuator_type;
            g_app_status.actuator_initialized =
                (status == TMC6460_OK) ? 1U : 0U;
            g_app_status.motor_state =
                (status == TMC6460_OK) ? APP_MOTOR_STATE_HOLD :
                                         APP_MOTOR_STATE_ERROR;
            g_app_status.commanded_velocity_raw = 0;
            g_app_status.calibration_active = 0U;
            g_app_status.calibration_valid =
                s_actuator_reference.calibration_available;
            g_app_status.calibration_status =
                (s_actuator_reference.calibration_available != 0U) ?
                    ACTUATOR_CAL_STATUS_OK :
                    ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
            g_app_status.calibration_iteration = 0U;
            g_app_status.calibration_zero_raw = 0;
            g_app_status.calibration_ninety_raw = 0;
            g_app_status.calibration_stroke_signed_counts =
                (s_actuator_reference.calibration_available != 0U) ?
                    (s_actuator_reference.direction_sign *
                     (int32_t)s_actuator_reference.stroke_counts) : 0;
            g_app_status.calibration_stroke_counts =
                s_actuator_reference.stroke_counts;
            g_app_status.calibration_params_loaded =
                s_actuator_reference.calibration_available;
            g_app_status.position_reference_valid = 0U;
            g_app_status.reference_zero_raw = 0;
            g_app_status.reference_ninety_raw = 0;
            g_app_status.calibration_zero_spread_counts = 0U;
            g_app_status.calibration_ninety_spread_counts = 0U;
            g_app_status.angle_deg_x100 = 0;
            g_app_status.soft_stall_active = 0U;
            g_app_status.soft_stall_contact_confirmed = 0U;
            g_app_status.soft_stall_status =
                (s_actuator_reference.calibration_available != 0U) ?
                    ACTUATOR_SOFT_STALL_STATUS_OK :
                    ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
            g_app_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;
    g_app_status.motor_stack_min_free_words = 0xFFFFFFFFUL;
    g_app_status.motor_stack_margin_low = 0U;
            g_app_status.soft_stall_direction = 0;
            g_app_status.soft_stall_creep_start_raw = 0;
            g_app_status.soft_stall_target_raw = 0;
            g_app_status.soft_stall_distance_to_end = 0;
            g_app_status.soft_stall_final_raw = 0;
            g_app_status.soft_stall_retry_count = 0U;
            g_app_status.soft_stall_creep_boost_count = 0U;
            g_app_status.soft_stall_reference_search_used = 0U;
            g_app_status.command_count++;
            if (status != TMC6460_OK)
            {
                g_app_status.command_error_count++;
            }
            taskEXIT_CRITICAL();

            /* Even when configuration fails, read a snapshot so the debug
             * terminal shows Hall state / driver state / status flags. */
            (void)APP_RefreshTmcFeedback();

            if ((status == TMC6460_OK) &&
                (s_actuator_reference.calibration_available != 0U))
            {
                char cal_message[180];
                (void)snprintf(cal_message,
                               sizeof(cal_message),
                               "STORED CAL LOADED: stroke=%lu dir=%ld. X/Y enabled; first X/Y after reset will soft-reference the requested end.\r\n",
                               (unsigned long)s_actuator_reference.stroke_counts,
                               (long)s_actuator_reference.direction_sign);
                APP_DebugWrite(cal_message);
            }
            else if (status == TMC6460_OK)
            {
                APP_DebugWrite("NO STORED CAL: G is required once; paste printed ACT_CAL_x_* defines and rebuild.\r\n");
            }
            break;

        case APP_CMD_RUN_CW:
            status = TMC6460_MotorRunCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CW,
                                 (status == TMC6460_OK) ?
                                     s_motor.commanded_velocity_raw : 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_RUN_CCW:
            status = TMC6460_MotorRunCCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CCW,
                                 (status == TMC6460_OK) ?
                                     s_motor.commanded_velocity_raw : 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_STOP_HOLD:
            status = TMC6460_MotorStopHold(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_HOLD,
                                 0);
            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_REFRESH_DIAGNOSTICS:
            status = APP_RefreshTmcFeedback();
            taskENTER_CRITICAL();
            g_app_status.command_count++;
            if (status != TMC6460_OK)
            {
                g_app_status.command_error_count++;
            }
            taskEXIT_CRITICAL();
            break;

        case APP_CMD_AUTO_CALIBRATE:
            profile = ActuatorProfile_Get(command->actuator_type);
            if ((profile == NULL) || (s_motor.initialized == 0U))
            {
                taskENTER_CRITICAL();
                g_app_status.calibration_status =
                    ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
                g_app_status.command_error_count++;
                g_app_status.command_count++;
                taskEXIT_CRITICAL();
                break;
            }

            /* G always means a fresh full calibration, irrespective of any
             * stored ACT_CAL_x_* parameters. It must never be blocked by the
             * persistent-reference feature added in v13. */
            s_calibration_abort_requested = 0U;
            s_soft_stall_abort_requested = 0U;
            memset(&s_calibration_result, 0, sizeof(s_calibration_result));

            APP_DebugWrite("CAL: COMMAND STARTED - running full G calibration\r\n");
            APP_UpdateMotorStackWatermark();

            taskENTER_CRITICAL();
            g_app_status.calibration_active = 1U;
            g_app_status.calibration_valid = 0U;
            g_app_status.calibration_status = ACTUATOR_CAL_STATUS_OK;
            g_app_status.calibration_iteration = 0U;
            g_app_status.motor_state = APP_MOTOR_STATE_CALIBRATING;
            g_app_status.commanded_velocity_raw = 0;
            g_app_status.command_count++;
            taskEXIT_CRITICAL();

            cal_status = ActuatorCalibration_Run(&s_motor,
                                                 profile,
                                                 &s_calibration_abort_requested,
                                                 &s_calibration_result,
                                                 APP_CalibrationProgress,
                                                 (void *)profile);

            if ((cal_status == ACTUATOR_CAL_STATUS_OK) &&
                (s_calibration_result.valid != 0U))
            {
                ActuatorReference_UpdateFromCalibration(&s_actuator_reference,
                                                        &s_calibration_result);
            }

            taskENTER_CRITICAL();
            g_app_status.calibration_active = 0U;
            g_app_status.calibration_status = (uint32_t)cal_status;
            g_app_status.calibration_valid = s_calibration_result.valid;
            g_app_status.calibration_zero_raw = s_calibration_result.zero_raw;
            g_app_status.calibration_ninety_raw = s_calibration_result.ninety_raw;
            g_app_status.calibration_stroke_signed_counts =
                s_calibration_result.stroke_signed_counts;
            g_app_status.calibration_stroke_counts =
                s_calibration_result.stroke_counts;
            g_app_status.calibration_zero_spread_counts =
                s_calibration_result.zero_spread_counts;
            g_app_status.calibration_ninety_spread_counts =
                s_calibration_result.ninety_spread_counts;
            APP_UpdateReferenceStatus();
            g_app_status.soft_stall_status =
                (s_actuator_reference.calibration_available != 0U) ?
                    ACTUATOR_SOFT_STALL_STATUS_OK :
                    ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;

            if (cal_status == ACTUATOR_CAL_STATUS_OK)
            {
                g_app_status.motor_state = APP_MOTOR_STATE_HOLD;
                g_app_status.commanded_velocity_raw = 0;
            }
            else if (cal_status == ACTUATOR_CAL_STATUS_ABORTED)
            {
                g_app_status.motor_state = APP_MOTOR_STATE_HOLD;
                g_app_status.commanded_velocity_raw = 0;
            }
            else
            {
                g_app_status.motor_state = APP_MOTOR_STATE_ERROR;
                g_app_status.command_error_count++;
                if (cal_status == ACTUATOR_CAL_STATUS_TMC_ERROR)
                {
                    g_app_status.tmc_status = TMC6460_ERROR;
                }
            }
            taskEXIT_CRITICAL();

            (void)APP_RefreshTmcFeedback();
            break;

        case APP_CMD_SOFT_CW:
        case APP_CMD_SOFT_CCW:
            profile = ActuatorProfile_Get(command->actuator_type);
            if ((profile == NULL) || (s_motor.initialized == 0U))
            {
                taskENTER_CRITICAL();
                g_app_status.soft_stall_status =
                    ACTUATOR_SOFT_STALL_STATUS_NOT_INITIALIZED;
                g_app_status.command_count++;
                g_app_status.command_error_count++;
                taskEXIT_CRITICAL();
                break;
            }

            if (s_actuator_reference.calibration_available == 0U)
            {
                taskENTER_CRITICAL();
                g_app_status.soft_stall_status =
                    ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
                g_app_status.command_count++;
                g_app_status.command_error_count++;
                taskEXIT_CRITICAL();
                APP_DebugWrite("ERR: NO STORED CALIBRATION. RUN G ONCE, COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
                break;
            }

            soft_direction = (command->type == APP_CMD_SOFT_CW) ?
                ACTUATOR_SOFT_STALL_DIRECTION_CW :
                ACTUATOR_SOFT_STALL_DIRECTION_CCW;

            s_soft_stall_abort_requested = 0U;
            memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));

            taskENTER_CRITICAL();
            g_app_status.soft_stall_active = 1U;
            g_app_status.soft_stall_contact_confirmed = 0U;
            g_app_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_OK;
            g_app_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;
            g_app_status.soft_stall_direction = (int32_t)soft_direction;
            g_app_status.motor_state =
                (soft_direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ?
                    APP_MOTOR_STATE_SOFT_CW : APP_MOTOR_STATE_SOFT_CCW;
            g_app_status.command_count++;
            taskEXIT_CRITICAL();

            soft_status = ActuatorSoftStall_Run(&s_motor,
                                                 profile,
                                                 &s_actuator_reference,
                                                 soft_direction,
                                                 &s_soft_stall_abort_requested,
                                                 &s_soft_stall_result,
                                                 APP_SoftStallProgress,
                                                 (void *)profile);

            taskENTER_CRITICAL();
            g_app_status.soft_stall_active = 0U;
            g_app_status.soft_stall_status = (uint32_t)soft_status;
            g_app_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_HOLD;
            g_app_status.soft_stall_contact_confirmed =
                s_soft_stall_result.contact_confirmed;
            g_app_status.soft_stall_final_raw =
                s_soft_stall_result.final_position_raw;
            g_app_status.soft_stall_retry_count =
                s_soft_stall_result.tmc_retry_count;
            g_app_status.soft_stall_creep_boost_count =
                s_soft_stall_result.creep_boost_count;
            g_app_status.soft_stall_reference_search_used =
                s_soft_stall_result.reference_search_used;
            APP_UpdateReferenceStatus();
            (void)ActuatorReference_ToCalibrationResult(&s_actuator_reference,
                                                        &s_calibration_result);
            g_app_status.commanded_velocity_raw = 0;
            g_app_status.motor_state = APP_MOTOR_STATE_HOLD;

            if ((soft_status != ACTUATOR_SOFT_STALL_STATUS_OK) &&
                (soft_status != ACTUATOR_SOFT_STALL_STATUS_ABORTED))
            {
                g_app_status.command_error_count++;
            }

            if (soft_status == ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR)
            {
                g_app_status.tmc_status = ActuatorSoftStall_GetLastTmcError();
            }
            taskEXIT_CRITICAL();

            (void)APP_RefreshTmcFeedback();
            break;

        default:
            APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                 APP_MOTOR_STATE_ERROR,
                                 0);
            break;
    }
}

static BaseType_t APP_QueueCommand(app_command_type_t type,
                                   actuator_type_t actuator_type)
{
    app_motor_command_t command;

    command.type = type;
    command.actuator_type = actuator_type;

    return xQueueSend(s_motor_command_queue, &command, pdMS_TO_TICKS(20U));
}

int32_t APP_Init(void)
{
    memset((void *)&g_app_status, 0, sizeof(g_app_status));
    memset(&s_calibration_result, 0, sizeof(s_calibration_result));
    memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));
    ActuatorReference_Clear(&s_actuator_reference);

    g_app_status.tmc_status = TMC6460_ERROR;
    g_app_status.actuator_type = ACTUATOR_TYPE_10KG;
    g_app_status.motor_state = APP_MOTOR_STATE_NOT_INITIALIZED;
    g_app_status.calibration_status = ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
    g_app_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
    g_app_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;

    /* Transport-independent device context. UART/SPI selection is handled
     * by tmc6460_transport.c using hardware_config.h. */
    TMC6460_Init(&s_tmc_device,
                 HW_TMC_COMM_TIMEOUT_MS);

    TMC6460_MotorInitContext(&s_motor, &s_tmc_device);

    s_motor_command_queue = xQueueCreate(HW_MOTOR_COMMAND_QUEUE_LENGTH,
                                          sizeof(app_motor_command_t));
    if (s_motor_command_queue == NULL)
    {
        return -1;
    }

    return 0;
}

void APP_HeartbeatTask(void)
{
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        BSP_LED_Toggle();
        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_LED_PERIOD_MS));
    }
}

void APP_MotorServiceTask(void)
{
    app_motor_command_t command;
    tmc6460_status_t status;
    int32_t position_raw;
    uint32_t feedback_divider = 0U;
    uint32_t sample_phase = 0U;
    TickType_t last_sample_wake;
    TickType_t sample_period_ticks;

    vTaskDelay(pdMS_TO_TICKS(HW_TMC_STARTUP_DELAY_MS));
    last_sample_wake = xTaskGetTickCount();

    for (;;)
    {
        APP_UpdateMotorStackWatermark();

        /* Single-owner rule: only MotorServiceTask accesses the TMC6460
         * transport. Process all queued commands before the next sample. */
        while (xQueueReceive(s_motor_command_queue,
                             &command,
                             (TickType_t)0U) == pdPASS)
        {
            APP_ProcessMotorCommand(&command);

            /* A configuration, calibration or motion command can take time.
             * Restart periodic sampling so vTaskDelayUntil() never catches up
             * against an old schedule. */
            last_sample_wake = xTaskGetTickCount();
            sample_phase = 0U;
        }

        if (s_motor.initialized != 0U)
        {
            position_raw = 0;
            status = TMC6460_MotorReadPosition(&s_motor, &position_raw);

            taskENTER_CRITICAL();
            g_app_status.tmc_status = status;
            if (status == TMC6460_OK)
            {
                g_app_status.position_raw = position_raw;
                g_app_status.position_sample_count++;
                APP_UpdateAngleFromPosition(position_raw);
            }
            else
            {
                g_app_status.position_error_count++;
            }
            taskEXIT_CRITICAL();

            if (status == TMC6460_OK)
            {
                feedback_divider++;
                if (feedback_divider >= APP_FEEDBACK_REFRESH_POSITION_SAMPLES)
                {
                    feedback_divider = 0U;
                    (void)APP_RefreshTmcFeedback();
                }
            }

            /* v10.4 benchmark rule: explicit periodic block prevents the
             * priority-4 motor task from starving debug/diagnostic tasks when
             * SPI transfers complete very quickly. */
            sample_period_ticks = APP_NextPositionPeriodTicks(&sample_phase);
            vTaskDelayUntil(&last_sample_wake, sample_period_ticks);
        }
        else
        {
            /* No actuator initialized: sleep until a command arrives. */
            if (xQueueReceive(s_motor_command_queue,
                              &command,
                              portMAX_DELAY) == pdPASS)
            {
                APP_ProcessMotorCommand(&command);
                last_sample_wake = xTaskGetTickCount();
                sample_phase = 0U;
            }
        }
    }
}

void APP_DebugCommandTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    uint8_t ch;
    const actuator_profile_t *profile;

    if (UART_IF_StartBufferedRx(UART_IF_PORT_DEBUG) != UART_IF_OK)
    {
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }

    APP_DebugWrite("\r\nNG Actuator v14.1 - 10Nm DMA + soft departure fix\r\n"
                   "TMC interface: " HW_TMC_INTERFACE_NAME "\r\n"
                   "A=10Nm  B=20kg  C=35kg\r\n"
                   "V=CW(raw) W=CCW(raw) Z=STOP/HOLD G=AUTO CAL\r\n"
                   "X=SOFT CW->90 Y=SOFT CCW->0 P=SOFT CONFIG R=DIAG M=MEM ?=HELP\r\n"
                   "If ACT_CAL_x_VALID=1, X/Y work after reset; first X/Y softly anchors position.\r\n"
                   "Run motion mode = 0x00002786.\r\n");

    for (;;)
    {
        if (UART_IF_ReadBuffered(UART_IF_PORT_DEBUG,
                                 &ch,
                                 1U,
                                 1000U) == 0U)
        {
            continue;
        }

        if ((ch >= (uint8_t)'a') && (ch <= (uint8_t)'z'))
        {
            ch = (uint8_t)(ch - ((uint8_t)'a' - (uint8_t)'A'));
        }

        /* Long calibration/soft-stall operations execute synchronously in the
         * sole-owner MotorServiceTask. Z is therefore a direct abort flag and
         * must not be queued behind the active operation. */
        if ((g_app_status.calibration_active != 0U) ||
            (g_app_status.soft_stall_active != 0U))
        {
            if (ch == (uint8_t)'Z')
            {
                if (g_app_status.calibration_active != 0U)
                {
                    s_calibration_abort_requested = 1U;
                    APP_DebugWrite("CAL ABORT REQUESTED\r\n");
                }
                else
                {
                    s_soft_stall_abort_requested = 1U;
                    APP_DebugWrite("SOFT ABORT REQUESTED\r\n");
                }
            }
            else if (ch == (uint8_t)'P')
            {
                APP_PrintSoftStallConfig();
            }
            else if (ch == (uint8_t)'M')
            {
                runtime_memory_snapshot_t mem;
                char mem_message[360];
                int mem_len;
                RuntimeMemory_Get(&mem);
                mem_len = RuntimeMemory_FormatDetailed(mem_message, sizeof(mem_message), &mem);
                if (mem_len > 0) APP_DebugWrite(mem_message);
            }
            else if ((ch == (uint8_t)'?') || (ch == (uint8_t)'H'))
            {
                APP_DebugWrite("BUSY: Z=ABORT/HOLD, P=SOFT CONFIG. Other motor commands are locked.\r\n");
            }
            else if ((ch != (uint8_t)'\r') &&
                     (ch != (uint8_t)'\n') &&
                     (ch != (uint8_t)' '))
            {
                APP_DebugWrite("ERR: CAL/SOFT MOVE ACTIVE; Z=ABORT\r\n");
            }
            continue;
        }

        profile = ActuatorProfile_FromCommand((char)ch);
        if (profile != NULL)
        {
            if (APP_QueueCommand(APP_CMD_SELECT_PROFILE, profile->type) == pdPASS)
            {
                APP_DebugWrite("PROFILE INIT REQUESTED\r\n");
            }
            else
            {
                APP_DebugWrite("ERR: COMMAND QUEUE FULL\r\n");
            }
            continue;
        }

        switch (ch)
        {
            case (uint8_t)'V':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'W':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CCW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CCW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'Z':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_STOP_HOLD,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("STOP/HOLD REQUESTED\r\n");
                }
                break;

            case (uint8_t)'G':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_AUTO_CALIBRATE,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("AUTO CALIBRATION REQUESTED\r\n");
                }
                break;

            case (uint8_t)'X':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (g_app_status.calibration_params_loaded == 0U)
                {
                    APP_DebugWrite("ERR: NO STORED CAL PARAMS. RUN G ONCE, COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_SOFT_CW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("SOFT CW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'Y':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (g_app_status.calibration_params_loaded == 0U)
                {
                    APP_DebugWrite("ERR: NO STORED CAL PARAMS. RUN G ONCE, COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_SOFT_CCW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("SOFT CCW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'P':
                APP_PrintSoftStallConfig();
                break;

            case (uint8_t)'R':
                if (APP_QueueCommand(APP_CMD_REFRESH_DIAGNOSTICS,
                                     g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("DIAG REFRESH REQUESTED\r\n");
                }
                break;

            case (uint8_t)'M':
            {
                runtime_memory_snapshot_t mem;
                char mem_message[360];
                int mem_len;
                RuntimeMemory_Get(&mem);
                mem_len = RuntimeMemory_FormatDetailed(mem_message, sizeof(mem_message), &mem);
                if (mem_len > 0) APP_DebugWrite(mem_message);
                break;
            }

            case (uint8_t)'D':
            case (uint8_t)'E':
                APP_DebugWrite("D/E PROFILE RESERVED - ADD VALUES IN actuator_profile.c\r\n");
                break;

            case (uint8_t)'?':
            case (uint8_t)'H':
                APP_DebugWrite("A=10Nm B=20kg C=35kg | V/W=raw manual | Z=HOLD | G=CAL | R=DIAG\r\n"
                               "X=soft CW->90 Y=soft CCW->0 P=soft config M=memory.\r\n"
                               "Stored ACT_CAL_x_* enables X/Y after reset; first X/Y does low-speed reference search.\r\n"
                               "Then: CRUISE -> 98% CREEP -> 99.5% CONTACT ARM -> physical contact -> HOLD.\r\n"
                               "During G/X/Y, Z aborts and returns to non-zero-flux HOLD.\r\n");
                break;

            case (uint8_t)'\r':
            case (uint8_t)'\n':
            case (uint8_t)' ':
                break;

            default:
                APP_DebugWrite("ERR: UNKNOWN COMMAND\r\n");
                break;
        }
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(1000U));
    }
#endif
}

void APP_DiagnosticsTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    char message[260];
    int length;
    uint32_t last_sample_count = 0U;
    uint32_t current_sample_count;
    uint32_t sample_rate_hz;
    uint32_t driver_on;
    runtime_memory_snapshot_t mem;
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        current_sample_count = g_app_status.position_sample_count;
        sample_rate_hz = ((current_sample_count - last_sample_count) * 1000U) / HW_DIAG_PERIOD_MS;
        last_sample_count = current_sample_count;
        driver_on = ((g_app_status.chip_status_flags & TMC6460_STATUS_GDRV_ON_MASK) != 0U) ? 1U : 0U;
        RuntimeMemory_Get(&mem);

        /* Periodic logging is intentionally compact. Use R for controller
         * refresh and M for a detailed RTOS/DMA memory report. */
        length = snprintf(message, sizeof(message),
                          "STAT p=%u st=%u tmc=%u pos=%ld vel=%ld cmd=%ld drv=%lu "
                          "Hz=%lu cal=%u/%u ref=%u soft=%u/%lu err=%lu heap=%lu stkM=%lu\r\n",
                          (unsigned int)g_app_status.actuator_type,
                          (unsigned int)g_app_status.motor_state,
                          (unsigned int)g_app_status.tmc_status,
                          (long)g_app_status.position_raw,
                          (long)g_app_status.velocity_actual_raw,
                          (long)g_app_status.commanded_velocity_raw,
                          (unsigned long)driver_on,
                          (unsigned long)sample_rate_hz,
                          (unsigned int)g_app_status.calibration_valid,
                          (unsigned int)g_app_status.calibration_active,
                          (unsigned int)g_app_status.position_reference_valid,
                          (unsigned int)g_app_status.soft_stall_active,
                          (unsigned long)g_app_status.soft_stall_status,
                          (unsigned long)g_app_status.command_error_count,
                          (unsigned long)mem.heap_free_bytes,
                          (unsigned long)mem.motor_stack_free_words);

        if (length > 0)
        {
            uint32_t tx_length = (uint32_t)length;
            if (tx_length >= sizeof(message)) tx_length = (uint32_t)(sizeof(message) - 1U);
            (void)UART_IF_Write(UART_IF_PORT_DEBUG, (const uint8_t *)message, tx_length,
                                HW_DEBUG_UART_TIMEOUT_MS);
        }

        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#endif
}


/* FreeRTOS stack-overflow hook. In debug builds this is preferable to silent
 * stack corruption followed by an unrelated HardFault. Inspect the globals in
 * IAR Watch if execution stops here. */
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)pcTaskName;
    g_freertos_stack_overflow_detected = 1U;
    g_freertos_stack_overflow_task = xTask;
    taskDISABLE_INTERRUPTS();
    for (;;)
    {
        /* Breakpoint here during development. */
    }
}

uint32_t APP_GetMotorCommandQueueSpaces(void)
{
    if (s_motor_command_queue == NULL)
    {
        return 0U;
    }
    return (uint32_t)uxQueueSpacesAvailable(s_motor_command_queue);
}
