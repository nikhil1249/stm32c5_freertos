#ifndef BSP_H
#define BSP_H

#include "stm32_hal.h"
#include <stdint.h>

typedef enum
{
    BSP_OK = 0,
    BSP_ERROR
} bsp_status_t;

typedef enum
{
    BSP_UART_TMC = 0,
    BSP_UART_DEBUG,
    BSP_UART_COUNT
} bsp_uart_id_t;

bsp_status_t BSP_Init(void);

void BSP_LED_On(void);
void BSP_LED_Off(void);
void BSP_LED_Toggle(void);

hal_uart_handle_t *BSP_UART_GetHandle(bsp_uart_id_t id);

#endif /* BSP_H */
