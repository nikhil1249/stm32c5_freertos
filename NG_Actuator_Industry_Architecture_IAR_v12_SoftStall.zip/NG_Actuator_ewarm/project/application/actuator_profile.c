#include "actuator_profile.h"

#include <stddef.h>

/*
 * Values below are taken from the latest delivered Qt ActuatorConfig.h.
 * The basic manual velocity is 1,000,000 raw, which is also the Qt GUI's
 * default Direct Value. The benchmark STM32 build uses the validated TMC6460
 * velocity motion value 0x00002786. The profile maximum remains 1,500,000 raw
 * unless intentionally retuned for a specific actuator.
 *
 * Add future actuator types only in this table + enum. The command and motor
 * service layers do not need to change.
 */
static const actuator_profile_t s_profiles[ACTUATOR_TYPE_COUNT] =
{
    {
        ACTUATOR_TYPE_10KG,
        'A',
        "10 kg",
        { 1000, 1200, 1200, 1000000, 1500000 }
    },
    {
        ACTUATOR_TYPE_20KG,
        'B',
        "20 kg",
        { 1500, 1500, 2000, 1000000, 1500000 }
    },
    {
        ACTUATOR_TYPE_35KG,
        'C',
        "35 kg",
        { 2500, 2000, 2500, 1000000, 1500000 }
    }
};

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type)
{
    if ((uint32_t)type >= (uint32_t)ACTUATOR_TYPE_COUNT)
    {
        return NULL;
    }

    return &s_profiles[(uint32_t)type];
}

const actuator_profile_t *ActuatorProfile_FromCommand(char command)
{
    uint32_t i;

    if ((command >= 'a') && (command <= 'z'))
    {
        command = (char)(command - ('a' - 'A'));
    }

    for (i = 0U; i < (uint32_t)ACTUATOR_TYPE_COUNT; i++)
    {
        if (s_profiles[i].command_key == command)
        {
            return &s_profiles[i];
        }
    }

    return NULL;
}
