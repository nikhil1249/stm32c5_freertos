/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : NG Actuator application entry point
  ******************************************************************************
  */
#include "main.h"
#include "bsp.h"
#include "uart_iface.h"
#include "app.h"

int main(void)
{
  /* HAL, NVIC, cache and system clock first. */
  if (mx_system_init() != SYSTEM_OK)
  {
    return -1;
  }

  /* Board-specific GPIO and UART initialization from hardware_config.h. */
  if (BSP_Init() != BSP_OK)
  {
    return -1;
  }

  /* RTOS-aware interrupt UART transport. */
  if (UART_IF_Init() != UART_IF_OK)
  {
    return -1;
  }

  /* Application/device contexts. */
  if (APP_Init() != 0)
  {
    return -1;
  }

  /* Create FreeRTOS tasks. */
  if (app_synctasks_init() != 0)
  {
    return -1;
  }

  vTaskStartScheduler();

  /* Scheduler should never return. */
  for (;;)
  {
  }
}
