#ifndef ACTUATOR_PROFILE_H
#define ACTUATOR_PROFILE_H

#include "tmc6460_motor.h"
#include <stdint.h>

typedef enum
{
    ACTUATOR_TYPE_10KG = 0,
    ACTUATOR_TYPE_20KG,
    ACTUATOR_TYPE_35KG,
    ACTUATOR_TYPE_COUNT
} actuator_type_t;

typedef struct
{
    actuator_type_t type;
    char command_key;
    const char *name;
    tmc6460_motor_profile_t motor;
} actuator_profile_t;

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type);
const actuator_profile_t *ActuatorProfile_FromCommand(char command);

#endif /* ACTUATOR_PROFILE_H */
