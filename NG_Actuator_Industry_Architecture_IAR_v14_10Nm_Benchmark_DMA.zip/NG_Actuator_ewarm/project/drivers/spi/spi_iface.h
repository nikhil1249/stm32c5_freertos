#ifndef SPI_IFACE_H
#define SPI_IFACE_H

#include "bsp.h"
#include <stdint.h>

typedef enum
{
    SPI_IF_OK = 0,
    SPI_IF_ERROR,
    SPI_IF_BUSY,
    SPI_IF_TIMEOUT,
    SPI_IF_INVALID_PARAM,
    SPI_IF_NOT_INITIALIZED
} spi_if_status_t;

typedef enum
{
    SPI_IF_PORT_TMC = 0,
    SPI_IF_PORT_COUNT
} spi_if_port_t;

typedef struct
{
    uint32_t transfers;
    uint32_t timeouts;
    uint32_t errors;
    uint32_t busy_count;
} spi_if_stats_t;

spi_if_status_t SPI_IF_Init(void);
spi_if_status_t SPI_IF_Transfer(spi_if_port_t port,
                                const uint8_t *tx_data,
                                uint8_t *rx_data,
                                uint32_t length,
                                uint32_t timeout_ms);
void SPI_IF_GetStats(spi_if_port_t port, spi_if_stats_t *stats);

#endif /* SPI_IFACE_H */
