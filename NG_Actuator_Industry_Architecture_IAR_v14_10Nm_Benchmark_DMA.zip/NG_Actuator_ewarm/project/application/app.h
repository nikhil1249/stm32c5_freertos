#ifndef APP_H
#define APP_H

#include "actuator_profile.h"
#include "tmc6460.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdint.h>

typedef enum
{
    APP_MOTOR_STATE_NOT_INITIALIZED = 0,
    APP_MOTOR_STATE_HOLD,
    APP_MOTOR_STATE_CW,
    APP_MOTOR_STATE_CCW,
    APP_MOTOR_STATE_ERROR,
    APP_MOTOR_STATE_CALIBRATING,
    APP_MOTOR_STATE_SOFT_CW,
    APP_MOTOR_STATE_SOFT_CCW
} app_motor_state_t;

typedef struct
{
    uint32_t tmc_chip_id;
    tmc6460_status_t tmc_status;
    actuator_type_t actuator_type;
    uint8_t actuator_initialized;
    app_motor_state_t motor_state;

    int32_t commanded_velocity_raw;
    int32_t velocity_target_readback_raw;
    int32_t velocity_actual_raw;
    int32_t position_raw;
    int32_t torque_actual_raw;
    int32_t flux_actual_raw;

    uint32_t chip_inputs_raw;
    uint32_t hall_raw;
    uint32_t hall_logic;
    uint32_t hall_count;
    uint32_t hall_events;
    uint32_t feedback_ch_b_raw;
    uint32_t phi_e_raw;
    uint32_t chip_status_flags;
    uint32_t chip_events;
    uint32_t gate_driver_config;
    uint32_t motor_motion_config;
    uint32_t feedback_output_config;

    /* Auto-calibration status. calibration_status uses
     * actuator_calibration_status_t numeric values to keep this public status
     * structure decoupled from the calibration module header. */
    uint8_t calibration_active;
    uint8_t calibration_valid;
    uint32_t calibration_status;
    uint32_t calibration_iteration;
    int32_t calibration_zero_raw;
    int32_t calibration_ninety_raw;
    int32_t calibration_stroke_signed_counts;
    uint32_t calibration_stroke_counts;
    uint32_t calibration_zero_spread_counts;
    uint32_t calibration_ninety_spread_counts;
    int32_t angle_deg_x100;

    /* Persistent calibration availability and current-session raw anchor. */
    uint8_t calibration_params_loaded;
    uint8_t position_reference_valid;
    int32_t reference_zero_raw;
    int32_t reference_ninety_raw;

    /* Software soft-stall / soft-end-stop status. */
    uint8_t soft_stall_active;
    uint8_t soft_stall_contact_confirmed;
    uint32_t soft_stall_status;
    uint32_t soft_stall_stage;
    int32_t soft_stall_direction;
    int32_t soft_stall_creep_start_raw;
    int32_t soft_stall_target_raw;
    int32_t soft_stall_distance_to_end;
    int32_t soft_stall_final_raw;
    uint32_t soft_stall_retry_count;
    uint32_t soft_stall_creep_boost_count;
    uint8_t soft_stall_reference_search_used;

    uint32_t position_sample_count;
    uint32_t position_error_count;
    uint32_t diagnostic_error_count;
    uint32_t command_count;
    uint32_t command_error_count;

    /* Runtime stack diagnostics. Value is in StackType_t words, not bytes. */
    uint32_t motor_stack_min_free_words;
    uint8_t motor_stack_margin_low;
} app_status_t;

extern volatile app_status_t g_app_status;

/* Set by FreeRTOS if a task stack overflow is detected. Useful in IAR Watch. */
extern volatile uint32_t g_freertos_stack_overflow_detected;
extern volatile TaskHandle_t g_freertos_stack_overflow_task;

int32_t APP_Init(void);
void APP_HeartbeatTask(void);
void APP_MotorServiceTask(void);
void APP_DebugCommandTask(void);
void APP_DiagnosticsTask(void);
uint32_t APP_GetMotorCommandQueueSpaces(void);

#endif /* APP_H */
