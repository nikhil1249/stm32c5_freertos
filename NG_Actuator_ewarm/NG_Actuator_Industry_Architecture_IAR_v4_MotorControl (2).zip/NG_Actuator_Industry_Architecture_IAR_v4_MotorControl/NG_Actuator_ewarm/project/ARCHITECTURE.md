# NG Actuator firmware architecture

## Runtime layers

```
Debug UART command task (USART2 / ST-LINK VCP)
        |
        v
FreeRTOS motor command queue
        |
        v
MotorService task -- sole TMC6460 bus owner, highest application priority
        |
        v
TMC6460 motor middleware (velocity mode / profile / safe hold)
        |
        v
TMC6460 register transport
        |
        v
UART_IF interrupt transport
        |
        v
BSP / STM32C5 HAL2 / USART1
```

The TMC bus has a **single owner task**. This is deliberate: no command,
position poll, diagnostics read, or future stall detector can overlap a TMC UART
transaction.

## Debug commands

- `A`: initialize 10 kg profile
- `B`: initialize 20 kg profile
- `C`: initialize 35 kg profile
- `V`: CW (positive velocity)
- `W`: CCW (negative velocity)
- `Z`: controlled stop/hold
- `?` or `H`: help

`D` and `E` are reserved. Add their verified profile values to
`application/actuator_profile.c` before enabling them.

## Stop/Hold behavior

`Z` deliberately preserves the Qt safe-hold logic:

1. keep gate driver enabled,
2. apply the selected profile's non-zero hold torque/flux ceiling,
3. keep velocity mode selected,
4. write velocity target = 0,
5. do **not** write torque/flux target = 0.

This is a controlled electromagnetic hold, not an energy-isolating safety stop.

## Position sampling

After successful profile initialization the MotorService task continuously reads
`FOC_PID_POSITION_ACTUAL`. There is no artificial RTOS delay between samples.
The task blocks on the USART interrupt semaphore while each UART response is in
flight, so other tasks still execute. At 115200 baud the UART transaction itself
sets the practical maximum rate.

## Where to extend next

- Add actuator types: `application/actuator_profile.c`
- Add TMC registers: `middleware/tmc6460/tmc6460_registers.h`
- Add reusable controller functions: `middleware/tmc6460/tmc6460_motor.c`
- Add stall/soft-stall state machine: application layer; keep TMC access inside
  MotorService task
- Add supervisory-controller commands: parse into the same motor command queue
- Keep STM32 GPIO/UART/clock changes only in `config/hardware_config.h`
