#include "tmc6460.h"
#include "tmc6460_transport.h"

#include <stddef.h>

#define TMC6460_MAX_REGISTER_ADDRESS         0x03FFU

static tmc6460_status_t TMC6460_ConvertTransportStatus(tmc6460_transport_status_t status)
{
    switch (status)
    {
        case TMC6460_TRANSPORT_OK:            return TMC6460_OK;
        case TMC6460_TRANSPORT_BUSY:          return TMC6460_BUSY;
        case TMC6460_TRANSPORT_TIMEOUT:       return TMC6460_TIMEOUT;
        case TMC6460_TRANSPORT_INVALID_PARAM: return TMC6460_INVALID_PARAM;
        default:                              return TMC6460_ERROR;
    }
}

void TMC6460_Init(tmc6460_t *device,
                  uint32_t timeout_ms)
{
    if (device != NULL)
    {
        device->timeout_ms = timeout_ms;
    }
}

tmc6460_status_t TMC6460_ReadRegister(tmc6460_t *device,
                                      uint16_t address,
                                      uint32_t *value)
{
    tmc6460_transport_status_t transport_status;

    if ((device == NULL) || (value == NULL) ||
        (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_INVALID_PARAM;
    }

    transport_status = TMC6460_TransportReadRegister(address,
                                                      value,
                                                      device->timeout_ms);
    return TMC6460_ConvertTransportStatus(transport_status);
}

tmc6460_status_t TMC6460_WriteRegister(tmc6460_t *device,
                                       uint16_t address,
                                       uint32_t value)
{
    tmc6460_transport_status_t transport_status;

    if ((device == NULL) || (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_INVALID_PARAM;
    }

    transport_status = TMC6460_TransportWriteRegister(address,
                                                       value,
                                                       device->timeout_ms);
    return TMC6460_ConvertTransportStatus(transport_status);
}

tmc6460_status_t TMC6460_ReadField(tmc6460_t *device,
                                   uint16_t address,
                                   uint32_t mask,
                                   uint8_t shift,
                                   uint32_t *value)
{
    uint32_t register_value;
    tmc6460_status_t status;

    if (value == NULL)
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(device, address, &register_value);
    if (status != TMC6460_OK)
    {
        return status;
    }

    *value = (register_value & mask) >> shift;
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_WriteField(tmc6460_t *device,
                                    uint16_t address,
                                    uint32_t mask,
                                    uint8_t shift,
                                    uint32_t value)
{
    uint32_t register_value;
    tmc6460_status_t status;

    status = TMC6460_ReadRegister(device, address, &register_value);
    if (status != TMC6460_OK)
    {
        return status;
    }

    register_value &= ~mask;
    register_value |= ((value << shift) & mask);

    return TMC6460_WriteRegister(device, address, register_value);
}

tmc6460_status_t TMC6460_ReadChipID(tmc6460_t *device,
                                    uint32_t *chip_id)
{
    return TMC6460_ReadRegister(device, TMC6460_REG_CHIP_ID, chip_id);
}

tmc6460_status_t TMC6460_CheckCommunication(tmc6460_t *device,
                                             uint32_t expected_chip_id)
{
    uint32_t chip_id;
    tmc6460_status_t status = TMC6460_ReadChipID(device, &chip_id);

    if (status != TMC6460_OK)
    {
        return status;
    }

    return (chip_id == expected_chip_id) ? TMC6460_OK : TMC6460_INVALID_CHIP_ID;
}
