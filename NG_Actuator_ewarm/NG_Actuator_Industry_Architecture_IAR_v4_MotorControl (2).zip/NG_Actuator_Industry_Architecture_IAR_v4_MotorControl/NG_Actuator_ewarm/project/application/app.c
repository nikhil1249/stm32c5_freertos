#include "app.h"
#include "bsp.h"
#include "hardware_config.h"
#include "tmc6460_motor.h"
#include "uart_iface.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#include <stdio.h>
#include <string.h>

typedef enum
{
    APP_CMD_SELECT_PROFILE = 0,
    APP_CMD_RUN_CW,
    APP_CMD_RUN_CCW,
    APP_CMD_STOP_HOLD
} app_command_type_t;

typedef struct
{
    app_command_type_t type;
    actuator_type_t actuator_type;
} app_motor_command_t;

static tmc6460_t s_tmc_device;
static tmc6460_motor_t s_motor;
static QueueHandle_t s_motor_command_queue;

volatile app_status_t g_app_status =
{
    0U,
    TMC6460_ERROR,
    ACTUATOR_TYPE_10KG,
    0U,
    APP_MOTOR_STATE_NOT_INITIALIZED,
    0,
    0,
    0U,
    0U,
    0U,
    0U
};

static void APP_DebugWrite(const char *text)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    if (text != NULL)
    {
        (void)UART_IF_Write(UART_IF_PORT_DEBUG,
                            (const uint8_t *)text,
                            (uint32_t)strlen(text),
                            HW_DEBUG_UART_TIMEOUT_MS);
    }
#else
    (void)text;
#endif
}

static void APP_SetCommandResult(tmc6460_status_t status,
                                 app_motor_state_t success_state,
                                 int32_t commanded_velocity)
{
    taskENTER_CRITICAL();
    g_app_status.tmc_status = status;
    g_app_status.command_count++;

    if (status == TMC6460_OK)
    {
        g_app_status.motor_state = success_state;
        g_app_status.commanded_velocity_raw = commanded_velocity;
    }
    else
    {
        g_app_status.motor_state = APP_MOTOR_STATE_ERROR;
        g_app_status.command_error_count++;
    }
    taskEXIT_CRITICAL();
}

static void APP_ProcessMotorCommand(const app_motor_command_t *command)
{
    const actuator_profile_t *profile;
    tmc6460_status_t status;
    uint32_t chip_id = 0U;

    if (command == NULL)
    {
        return;
    }

    switch (command->type)
    {
        case APP_CMD_SELECT_PROFILE:
            profile = ActuatorProfile_Get(command->actuator_type);
            if (profile == NULL)
            {
                APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                     APP_MOTOR_STATE_ERROR,
                                     0);
                break;
            }

            /* If another profile is already active, stop safely before
             * reconfiguring the controller. */
            if (s_motor.initialized != 0U)
            {
                (void)TMC6460_MotorStopHold(&s_motor);
            }

            status = TMC6460_MotorConfigure(&s_motor,
                                            &profile->motor,
                                            HW_TMC_EXPECTED_CHIP_ID,
                                            &chip_id);

            taskENTER_CRITICAL();
            g_app_status.tmc_chip_id = chip_id;
            g_app_status.tmc_status = status;
            g_app_status.actuator_type = command->actuator_type;
            g_app_status.actuator_initialized =
                (status == TMC6460_OK) ? 1U : 0U;
            g_app_status.motor_state =
                (status == TMC6460_OK) ? APP_MOTOR_STATE_HOLD :
                                         APP_MOTOR_STATE_ERROR;
            g_app_status.commanded_velocity_raw = 0;
            g_app_status.command_count++;
            if (status != TMC6460_OK)
            {
                g_app_status.command_error_count++;
            }
            taskEXIT_CRITICAL();
            break;

        case APP_CMD_RUN_CW:
            status = TMC6460_MotorRunCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CW,
                                 (s_motor.profile != NULL) ?
                                     s_motor.profile->default_velocity_raw : 0);
            break;

        case APP_CMD_RUN_CCW:
            status = TMC6460_MotorRunCCW(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_CCW,
                                 (s_motor.profile != NULL) ?
                                     -s_motor.profile->default_velocity_raw : 0);
            break;

        case APP_CMD_STOP_HOLD:
            status = TMC6460_MotorStopHold(&s_motor);
            APP_SetCommandResult(status,
                                 APP_MOTOR_STATE_HOLD,
                                 0);
            break;

        default:
            APP_SetCommandResult(TMC6460_INVALID_PARAM,
                                 APP_MOTOR_STATE_ERROR,
                                 0);
            break;
    }
}

static BaseType_t APP_QueueCommand(app_command_type_t type,
                                   actuator_type_t actuator_type)
{
    app_motor_command_t command;

    command.type = type;
    command.actuator_type = actuator_type;

    return xQueueSend(s_motor_command_queue, &command, pdMS_TO_TICKS(20U));
}

int32_t APP_Init(void)
{
    TMC6460_Init(&s_tmc_device,
                 UART_IF_PORT_TMC,
                 HW_TMC_UART_TIMEOUT_MS);

    TMC6460_MotorInitContext(&s_motor, &s_tmc_device);

    s_motor_command_queue = xQueueCreate(HW_MOTOR_COMMAND_QUEUE_LENGTH,
                                          sizeof(app_motor_command_t));
    if (s_motor_command_queue == NULL)
    {
        return -1;
    }

    return 0;
}

void APP_HeartbeatTask(void)
{
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        BSP_LED_Toggle();
        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_LED_PERIOD_MS));
    }
}

void APP_MotorServiceTask(void)
{
    app_motor_command_t command;
    tmc6460_status_t status;
    int32_t position_raw;

    vTaskDelay(pdMS_TO_TICKS(HW_TMC_STARTUP_DELAY_MS));

    for (;;)
    {
        /* Commands always pre-empt the next feedback transaction.  Only this
         * task accesses the TMC6460, so UART transactions can never overlap. */
        while (xQueueReceive(s_motor_command_queue,
                             &command,
                             (TickType_t)0U) == pdPASS)
        {
            APP_ProcessMotorCommand(&command);
        }

        if (s_motor.initialized != 0U)
        {
            /* No artificial delay: this loop runs at the maximum sustainable
             * USART1 request/response rate.  The task sleeps on the RX
             * semaphore while the UART frame is physically transferring. */
            position_raw = 0;
            status = TMC6460_MotorReadPosition(&s_motor, &position_raw);

            taskENTER_CRITICAL();
            g_app_status.tmc_status = status;
            if (status == TMC6460_OK)
            {
                g_app_status.position_raw = position_raw;
                g_app_status.position_sample_count++;
            }
            else
            {
                g_app_status.position_error_count++;
            }
            taskEXIT_CRITICAL();
        }
        else
        {
            /* No actuator selected yet.  Block until a command arrives so the
             * CPU remains idle instead of polling. */
            if (xQueueReceive(s_motor_command_queue,
                              &command,
                              pdMS_TO_TICKS(50U)) == pdPASS)
            {
                APP_ProcessMotorCommand(&command);
            }
        }
    }
}

void APP_DebugCommandTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    uint8_t ch;
    const actuator_profile_t *profile;

    if (UART_IF_StartBufferedRx(UART_IF_PORT_DEBUG) != UART_IF_OK)
    {
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }

    APP_DebugWrite("\r\nNG Actuator ready\r\n"
                   "A=10kg  B=20kg  C=35kg\r\n"
                   "V=CW  W=CCW  Z=STOP/HOLD  ?=HELP\r\n"
                   "Select A/B/C before V or W.\r\n");

    for (;;)
    {
        if (UART_IF_ReadBuffered(UART_IF_PORT_DEBUG,
                                 &ch,
                                 1U,
                                 1000U) == 0U)
        {
            continue;
        }

        if ((ch >= (uint8_t)'a') && (ch <= (uint8_t)'z'))
        {
            ch = (uint8_t)(ch - ((uint8_t)'a' - (uint8_t)'A'));
        }

        profile = ActuatorProfile_FromCommand((char)ch);
        if (profile != NULL)
        {
            if (APP_QueueCommand(APP_CMD_SELECT_PROFILE, profile->type) == pdPASS)
            {
                APP_DebugWrite("PROFILE INIT REQUESTED\r\n");
            }
            else
            {
                APP_DebugWrite("ERR: COMMAND QUEUE FULL\r\n");
            }
            continue;
        }

        switch (ch)
        {
            case (uint8_t)'V':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'W':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_RUN_CCW,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("CCW REQUESTED\r\n");
                }
                break;

            case (uint8_t)'Z':
                if (g_app_status.actuator_initialized == 0U)
                {
                    APP_DebugWrite("ERR: SELECT A/B/C FIRST\r\n");
                }
                else if (APP_QueueCommand(APP_CMD_STOP_HOLD,
                                          g_app_status.actuator_type) == pdPASS)
                {
                    APP_DebugWrite("STOP/HOLD REQUESTED\r\n");
                }
                break;

            case (uint8_t)'D':
            case (uint8_t)'E':
                APP_DebugWrite("D/E PROFILE RESERVED - ADD VALUES IN actuator_profile.c\r\n");
                break;

            case (uint8_t)'?':
            case (uint8_t)'H':
                APP_DebugWrite("A=10kg B=20kg C=35kg | V=CW W=CCW Z=STOP/HOLD\r\n");
                break;

            case (uint8_t)'\r':
            case (uint8_t)'\n':
            case (uint8_t)' ':
                break;

            default:
                APP_DebugWrite("ERR: UNKNOWN COMMAND\r\n");
                break;
        }
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(1000U));
    }
#endif
}

void APP_DiagnosticsTask(void)
{
#if (HW_DEBUG_UART_ENABLE != 0U)
    char message[208];
    int length;
    uint32_t last_sample_count = 0U;
    uint32_t current_sample_count;
    uint32_t sample_rate_hz;
    TickType_t last_wake_time = xTaskGetTickCount();

    for (;;)
    {
        current_sample_count = g_app_status.position_sample_count;
        sample_rate_hz = ((current_sample_count - last_sample_count) * 1000U) /
                         HW_DIAG_PERIOD_MS;
        last_sample_count = current_sample_count;

        length = snprintf(message,
                          sizeof(message),
                          "STAT init=%u profile=%u state=%u chip=0x%08lX "
                          "cmdVel=%ld pos=%ld posHz=%lu samples=%lu posErr=%lu "
                          "tmc=%u cmdErr=%lu\r\n",
                          (unsigned int)g_app_status.actuator_initialized,
                          (unsigned int)g_app_status.actuator_type,
                          (unsigned int)g_app_status.motor_state,
                          (unsigned long)g_app_status.tmc_chip_id,
                          (long)g_app_status.commanded_velocity_raw,
                          (long)g_app_status.position_raw,
                          (unsigned long)sample_rate_hz,
                          (unsigned long)current_sample_count,
                          (unsigned long)g_app_status.position_error_count,
                          (unsigned int)g_app_status.tmc_status,
                          (unsigned long)g_app_status.command_error_count);

        if (length > 0)
        {
            uint32_t tx_length = (uint32_t)length;
            if (tx_length >= sizeof(message))
            {
                tx_length = (uint32_t)(sizeof(message) - 1U);
            }

            (void)UART_IF_Write(UART_IF_PORT_DEBUG,
                                (const uint8_t *)message,
                                tx_length,
                                HW_DEBUG_UART_TIMEOUT_MS);
        }

        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(HW_DIAG_PERIOD_MS));
    }
#endif
}
