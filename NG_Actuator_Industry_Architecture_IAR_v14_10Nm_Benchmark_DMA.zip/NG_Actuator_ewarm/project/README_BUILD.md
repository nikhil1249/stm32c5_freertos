# NG Actuator v10 - build and first SPI test

1. Open `NG_Actuator.eww` in IAR Embedded Workbench.
2. Open `config/hardware_config.h`.
3. For SPI use:

```c
#define HW_TMC_UART_ENABLE 0U
#define HW_TMC_SPI_ENABLE  1U
```

4. Wire SPI2:
   - PB12 -> TMC6460 CSN
   - PB13 -> TMC6460 SCK
   - PB14 <- TMC6460 SDO
   - PB15 -> TMC6460 SDI
   - GND <-> GND
5. Keep USART2 PA2/PA3 connected to ST-LINK VCP for debug commands/logs.
6. Project -> Rebuild All and flash.
7. Open the ST-LINK VCP at 115200 8-N-1.
8. The banner should report `TMC interface: SPI2`.
9. Send `A` (10 kg), `B` (20 kg), or `C` (35 kg). Successful initialization
   must read CHIP_ID = `0x36343630` and report `tmc=0`.
10. Use `V` for CW, `W` for CCW and `Z` for controlled stop/hold.

For UART transport, only invert the two interface-selection macros. The motor,
application and task code does not change.

Current motor motion values:
- initialization/idle: `0x00002386`
- velocity run: `0x00002786`

SPI implementation notes:
- SPI mode 1 (CPOL=0, CPHA=1), MSB first.
- SCK = 4.5 MHz with the current 144 MHz PCLK1 and /32 prescaler.
- TMC6460 regular register access uses 48-bit datagrams.
- Reads and writes are pipelined, so the transport sends a second datagram to
  receive the response to the first.
- CS is software controlled and is deasserted between 48-bit datagrams.

## v11 auto-calibration quick test

This release is based on the verified v10.4 SPI benchmark.

1. Build/rebuild in IAR and flash STM32C562RE.
2. Open USART2/ST-LINK VCP at 115200 8-N-1.
3. Verify normal motor commands first: `A`, `V`, `Z`, `W`, `Z`.
4. Send `A`/`B`/`C` for the actuator to calibrate.
5. Send `G` once.
6. The actuator first moves CCW to physical 0 degrees, then performs
   `ACTUATOR_CALIBRATION_ITERATION_COUNT` complete 0->90->0 cycles.
7. During calibration, `Z` aborts and returns to HOLD.
8. On success, copy the printed `ACT_CAL_xx_*` macros into
   `config/actuator_calibration_config.h` after bench validation.

Calibration intentionally contacts the mechanical end stops. Use conservative
bench current/power limits during the first validation.
