#ifndef APP_H
#define APP_H

#include "actuator_profile.h"
#include "tmc6460.h"
#include <stdint.h>

typedef enum
{
    APP_MOTOR_STATE_NOT_INITIALIZED = 0,
    APP_MOTOR_STATE_HOLD,
    APP_MOTOR_STATE_CW,
    APP_MOTOR_STATE_CCW,
    APP_MOTOR_STATE_ERROR
} app_motor_state_t;

typedef struct
{
    uint32_t tmc_chip_id;
    tmc6460_status_t tmc_status;
    actuator_type_t actuator_type;
    uint8_t actuator_initialized;
    app_motor_state_t motor_state;
    int32_t commanded_velocity_raw;
    int32_t position_raw;
    uint32_t position_sample_count;
    uint32_t position_error_count;
    uint32_t command_count;
    uint32_t command_error_count;
} app_status_t;

extern volatile app_status_t g_app_status;

int32_t APP_Init(void);
void APP_HeartbeatTask(void);
void APP_MotorServiceTask(void);
void APP_DebugCommandTask(void);
void APP_DiagnosticsTask(void);

#endif /* APP_H */
