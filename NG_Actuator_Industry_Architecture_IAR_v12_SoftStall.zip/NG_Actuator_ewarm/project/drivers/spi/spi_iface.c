#include "spi_iface.h"
#include "hardware_config.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"

#include <stddef.h>

typedef struct
{
    hal_spi_handle_t *handle;
    bsp_spi_id_t bsp_id;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t done;
    volatile uint8_t error;
    uint8_t initialized;
} spi_if_context_t;

static spi_if_context_t s_spi[SPI_IF_PORT_COUNT];

static spi_if_context_t *SPI_IF_GetContext(spi_if_port_t port)
{
    if ((uint32_t)port >= (uint32_t)SPI_IF_PORT_COUNT)
    {
        return NULL;
    }

    return &s_spi[(uint32_t)port];
}

static spi_if_context_t *SPI_IF_FindByHandle(hal_spi_handle_t *hspi)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)SPI_IF_PORT_COUNT; i++)
    {
        if ((s_spi[i].initialized != 0U) && (s_spi[i].handle == hspi))
        {
            return &s_spi[i];
        }
    }

    return NULL;
}

static void SPI_IF_ClearSemaphore(SemaphoreHandle_t semaphore)
{
    while (xSemaphoreTake(semaphore, (TickType_t)0U) == pdTRUE)
    {
        /* Drain stale completion tokens. */
    }
}

spi_if_status_t SPI_IF_Init(void)
{
#if (HW_TMC_SPI_ENABLE != 0U)
    spi_if_context_t *ctx = &s_spi[SPI_IF_PORT_TMC];

    ctx->bsp_id = BSP_SPI_TMC;
    ctx->handle = BSP_SPI_GetHandle(ctx->bsp_id);
    if (ctx->handle == NULL)
    {
        return SPI_IF_ERROR;
    }

    ctx->mutex = xSemaphoreCreateMutex();
    ctx->done = xSemaphoreCreateBinary();
    ctx->error = 0U;
    ctx->initialized = 0U;

    if ((ctx->mutex == NULL) || (ctx->done == NULL))
    {
        return SPI_IF_ERROR;
    }

    BSP_SPI_Deselect(ctx->bsp_id);
    ctx->initialized = 1U;
    return SPI_IF_OK;
#else
    return SPI_IF_OK;
#endif
}

spi_if_status_t SPI_IF_Transfer(spi_if_port_t port,
                                const uint8_t *tx_data,
                                uint8_t *rx_data,
                                uint32_t length,
                                uint32_t timeout_ms)
{
#if (HW_TMC_SPI_ENABLE != 0U)
    spi_if_context_t *ctx = SPI_IF_GetContext(port);
    TickType_t timeout_ticks;
    hal_status_t hal_status;
    spi_if_status_t result = SPI_IF_OK;

    if ((ctx == NULL) || (tx_data == NULL) || (rx_data == NULL) ||
        (length == 0U))
    {
        return SPI_IF_INVALID_PARAM;
    }

    if (ctx->initialized == 0U)
    {
        return SPI_IF_NOT_INITIALIZED;
    }

    timeout_ticks = pdMS_TO_TICKS(timeout_ms);
    if (timeout_ticks == 0U)
    {
        timeout_ticks = 1U;
    }

    if (xSemaphoreTake(ctx->mutex, timeout_ticks) != pdTRUE)
    {
        return SPI_IF_BUSY;
    }

    ctx->error = 0U;
    SPI_IF_ClearSemaphore(ctx->done);

    /*
     * When external CS is selected, TMC6460 requires the first SCK edge shortly
     * after CSN falls. Keep CS-low + HAL start in a very small RTOS critical
     * section so a
     * task switch cannot be inserted between them.  The SPI transfer itself is
     * interrupt-driven and continues after the critical section exits.
     */
    taskENTER_CRITICAL();
    BSP_SPI_Select(ctx->bsp_id);
    hal_status = HAL_SPI_TransmitReceive_IT(ctx->handle,
                                            tx_data,
                                            rx_data,
                                            length);
    taskEXIT_CRITICAL();

    if (hal_status != HAL_OK)
    {
        BSP_SPI_Deselect(ctx->bsp_id);
        (void)xSemaphoreGive(ctx->mutex);
        return (hal_status == HAL_BUSY) ? SPI_IF_BUSY : SPI_IF_ERROR;
    }

    if (xSemaphoreTake(ctx->done, timeout_ticks) != pdTRUE)
    {
        (void)HAL_SPI_Abort(ctx->handle);
        BSP_SPI_Deselect(ctx->bsp_id);
        result = SPI_IF_TIMEOUT;
    }
    else if (ctx->error != 0U)
    {
        result = SPI_IF_ERROR;
    }

    (void)xSemaphoreGive(ctx->mutex);
    return result;
#else
    (void)port;
    (void)tx_data;
    (void)rx_data;
    (void)length;
    (void)timeout_ms;
    return SPI_IF_NOT_INITIALIZED;
#endif
}

void HAL_SPI_TxRxCpltCallback(hal_spi_handle_t *hspi)
{
#if (HW_TMC_SPI_ENABLE != 0U)
    spi_if_context_t *ctx = SPI_IF_FindByHandle(hspi);

    if (ctx != NULL)
    {
        BaseType_t higher_priority_task_woken = pdFALSE;

        BSP_SPI_Deselect(ctx->bsp_id);
        (void)xSemaphoreGiveFromISR(ctx->done, &higher_priority_task_woken);
        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
#else
    (void)hspi;
#endif
}

void HAL_SPI_ErrorCallback(hal_spi_handle_t *hspi)
{
#if (HW_TMC_SPI_ENABLE != 0U)
    spi_if_context_t *ctx = SPI_IF_FindByHandle(hspi);

    if (ctx != NULL)
    {
        BaseType_t higher_priority_task_woken = pdFALSE;

        ctx->error = 1U;
        BSP_SPI_Deselect(ctx->bsp_id);
        (void)xSemaphoreGiveFromISR(ctx->done, &higher_priority_task_woken);
        portYIELD_FROM_ISR(higher_priority_task_woken);
    }
#else
    (void)hspi;
#endif
}
