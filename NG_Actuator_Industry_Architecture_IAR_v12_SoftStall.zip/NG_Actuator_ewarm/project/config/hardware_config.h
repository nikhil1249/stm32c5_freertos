#ifndef HARDWARE_CONFIG_H
#define HARDWARE_CONFIG_H

/*
 * NG Actuator - single STM32C5 hardware configuration file.
 *
 * Select EXACTLY ONE TMC6460 host interface below.  All application and
 * TMC6460 motor-control code is interface-independent.
 */

/* -------------------------------------------------------------------------- */
/* TMC6460 host-interface selection                                           */
/* -------------------------------------------------------------------------- */
#define HW_TMC_UART_ENABLE                         0U
#define HW_TMC_SPI_ENABLE                          1U

#if ((HW_TMC_UART_ENABLE + HW_TMC_SPI_ENABLE) != 1U)
#error "Enable exactly one TMC6460 interface: UART or SPI."
#endif

#if (HW_TMC_UART_ENABLE != 0U)
#define HW_TMC_INTERFACE_NAME                     "UART1"
#else
#define HW_TMC_INTERFACE_NAME                     "SPI2"
#endif

/* -------------------------------------------------------------------------- */
/* System clock / FreeRTOS tick                                               */
/* -------------------------------------------------------------------------- */
#define HW_CPU_CLOCK_HZ                       144000000U
#define HW_SYSTICK_CLOCK_HZ                    18000000U
#define HW_RTOS_TICK_RATE_HZ                       1000U
#define HW_RTOS_HEAP_SIZE_BYTES                   24576U

/* 24 MHz HSE -> PSI 144 MHz -> SYSCLK/HCLK 144 MHz. */
#define HW_RCC_ENABLE_HSE                           1U
#define HW_RCC_ENABLE_PSI                           1U
#define HW_RCC_PSI_SOURCE                 HAL_RCC_PSI_SRC_HSE
#define HW_RCC_PSI_REFERENCE             HAL_RCC_PSI_REF_24MHZ
#define HW_RCC_PSI_OUTPUT                HAL_RCC_PSI_OUT_144MHZ
#define HW_RCC_SYSCLK_SOURCE             HAL_RCC_SYSCLK_SRC_PSIS
#define HW_RCC_HCLK_PRESCALER            HAL_RCC_HCLK_PRESCALER1
#define HW_RCC_PCLK1_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_RCC_PCLK2_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_RCC_PCLK3_PRESCALER           HAL_RCC_PCLK_PRESCALER1
#define HW_FLASH_LATENCY                 HAL_FLASH_ITF_LATENCY_4
#define HW_FLASH_PROGRAM_DELAY           HAL_FLASH_ITF_PROGRAM_DELAY_2

/* -------------------------------------------------------------------------- */
/* On-board heartbeat LED                                                    */
/* -------------------------------------------------------------------------- */
#define HW_LED_PORT                            HAL_GPIOA
#define HW_LED_PIN                             HAL_GPIO_PIN_5
#define HW_LED_INIT_STATE                      HAL_GPIO_PIN_RESET
#define HW_LED_PERIOD_MS                       1000U

/* -------------------------------------------------------------------------- */
/* TMC6460 UART option                                                        */
/* USART1: PB15=TX, PB14=RX on NUCLEO-C562RE.                                 */
/* -------------------------------------------------------------------------- */
#define HW_TMC_UART_INSTANCE                   HAL_UART1
#define HW_TMC_UART_BAUDRATE                   115200U
#define HW_TMC_UART_TX_PORT                    HAL_GPIOB
#define HW_TMC_UART_TX_PIN                     HAL_GPIO_PIN_15
#define HW_TMC_UART_RX_PORT                    HAL_GPIOB
#define HW_TMC_UART_RX_PIN                     HAL_GPIO_PIN_14
#define HW_TMC_UART_GPIO_AF                    HAL_GPIO_AF_4
#define HW_TMC_UART_IRQn                       USART1_IRQn
#define HW_TMC_UART_IRQ_HANDLER                USART1_IRQHandler
#define HW_TMC_UART_IRQ_PRIORITY_NUM           5U
#define HW_TMC_UART_IRQ_PREEMPT_PRIORITY       ((hal_cortex_nvic_preemp_priority_t)HW_TMC_UART_IRQ_PRIORITY_NUM)
#define HW_TMC_UART_IRQ_SUB_PRIORITY           HAL_CORTEX_NVIC_SUB_PRIORITY_0
#define HW_TMC_UART_KERNEL_CLOCK_CONFIG()      HAL_RCC_USART1_SetKernelClkSource(HAL_RCC_USART1_CLK_SRC_PCLK2)
#define HW_TMC_UART_RESET()                    HAL_RCC_USART1_Reset()
#define HW_TMC_UART_DISABLE_CLOCK()            HAL_RCC_USART1_DisableClock()

/* -------------------------------------------------------------------------- */
/* TMC6460 SPI option                                                         */
/* SPI2 uses the same PB14/PB15 pair as the UART option, plus PB12/PB13.       */
/*                                                                            */
/* STM32C562RE                  TMC6460                                        */
/* PB12 GPIO CS  -------------> CSN                                           */
/* PB13 SPI2_SCK  ------------> SCK                                           */
/* PB14 SPI2_MISO <------------ SDO                                           */
/* PB15 SPI2_MOSI ------------> SDI                                           */
/* GND              ----------- GND                                           */
/*                                                                            */
/* TMC6460 requires SPI mode 1: CPOL=0, CPHA=1, MSB first, max 8 MHz.         */
/* PCLK1 is 144 MHz; /32 gives 4.5 MHz and leaves comfortable timing margin.  */
/* -------------------------------------------------------------------------- */
#define HW_TMC_SPI_INSTANCE                    HAL_SPI2
#define HW_TMC_SPI_SCK_PORT                    HAL_GPIOB
#define HW_TMC_SPI_SCK_PIN                     HAL_GPIO_PIN_13
#define HW_TMC_SPI_MISO_PORT                   HAL_GPIOB
#define HW_TMC_SPI_MISO_PIN                    HAL_GPIO_PIN_14
#define HW_TMC_SPI_MOSI_PORT                   HAL_GPIOB
#define HW_TMC_SPI_MOSI_PIN                    HAL_GPIO_PIN_15
#define HW_TMC_SPI_GPIO_AF                     HAL_GPIO_AF5_SPI2

/* TMC6460 has a dedicated external active-low CSN input.
 * 1 = drive CSN from a normal STM32 GPIO (recommended/default).
 * 0 = let the SPI peripheral drive its hardware NSS output.
 *
 * External GPIO CS is preferred because TMC6460 uses 48-bit datagrams and
 * CSN must return HIGH between every datagram, including the two frames used
 * for pipelined SPI reads/writes. */
#define HW_TMC_SPI_EXTERNAL_CS_ENABLE          1U
#define HW_TMC_SPI_CS_PORT                     HAL_GPIOB
#define HW_TMC_SPI_CS_PIN                      HAL_GPIO_PIN_12
#define HW_TMC_SPI_CS_GPIO_AF                  HAL_GPIO_AF5_SPI2
#define HW_TMC_SPI_CS_INACTIVE_STATE           HAL_GPIO_PIN_SET
#define HW_TMC_SPI_CS_ACTIVE_STATE             HAL_GPIO_PIN_RESET

#define HW_TMC_SPI_IRQn                        SPI2_IRQn
#define HW_TMC_SPI_IRQ_HANDLER                 SPI2_IRQHandler
#define HW_TMC_SPI_IRQ_PRIORITY_NUM            5U
#define HW_TMC_SPI_IRQ_PREEMPT_PRIORITY        ((hal_cortex_nvic_preemp_priority_t)HW_TMC_SPI_IRQ_PRIORITY_NUM)
#define HW_TMC_SPI_IRQ_SUB_PRIORITY            HAL_CORTEX_NVIC_SUB_PRIORITY_0
#define HW_TMC_SPI_KERNEL_CLOCK_CONFIG()       HAL_RCC_SPI2_SetKernelClkSource(HAL_RCC_SPI2_CLK_SRC_PCLK1)
#define HW_TMC_SPI_ENABLE_CLOCK()              HAL_RCC_SPI2_EnableClock()
#define HW_TMC_SPI_RESET()                     HAL_RCC_SPI2_Reset()
#define HW_TMC_SPI_DISABLE_CLOCK()             HAL_RCC_SPI2_DisableClock()

#define HW_TMC_SPI_MODE                        HAL_SPI_MODE_MASTER
#define HW_TMC_SPI_DIRECTION                   HAL_SPI_DIRECTION_FULL_DUPLEX
#define HW_TMC_SPI_DATA_WIDTH                  HAL_SPI_DATA_WIDTH_8_BIT
#define HW_TMC_SPI_CLOCK_POLARITY               HAL_SPI_CLOCK_POLARITY_LOW
#define HW_TMC_SPI_CLOCK_PHASE                  HAL_SPI_CLOCK_PHASE_2_EDGE
#define HW_TMC_SPI_BAUD_PRESCALER               HAL_SPI_BAUD_RATE_PRESCALER_32
#define HW_TMC_SPI_FIRST_BIT                    HAL_SPI_MSB_FIRST
#if (HW_TMC_SPI_EXTERNAL_CS_ENABLE != 0U)
/* Software NSS inside SPI; the real TMC6460 CSN is driven by GPIO above. */
#define HW_TMC_SPI_NSS_MANAGEMENT              HAL_SPI_NSS_PIN_MGMT_INTERNAL
#else
/* Optional future mode: SPI2 drives PB12/NSS itself. */
#define HW_TMC_SPI_NSS_MANAGEMENT              HAL_SPI_NSS_PIN_MGMT_OUTPUT
#endif
#define HW_TMC_SPI_GPIO_OUTPUT_TYPE             HAL_GPIO_OUTPUT_PUSHPULL
/* Keep SCK at the required CPOL=0 level whenever HAL temporarily disables
 * SPI between interrupt-driven transfers.  Without this pull-down the EVKIT
 * side can pull SCK high; asserting CS while SCK is high creates a spurious
 * edge before the 48-bit frame and shifts the TMC6460 response. */
#define HW_TMC_SPI_SCK_PULL                     HAL_GPIO_PULL_DOWN
#define HW_TMC_SPI_MISO_PULL                    HAL_GPIO_PULL_NO
#define HW_TMC_SPI_MOSI_PULL                    HAL_GPIO_PULL_NO
#define HW_TMC_SPI_GPIO_SPEED                   HAL_GPIO_SPEED_FREQ_HIGH

/* -------------------------------------------------------------------------- */
/* Debug UART - ST-LINK VCP                                                   */
/* USART2: PA2=TX, PA3=RX on NUCLEO-C562RE.                                   */
/* -------------------------------------------------------------------------- */
#define HW_DEBUG_UART_ENABLE                   1U
#define HW_DEBUG_UART_INSTANCE                 HAL_UART2
#define HW_DEBUG_UART_BAUDRATE                 115200U
#define HW_DEBUG_UART_TX_PORT                  HAL_GPIOA
#define HW_DEBUG_UART_TX_PIN                   HAL_GPIO_PIN_2
#define HW_DEBUG_UART_RX_PORT                  HAL_GPIOA
#define HW_DEBUG_UART_RX_PIN                   HAL_GPIO_PIN_3
#define HW_DEBUG_UART_GPIO_AF                  HAL_GPIO_AF_7
#define HW_DEBUG_UART_IRQn                     USART2_IRQn
#define HW_DEBUG_UART_IRQ_HANDLER              USART2_IRQHandler
#define HW_DEBUG_UART_IRQ_PRIORITY_NUM         6U
#define HW_DEBUG_UART_IRQ_PREEMPT_PRIORITY     ((hal_cortex_nvic_preemp_priority_t)HW_DEBUG_UART_IRQ_PRIORITY_NUM)
#define HW_DEBUG_UART_IRQ_SUB_PRIORITY         HAL_CORTEX_NVIC_SUB_PRIORITY_0
#define HW_DEBUG_UART_KERNEL_CLOCK_CONFIG()    HAL_RCC_USART2_SetKernelClkSource(HAL_RCC_USART2_CLK_SRC_PCLK1)
#define HW_DEBUG_UART_RESET()                  HAL_RCC_USART2_Reset()
#define HW_DEBUG_UART_DISABLE_CLOCK()          HAL_RCC_USART2_DisableClock()

/* UART framing shared by TMC-UART and debug links. */
#define HW_UART_WORD_LENGTH                    HAL_UART_WORD_LENGTH_8_BIT
#define HW_UART_STOP_BITS                      HAL_UART_STOP_BIT_1
#define HW_UART_PARITY                         HAL_UART_PARITY_NONE
#define HW_UART_DIRECTION                      HAL_UART_DIRECTION_TX_RX
#define HW_UART_HW_FLOW_CONTROL                HAL_UART_HW_CONTROL_NONE
#define HW_UART_OVERSAMPLING                   HAL_UART_OVERSAMPLING_16
#define HW_UART_ONE_BIT_SAMPLING               HAL_UART_ONE_BIT_SAMPLE_DISABLE
#define HW_UART_PRESCALER                      HAL_UART_PRESCALER_DIV1
#define HW_UART_GPIO_OUTPUT_TYPE               HAL_GPIO_OUTPUT_PUSHPULL
#define HW_UART_GPIO_PULL                      HAL_GPIO_PULL_NO
#define HW_UART_GPIO_SPEED                     HAL_GPIO_SPEED_FREQ_LOW

/* -------------------------------------------------------------------------- */
/* Communication middleware                                                  */
/* -------------------------------------------------------------------------- */
#define HW_TMC_COMM_TIMEOUT_MS                 25U
#define HW_DEBUG_UART_TIMEOUT_MS               50U
#define HW_DEBUG_RX_STREAM_SIZE                64U
#define HW_TMC_STARTUP_DELAY_MS                100U
#define HW_TMC_EXPECTED_CHIP_ID                0x36343630UL

/* -------------------------------------------------------------------------- */
/* Application / motor service                                                */
/* -------------------------------------------------------------------------- */
#define HW_MOTOR_COMMAND_QUEUE_LENGTH          12U
#define HW_DIAG_PERIOD_MS                      500U

/* Limit continuous TMC position polling so the high-priority MotorService task
 * cannot starve DebugCommand/Diagnostics/Heartbeat.  With a 1 kHz RTOS tick,
 * 400 Hz is implemented by alternating 2-tick and 3-tick periods. */
#define HW_TMC_POSITION_SAMPLE_RATE_HZ         400U

/* -------------------------------------------------------------------------- */
/* FreeRTOS application tasks                                                 */
/* Stack values are FreeRTOS StackType_t entries, not bytes.                  */
/* -------------------------------------------------------------------------- */
#define HW_TASK_HEARTBEAT_NAME                 "Heartbeat"
#define HW_TASK_HEARTBEAT_STACK                256U
#define HW_TASK_HEARTBEAT_PRIORITY             1U

#define HW_TASK_MOTOR_NAME                     "MotorService"
#define HW_TASK_MOTOR_STACK                    512U
#define HW_TASK_MOTOR_PRIORITY                 4U

#define HW_TASK_COMMAND_NAME                   "DebugCommand"
#define HW_TASK_COMMAND_STACK                  384U
#define HW_TASK_COMMAND_PRIORITY               3U

#define HW_TASK_DIAG_NAME                      "Diagnostics"
#define HW_TASK_DIAG_STACK                     512U
#define HW_TASK_DIAG_PRIORITY                  1U

/* -------------------------------------------------------------------------- */
/* Compile-time sanity checks                                                 */
/* -------------------------------------------------------------------------- */
#if (HW_TMC_UART_ENABLE != 0U) && (HW_TMC_UART_IRQ_PRIORITY_NUM < 5U)
#error "TMC UART IRQ priority must be FreeRTOS-safe (numeric priority >= 5)."
#endif

#if ((HW_TMC_SPI_EXTERNAL_CS_ENABLE != 0U) && (HW_TMC_SPI_EXTERNAL_CS_ENABLE != 1U))
#error "HW_TMC_SPI_EXTERNAL_CS_ENABLE must be 0 or 1."
#endif

#if (HW_TMC_SPI_ENABLE != 0U) && (HW_TMC_SPI_IRQ_PRIORITY_NUM < 5U)
#error "TMC SPI IRQ priority must be FreeRTOS-safe (numeric priority >= 5)."
#endif

#if (HW_DEBUG_UART_ENABLE != 0U) && (HW_DEBUG_UART_IRQ_PRIORITY_NUM < 5U)
#error "Debug UART IRQ priority must be FreeRTOS-safe (numeric priority >= 5)."
#endif

#if (HW_TMC_POSITION_SAMPLE_RATE_HZ == 0U)
#error "HW_TMC_POSITION_SAMPLE_RATE_HZ must be non-zero."
#endif

#if (HW_TMC_POSITION_SAMPLE_RATE_HZ > HW_RTOS_TICK_RATE_HZ)
#error "Position sample rate cannot exceed RTOS tick rate with this scheduler implementation."
#endif

#endif /* HARDWARE_CONFIG_H */
