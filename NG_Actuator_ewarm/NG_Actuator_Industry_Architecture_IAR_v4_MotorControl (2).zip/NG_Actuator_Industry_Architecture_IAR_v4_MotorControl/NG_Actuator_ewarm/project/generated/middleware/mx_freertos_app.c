/**
  ******************************************************************************
  * @file           : mx_freertos_app.c
  * @brief          : FreeRTOS task creation and task entry wrappers
  ******************************************************************************
  */
#include "mx_freertos_app.h"
#include "hardware_config.h"
#include "app.h"

static TaskHandle_t HeartbeatTask_Handle;
static TaskHandle_t MotorServiceTask_Handle;
static TaskHandle_t DebugCommandTask_Handle;
static TaskHandle_t DiagnosticsTask_Handle;

static void HeartbeatTask_Entry(void *pvParameters);
static void MotorServiceTask_Entry(void *pvParameters);
static void DebugCommandTask_Entry(void *pvParameters);
static void DiagnosticsTask_Entry(void *pvParameters);

int32_t app_synctasks_init(void)
{
  BaseType_t ret;

  ret = xTaskCreate(HeartbeatTask_Entry,
                    HW_TASK_HEARTBEAT_NAME,
                    HW_TASK_HEARTBEAT_STACK,
                    NULL,
                    (UBaseType_t)HW_TASK_HEARTBEAT_PRIORITY,
                    &HeartbeatTask_Handle);
  if (ret != pdPASS)
  {
    return -1;
  }

  ret = xTaskCreate(MotorServiceTask_Entry,
                    HW_TASK_MOTOR_NAME,
                    HW_TASK_MOTOR_STACK,
                    NULL,
                    (UBaseType_t)HW_TASK_MOTOR_PRIORITY,
                    &MotorServiceTask_Handle);
  if (ret != pdPASS)
  {
    return -1;
  }

  ret = xTaskCreate(DebugCommandTask_Entry,
                    HW_TASK_COMMAND_NAME,
                    HW_TASK_COMMAND_STACK,
                    NULL,
                    (UBaseType_t)HW_TASK_COMMAND_PRIORITY,
                    &DebugCommandTask_Handle);
  if (ret != pdPASS)
  {
    return -1;
  }

  ret = xTaskCreate(DiagnosticsTask_Entry,
                    HW_TASK_DIAG_NAME,
                    HW_TASK_DIAG_STACK,
                    NULL,
                    (UBaseType_t)HW_TASK_DIAG_PRIORITY,
                    &DiagnosticsTask_Handle);
  if (ret != pdPASS)
  {
    return -1;
  }

  return 0;
}

static void HeartbeatTask_Entry(void *pvParameters)
{
  (void)pvParameters;
  APP_HeartbeatTask();
}

static void MotorServiceTask_Entry(void *pvParameters)
{
  (void)pvParameters;
  APP_MotorServiceTask();
}

static void DebugCommandTask_Entry(void *pvParameters)
{
  (void)pvParameters;
  APP_DebugCommandTask();
}

static void DiagnosticsTask_Entry(void *pvParameters)
{
  (void)pvParameters;
  APP_DiagnosticsTask();
}
