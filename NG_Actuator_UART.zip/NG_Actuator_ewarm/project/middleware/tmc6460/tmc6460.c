#include "tmc6460.h"

#include <stddef.h>

#define TMC6460_MAX_REGISTER_ADDRESS         0x03FFU
#define TMC6460_READ_TX_SIZE                 2U
#define TMC6460_READ_RX_SIZE                 6U
#define TMC6460_WRITE_TX_SIZE                6U
#define TMC6460_WRITE_RX_SIZE                5U
#define TMC6460_UART_BASE_HEADER             0x42U
#define TMC6460_UART_WRITE_BIT               0x08U

static uint8_t TMC6460_GetHeader(uint16_t address, uint8_t write)
{
    uint8_t header = (uint8_t)(TMC6460_UART_BASE_HEADER |
                               ((address >> 4U) & 0x30U));

    if (write != 0U)
    {
        header |= TMC6460_UART_WRITE_BIT;
    }

    return header;
}

static tmc6460_status_t TMC6460_ConvertStatus(uart_if_status_t status)
{
    switch (status)
    {
        case UART_IF_OK:                return TMC6460_OK;
        case UART_IF_BUSY:              return TMC6460_BUSY;
        case UART_IF_TIMEOUT:           return TMC6460_TIMEOUT;
        case UART_IF_INVALID_PARAM:     return TMC6460_INVALID_PARAM;
        default:                        return TMC6460_ERROR;
    }
}

void TMC6460_Init(tmc6460_t *device,
                  uart_if_port_t uart_port,
                  uint32_t timeout_ms)
{
    if (device != NULL)
    {
        device->uart_port = uart_port;
        device->timeout_ms = timeout_ms;
    }
}

tmc6460_status_t TMC6460_ReadRegister(tmc6460_t *device,
                                      uint16_t address,
                                      uint32_t *value)
{
    uint8_t tx[TMC6460_READ_TX_SIZE];
    uint8_t rx[TMC6460_READ_RX_SIZE];
    uart_if_status_t uart_status;

    if ((device == NULL) || (value == NULL) ||
        (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_INVALID_PARAM;
    }

    tx[0] = TMC6460_GetHeader(address, 0U);
    tx[1] = (uint8_t)(address & 0xFFU);

    uart_status = UART_IF_WriteRead(device->uart_port,
                                    tx,
                                    sizeof(tx),
                                    rx,
                                    sizeof(rx),
                                    device->timeout_ms);

    if (uart_status != UART_IF_OK)
    {
        return TMC6460_ConvertStatus(uart_status);
    }

    if ((rx[0] != tx[0]) || (rx[1] != tx[1]))
    {
        return TMC6460_INVALID_RESPONSE;
    }

    *value = ((uint32_t)rx[2] << 24U) |
             ((uint32_t)rx[3] << 16U) |
             ((uint32_t)rx[4] << 8U)  |
             ((uint32_t)rx[5]);

    return TMC6460_OK;
}

tmc6460_status_t TMC6460_WriteRegister(tmc6460_t *device,
                                       uint16_t address,
                                       uint32_t value)
{
    uint8_t tx[TMC6460_WRITE_TX_SIZE];
    uint8_t rx[TMC6460_WRITE_RX_SIZE];
    uart_if_status_t uart_status;

    if ((device == NULL) || (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_INVALID_PARAM;
    }

    tx[0] = TMC6460_GetHeader(address, 1U);
    tx[1] = (uint8_t)(address & 0xFFU);
    tx[2] = (uint8_t)((value >> 24U) & 0xFFU);
    tx[3] = (uint8_t)((value >> 16U) & 0xFFU);
    tx[4] = (uint8_t)((value >> 8U) & 0xFFU);
    tx[5] = (uint8_t)(value & 0xFFU);

    /*
     * IMPORTANT FOR DIRECT STM32 <-> TMC6460 UART:
     *
     * UART.RTMI_CH_7.CH_7_EN is enabled after reset. Therefore every normal
     * register write produces a 5-byte reply. The older Arduino transport
     * explicitly drained these bytes after each write. If they are left in the
     * STM32 USART RX path, the following 6-byte register read starts with stale
     * write-reply bytes and can report UART overrun / invalid response.
     *
     * Arm RX before TX and consume the complete 5-byte write reply here.
     */
    uart_status = UART_IF_WriteRead(device->uart_port,
                                    tx,
                                    sizeof(tx),
                                    rx,
                                    sizeof(rx),
                                    device->timeout_ms);

    if (uart_status != UART_IF_OK)
    {
        return TMC6460_ConvertStatus(uart_status);
    }

    /* Normal write response byte 0:
     *   bit7   = 0 (sync)
     *   bit6:4 = write counter (variable)
     *   bit3:1 = 111 (normal write response channel 7)
     *   bit0   = 1 (sync)
     * Mask out the variable write counter and verify the fixed bits.
     */
    if ((rx[0] & 0x8FU) != 0x0FU)
    {
        return TMC6460_INVALID_RESPONSE;
    }

    /* Bytes 1..4 contain the controller write-response data. Do not require
     * exact equality here because some registers contain self-clearing or
     * hardware-modified bits. The important transport requirement is that the
     * five response bytes are consumed before the next transaction.
     */
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_ReadField(tmc6460_t *device,
                                   uint16_t address,
                                   uint32_t mask,
                                   uint8_t shift,
                                   uint32_t *value)
{
    uint32_t register_value;
    tmc6460_status_t status;

    if (value == NULL)
    {
        return TMC6460_INVALID_PARAM;
    }

    status = TMC6460_ReadRegister(device, address, &register_value);
    if (status != TMC6460_OK)
    {
        return status;
    }

    *value = (register_value & mask) >> shift;
    return TMC6460_OK;
}

tmc6460_status_t TMC6460_WriteField(tmc6460_t *device,
                                    uint16_t address,
                                    uint32_t mask,
                                    uint8_t shift,
                                    uint32_t value)
{
    uint32_t register_value;
    tmc6460_status_t status;

    status = TMC6460_ReadRegister(device, address, &register_value);
    if (status != TMC6460_OK)
    {
        return status;
    }

    register_value &= ~mask;
    register_value |= ((value << shift) & mask);

    return TMC6460_WriteRegister(device, address, register_value);
}

tmc6460_status_t TMC6460_ReadChipID(tmc6460_t *device,
                                    uint32_t *chip_id)
{
    return TMC6460_ReadRegister(device, TMC6460_REG_CHIP_ID, chip_id);
}

tmc6460_status_t TMC6460_CheckCommunication(tmc6460_t *device,
                                             uint32_t expected_chip_id)
{
    uint32_t chip_id;
    tmc6460_status_t status = TMC6460_ReadChipID(device, &chip_id);

    if (status != TMC6460_OK)
    {
        return status;
    }

    return (chip_id == expected_chip_id) ? TMC6460_OK : TMC6460_INVALID_CHIP_ID;
}
