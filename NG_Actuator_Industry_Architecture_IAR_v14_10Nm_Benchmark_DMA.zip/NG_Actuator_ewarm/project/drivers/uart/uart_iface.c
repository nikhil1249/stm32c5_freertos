#include "uart_iface.h"
#include "hardware_config.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "stream_buffer.h"
#include "task.h"

#include <stddef.h>
#include <string.h>

typedef struct
{
    hal_uart_handle_t *handle;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t tx_done;
    SemaphoreHandle_t rx_done;
    StreamBufferHandle_t rx_stream;
#if (HW_UART_DMA_ENABLE != 0U)
    uint8_t buffered_rx_dma[HW_DEBUG_RX_DMA_CHUNK_SIZE];
#else
    uint8_t buffered_rx_byte;
#endif
    volatile uint8_t error;
    volatile uint8_t buffered_rx_enabled;
    uint8_t initialized;
    uart_if_stats_t stats;
} uart_if_context_t;

static uart_if_context_t s_uart[UART_IF_PORT_COUNT];

static uart_if_context_t *UART_IF_GetContext(uart_if_port_t port)
{
    if ((uint32_t)port >= (uint32_t)UART_IF_PORT_COUNT)
    {
        return NULL;
    }
    return &s_uart[(uint32_t)port];
}

static uart_if_context_t *UART_IF_FindByHandle(hal_uart_handle_t *huart)
{
    uint32_t i;
    for (i = 0U; i < (uint32_t)UART_IF_PORT_COUNT; i++)
    {
        if ((s_uart[i].initialized != 0U) && (s_uart[i].handle == huart))
        {
            return &s_uart[i];
        }
    }
    return NULL;
}

static void UART_IF_ClearSemaphore(SemaphoreHandle_t semaphore)
{
    while (xSemaphoreTake(semaphore, (TickType_t)0U) == pdTRUE) { }
}

static uart_if_status_t UART_IF_Register(uart_if_port_t port, hal_uart_handle_t *handle)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    if ((ctx == NULL) || (handle == NULL))
    {
        return UART_IF_INVALID_PARAM;
    }

    memset(ctx, 0, sizeof(*ctx));
    ctx->handle = handle;
    ctx->mutex = xSemaphoreCreateMutex();
    ctx->tx_done = xSemaphoreCreateBinary();
    ctx->rx_done = xSemaphoreCreateBinary();
    if ((ctx->mutex == NULL) || (ctx->tx_done == NULL) || (ctx->rx_done == NULL))
    {
        return UART_IF_ERROR;
    }
    ctx->initialized = 1U;
    return UART_IF_OK;
}

uart_if_status_t UART_IF_Init(void)
{
    uart_if_status_t status;
#if (HW_TMC_UART_ENABLE != 0U)
    status = UART_IF_Register(UART_IF_PORT_TMC, BSP_UART_GetHandle(BSP_UART_TMC));
    if (status != UART_IF_OK) { return status; }
#endif
#if (HW_DEBUG_UART_ENABLE != 0U)
    status = UART_IF_Register(UART_IF_PORT_DEBUG, BSP_UART_GetHandle(BSP_UART_DEBUG));
    if (status != UART_IF_OK) { return status; }
#endif
    return UART_IF_OK;
}

static uart_if_status_t UART_IF_Lock(uart_if_context_t *ctx, uint32_t timeout_ms)
{
    TickType_t ticks = pdMS_TO_TICKS(timeout_ms);
    if (ticks == 0U) { ticks = 1U; }
    return (xSemaphoreTake(ctx->mutex, ticks) == pdTRUE) ? UART_IF_OK : UART_IF_BUSY;
}

static void UART_IF_Unlock(uart_if_context_t *ctx)
{
    (void)xSemaphoreGive(ctx->mutex);
}

static uart_if_status_t UART_IF_WaitCompletion(uart_if_context_t *ctx,
                                               SemaphoreHandle_t semaphore,
                                               uint32_t timeout_ms)
{
    TickType_t ticks = pdMS_TO_TICKS(timeout_ms);
    if (ticks == 0U) { ticks = 1U; }

    if (xSemaphoreTake(semaphore, ticks) != pdTRUE)
    {
        (void)HAL_UART_Abort(ctx->handle);
        ctx->stats.timeouts++;
        return UART_IF_TIMEOUT;
    }
    if (ctx->error != 0U)
    {
        ctx->stats.errors++;
        return UART_IF_ERROR;
    }
    return UART_IF_OK;
}

uart_if_status_t UART_IF_Write(uart_if_port_t port,
                               const uint8_t *data,
                               uint32_t length,
                               uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hs;

    if ((ctx == NULL) || (data == NULL) || (length == 0U)) return UART_IF_INVALID_PARAM;
    if (ctx->initialized == 0U) return UART_IF_NOT_INITIALIZED;

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK) return result;

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->tx_done);
#if (HW_UART_DMA_ENABLE != 0U)
    hs = HAL_UART_Transmit_DMA(ctx->handle, data, length);
#else
    hs = HAL_UART_Transmit_IT(ctx->handle, data, length);
#endif
    if (hs != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hs == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->tx_done, timeout_ms);
    if (result == UART_IF_OK) ctx->stats.tx_transfers++;
    UART_IF_Unlock(ctx);
    return result;
}

uart_if_status_t UART_IF_Read(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t length,
                              uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hs;

    if ((ctx == NULL) || (data == NULL) || (length == 0U)) return UART_IF_INVALID_PARAM;
    if (ctx->initialized == 0U) return UART_IF_NOT_INITIALIZED;
    if (ctx->buffered_rx_enabled != 0U) return UART_IF_BUSY;

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK) return result;

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->rx_done);
#if (HW_UART_DMA_ENABLE != 0U)
    hs = HAL_UART_Receive_DMA(ctx->handle, data, length);
#else
    hs = HAL_UART_Receive_IT(ctx->handle, data, length);
#endif
    if (hs != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hs == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->rx_done, timeout_ms);
    if (result == UART_IF_OK) ctx->stats.rx_transfers++;
    UART_IF_Unlock(ctx);
    return result;
}

uart_if_status_t UART_IF_WriteRead(uart_if_port_t port,
                                   const uint8_t *tx_data,
                                   uint32_t tx_length,
                                   uint8_t *rx_data,
                                   uint32_t rx_length,
                                   uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    uart_if_status_t result;
    hal_status_t hs;

    if ((ctx == NULL) || (tx_data == NULL) || (rx_data == NULL) ||
        (tx_length == 0U) || (rx_length == 0U)) return UART_IF_INVALID_PARAM;
    if (ctx->initialized == 0U) return UART_IF_NOT_INITIALIZED;
    if (ctx->buffered_rx_enabled != 0U) return UART_IF_BUSY;

    result = UART_IF_Lock(ctx, timeout_ms);
    if (result != UART_IF_OK) return result;

    ctx->error = 0U;
    UART_IF_ClearSemaphore(ctx->tx_done);
    UART_IF_ClearSemaphore(ctx->rx_done);

    /* Arm receive before transmit; TMC6460 UART can answer immediately. */
#if (HW_UART_DMA_ENABLE != 0U)
    hs = HAL_UART_Receive_DMA(ctx->handle, rx_data, rx_length);
#else
    hs = HAL_UART_Receive_IT(ctx->handle, rx_data, rx_length);
#endif
    if (hs != HAL_OK)
    {
        UART_IF_Unlock(ctx);
        return (hs == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

#if (HW_UART_DMA_ENABLE != 0U)
    hs = HAL_UART_Transmit_DMA(ctx->handle, tx_data, tx_length);
#else
    hs = HAL_UART_Transmit_IT(ctx->handle, tx_data, tx_length);
#endif
    if (hs != HAL_OK)
    {
        (void)HAL_UART_Abort(ctx->handle);
        UART_IF_Unlock(ctx);
        return (hs == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }

    result = UART_IF_WaitCompletion(ctx, ctx->rx_done, timeout_ms);
    if (result == UART_IF_OK) result = UART_IF_WaitCompletion(ctx, ctx->tx_done, timeout_ms);
    if (result == UART_IF_OK)
    {
        ctx->stats.rx_transfers++;
        ctx->stats.tx_transfers++;
    }
    UART_IF_Unlock(ctx);
    return result;
}

static hal_status_t UART_IF_ArmBufferedRx(uart_if_context_t *ctx)
{
#if (HW_UART_DMA_ENABLE != 0U)
    return HAL_UART_ReceiveToIdle_DMA_Opt(ctx->handle,
                                         ctx->buffered_rx_dma,
                                         (uint32_t)sizeof(ctx->buffered_rx_dma),
                                         HAL_UART_OPT_DMA_RX_IT_NONE);
#else
    return HAL_UART_Receive_IT(ctx->handle, &ctx->buffered_rx_byte, 1U);
#endif
}

uart_if_status_t UART_IF_StartBufferedRx(uart_if_port_t port)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    hal_status_t hs;

    if (ctx == NULL) return UART_IF_INVALID_PARAM;
    if (ctx->initialized == 0U) return UART_IF_NOT_INITIALIZED;
    if (ctx->buffered_rx_enabled != 0U) return UART_IF_OK;

    ctx->rx_stream = xStreamBufferCreate((size_t)HW_DEBUG_RX_STREAM_SIZE, 1U);
    if (ctx->rx_stream == NULL) return UART_IF_ERROR;

    ctx->error = 0U;
    ctx->buffered_rx_enabled = 1U;
    hs = UART_IF_ArmBufferedRx(ctx);
    if (hs != HAL_OK)
    {
        ctx->buffered_rx_enabled = 0U;
        vStreamBufferDelete(ctx->rx_stream);
        ctx->rx_stream = NULL;
        return (hs == HAL_BUSY) ? UART_IF_BUSY : UART_IF_ERROR;
    }
    return UART_IF_OK;
}

uint32_t UART_IF_ReadBuffered(uart_if_port_t port,
                              uint8_t *data,
                              uint32_t max_length,
                              uint32_t timeout_ms)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    TickType_t ticks;
    size_t received;

    if ((ctx == NULL) || (data == NULL) || (max_length == 0U) ||
        (ctx->initialized == 0U) || (ctx->buffered_rx_enabled == 0U) ||
        (ctx->rx_stream == NULL)) return 0U;

    ticks = pdMS_TO_TICKS(timeout_ms);
    if ((timeout_ms != 0U) && (ticks == 0U)) ticks = 1U;
    received = xStreamBufferReceive(ctx->rx_stream, data, (size_t)max_length, ticks);
    return (uint32_t)received;
}

void UART_IF_GetStats(uart_if_port_t port, uart_if_stats_t *stats)
{
    uart_if_context_t *ctx = UART_IF_GetContext(port);
    if (stats == NULL) return;
    memset(stats, 0, sizeof(*stats));
    if ((ctx == NULL) || (ctx->initialized == 0U)) return;
    *stats = ctx->stats;
    if (ctx->rx_stream != NULL)
    {
        stats->stream_bytes_available = (uint32_t)xStreamBufferBytesAvailable(ctx->rx_stream);
    }
}

void HAL_UART_TxCpltCallback(hal_uart_handle_t *huart)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    if (ctx != NULL)
    {
        (void)xSemaphoreGiveFromISR(ctx->tx_done, &hpw);
        portYIELD_FROM_ISR(hpw);
    }
}

void HAL_UART_RxCpltCallback(hal_uart_handle_t *huart,
                             uint32_t size_byte,
                             hal_uart_rx_event_types_t rx_event)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    size_t sent;
    (void)rx_event;

    if (ctx == NULL) return;

    if ((ctx->buffered_rx_enabled != 0U) && (ctx->rx_stream != NULL))
    {
#if (HW_UART_DMA_ENABLE != 0U)
        if (size_byte > (uint32_t)sizeof(ctx->buffered_rx_dma))
        {
            size_byte = (uint32_t)sizeof(ctx->buffered_rx_dma);
        }
        sent = xStreamBufferSendFromISR(ctx->rx_stream,
                                        ctx->buffered_rx_dma,
                                        (size_t)size_byte,
                                        &hpw);
        ctx->stats.buffered_rx_bytes += (uint32_t)sent;
        ctx->stats.buffered_rx_dropped += (size_byte - (uint32_t)sent);
#else
        sent = xStreamBufferSendFromISR(ctx->rx_stream,
                                        &ctx->buffered_rx_byte,
                                        1U,
                                        &hpw);
        ctx->stats.buffered_rx_bytes += (uint32_t)sent;
        ctx->stats.buffered_rx_dropped += (1U - (uint32_t)sent);
#endif
        if (UART_IF_ArmBufferedRx(ctx) != HAL_OK)
        {
            ctx->error = 1U;
            ctx->stats.errors++;
        }
        portYIELD_FROM_ISR(hpw);
        return;
    }

    (void)xSemaphoreGiveFromISR(ctx->rx_done, &hpw);
    portYIELD_FROM_ISR(hpw);
}

void HAL_UART_ErrorCallback(hal_uart_handle_t *huart)
{
    uart_if_context_t *ctx = UART_IF_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    if (ctx != NULL)
    {
        ctx->error = 1U;
        ctx->stats.errors++;
        (void)xSemaphoreGiveFromISR(ctx->tx_done, &hpw);
        (void)xSemaphoreGiveFromISR(ctx->rx_done, &hpw);
        portYIELD_FROM_ISR(hpw);
    }
}
