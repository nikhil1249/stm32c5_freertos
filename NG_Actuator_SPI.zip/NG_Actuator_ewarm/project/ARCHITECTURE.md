# NG Actuator firmware architecture

## Layering

```
Application / FreeRTOS tasks
        |
        v
TMC6460 motor middleware
        |
        v
TMC6460 register API
        |
        v
TMC6460 transport selector
   |                 |
   v                 v
UART_IF             SPI_IF
   |                 |
   +--------+--------+
            v
       BSP / HAL2
            v
        STM32C562RE
```

Only `config/hardware_config.h` selects the TMC6460 host interface.
Exactly one of `HW_TMC_UART_ENABLE` and `HW_TMC_SPI_ENABLE` must be 1.
The application and TMC motor-control layers do not contain UART/SPI selection logic.

## FreeRTOS ownership

`MotorService` is the sole owner of TMC6460 register transactions. Debug commands
(A/B/C/V/W/Z/R) are received on USART2 and placed on the motor command queue.
This prevents register reads, writes and high-rate position sampling from colliding.

The selected physical driver is RTOS-aware:
- UART uses interrupt completion semaphores.
- SPI uses interrupt-driven full-duplex transfers, a mutex and software CS.

## TMC6460 transport selection

SPI mode is the default in v10:

```c
#define HW_TMC_UART_ENABLE 0U
#define HW_TMC_SPI_ENABLE  1U
```

To return to the already-working UART transport:

```c
#define HW_TMC_UART_ENABLE 1U
#define HW_TMC_SPI_ENABLE  0U
```

No application, task, motor or register code changes are required.

## TMC6460 SPI2 mapping

- PB12: software CSN
- PB13: SPI2 SCK
- PB14: SPI2 MISO <- TMC6460 SDO
- PB15: SPI2 MOSI -> TMC6460 SDI
- SPI mode 1, MSB first
- PCLK1 144 MHz / 32 = 4.5 MHz SCK
- 48-bit TMC6460 datagrams

The TMC6460 SPI response is pipelined. A response to command N is shifted out
during command N+1. The transport layer hides this detail from the register API.

## Motor-control baseline

The current proven motion-mode values are preserved:

```c
#define TMC6460_VALUE_MOTOR_MOTION_IDLE 0x00002386UL
#define TMC6460_VALUE_MOTOR_MOTION_RUN  0x00002786UL
```

`V` uses positive velocity, `W` negative velocity, and `Z` sets velocity target
to zero while keeping the gate driver enabled and retaining the non-zero hold
limit. The code does not deliberately set the flux target to zero on Z.

## Where to extend

- New board/peripheral mapping: `config/hardware_config.h` + `bsp/`
- New generic SPI/UART behavior: `drivers/spi` or `drivers/uart`
- TMC6460 bus framing: `middleware/tmc6460/tmc6460_transport.c`
- TMC6460 registers: `middleware/tmc6460/tmc6460_registers.h`
- Reusable motor functions: `middleware/tmc6460/tmc6460_motor.c`
- Actuator profiles: `application/actuator_profile.c`
- Stall/soft-stall/supervisory state machines: `application/`
