#include "actuator_soft_stall.h"
#include "hardware_config.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stddef.h>
#include <string.h>

static volatile uint32_t s_soft_tmc_retry_count = 0U;
static volatile tmc6460_status_t s_soft_last_tmc_error = TMC6460_OK;

static int32_t ActuatorSoftStall_Abs32(int32_t value)
{
    if (value >= 0)
    {
        return value;
    }

    if (value == (int32_t)0x80000000UL)
    {
        return 0x7FFFFFFF;
    }

    return -value;
}

static uint32_t ActuatorSoftStall_AbsDiff32(int32_t a, int32_t b)
{
    int64_t diff = (int64_t)a - (int64_t)b;

    if (diff < 0LL)
    {
        diff = -diff;
    }

    if (diff > 0xFFFFFFFFLL)
    {
        return 0xFFFFFFFFUL;
    }

    return (uint32_t)diff;
}

static int32_t ActuatorSoftStall_Clamp32(int32_t value,
                                         int32_t minimum,
                                         int32_t maximum)
{
    if (value < minimum)
    {
        return minimum;
    }

    if (value > maximum)
    {
        return maximum;
    }

    return value;
}

static int32_t ActuatorSoftStall_SaturateInt64(int64_t value)
{
    if (value > 2147483647LL)
    {
        return 2147483647L;
    }

    if (value < (-2147483647LL - 1LL))
    {
        return (int32_t)0x80000000UL;
    }

    return (int32_t)value;
}

static uint8_t ActuatorSoftStall_Reached(int32_t position,
                                         int32_t boundary,
                                         int32_t position_direction_sign)
{
    if (position_direction_sign >= 0)
    {
        return (position >= boundary) ? 1U : 0U;
    }

    return (position <= boundary) ? 1U : 0U;
}

static int32_t ActuatorSoftStall_DistanceToEnd(int32_t position,
                                               int32_t target,
                                               int32_t position_direction_sign)
{
    int64_t distance;

    if (position_direction_sign >= 0)
    {
        distance = (int64_t)target - (int64_t)position;
    }
    else
    {
        distance = (int64_t)position - (int64_t)target;
    }

    return ActuatorSoftStall_SaturateInt64(distance);
}

static int32_t ActuatorSoftStall_GetFixedCreepVelocity(actuator_type_t type)
{
    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            return (int32_t)ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW;

        case ACTUATOR_TYPE_20KG:
            return (int32_t)ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW;

        case ACTUATOR_TYPE_35KG:
            return (int32_t)ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW;

        default:
            return 0;
    }
}

static int32_t ActuatorSoftStall_GetTorqueThreshold(actuator_type_t type)
{
    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            return (int32_t)ACTUATOR_SOFT_STALL_10KG_TORQUE_CONTACT_RAW;

        case ACTUATOR_TYPE_20KG:
            return (int32_t)ACTUATOR_SOFT_STALL_20KG_TORQUE_CONTACT_RAW;

        case ACTUATOR_TYPE_35KG:
            return (int32_t)ACTUATOR_SOFT_STALL_35KG_TORQUE_CONTACT_RAW;

        default:
            return 0;
    }
}

static void ActuatorSoftStall_RecordTmcFailure(tmc6460_status_t status)
{
    s_soft_last_tmc_error = status;
    s_soft_tmc_retry_count++;
}

static tmc6460_status_t ActuatorSoftStall_ReadMotionRetry(
    tmc6460_motor_t *motor,
    tmc6460_motion_sample_t *sample)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorReadMotionSample(motor, sample);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorSoftStall_RecordTmcFailure(status);

        if (attempt < ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorSoftStall_ReadPositionRetry(
    tmc6460_motor_t *motor,
    int32_t *position_raw)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorReadPosition(motor, position_raw);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorSoftStall_RecordTmcFailure(status);

        if (attempt < ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorSoftStall_SetVelocityRetry(
    tmc6460_motor_t *motor,
    int32_t velocity_raw)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorSetVelocity(motor, velocity_raw);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorSoftStall_RecordTmcFailure(status);

        if (attempt < ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static tmc6460_status_t ActuatorSoftStall_StopHoldRetry(tmc6460_motor_t *motor)
{
    tmc6460_status_t status = TMC6460_ERROR;
    uint32_t attempt;

    for (attempt = 0U;
         attempt <= ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT;
         attempt++)
    {
        status = TMC6460_MotorStopHold(motor);
        if (status == TMC6460_OK)
        {
            return TMC6460_OK;
        }

        ActuatorSoftStall_RecordTmcFailure(status);

        if (attempt < ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT)
        {
            vTaskDelay(pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS));
        }
    }

    return status;
}

static void ActuatorSoftStall_Notify(
    actuator_soft_stall_progress_cb_t cb,
    void *context,
    actuator_soft_stall_event_t event,
    actuator_soft_stall_status_t status,
    actuator_soft_stall_stage_t stage,
    actuator_soft_stall_direction_t direction,
    const tmc6460_motion_sample_t *sample,
    int32_t target_end_raw,
    int32_t creep_start_raw,
    int32_t position_direction_sign,
    uint8_t position_stable,
    uint8_t velocity_low,
    uint8_t torque_high)
{
    actuator_soft_stall_progress_t progress;

    if (cb == NULL)
    {
        return;
    }

    memset(&progress, 0, sizeof(progress));
    progress.event = event;
    progress.status = status;
    progress.stage = stage;
    progress.direction = direction;
    progress.target_end_raw = target_end_raw;
    progress.creep_start_raw = creep_start_raw;
    progress.position_stable = position_stable;
    progress.velocity_low = velocity_low;
    progress.torque_high = torque_high;

    if (sample != NULL)
    {
        progress.position_raw = sample->position_raw;
        progress.velocity_raw = sample->velocity_raw;
        progress.torque_raw = sample->torque_raw;
        progress.distance_to_end_counts =
            ActuatorSoftStall_DistanceToEnd(sample->position_raw,
                                            target_end_raw,
                                            position_direction_sign);
    }

    cb(&progress, context);
}

static int32_t ActuatorSoftStall_ComputeBoundary(int32_t target_end_raw,
                                                 int32_t position_direction_sign,
                                                 uint32_t stroke_counts,
                                                 uint32_t percentage)
{
    uint32_t remaining_percent;
    uint64_t remaining_counts;
    int64_t boundary;

    if (percentage > 100U)
    {
        percentage = 100U;
    }

    remaining_percent = 100U - percentage;
    remaining_counts =
        ((uint64_t)stroke_counts * (uint64_t)remaining_percent) / 100ULL;

    boundary = (int64_t)target_end_raw -
        ((int64_t)position_direction_sign * (int64_t)remaining_counts);

    return ActuatorSoftStall_SaturateInt64(boundary);
}

static int32_t ActuatorSoftStall_ComputeCreepVelocity(
    const actuator_profile_t *profile,
    int32_t cruise_velocity_abs)
{
    int32_t creep_velocity;
    int32_t fixed_velocity;

    fixed_velocity = ActuatorSoftStall_GetFixedCreepVelocity(profile->type);

    if (fixed_velocity > 0)
    {
        creep_velocity = fixed_velocity;
    }
    else
    {
        creep_velocity =
            (cruise_velocity_abs *
             (int32_t)ACTUATOR_SOFT_STALL_CREEP_VELOCITY_PERCENT) / 100;
    }

    creep_velocity = ActuatorSoftStall_Clamp32(
        creep_velocity,
        (int32_t)ACTUATOR_SOFT_STALL_CREEP_MIN_RAW,
        (int32_t)ACTUATOR_SOFT_STALL_CREEP_MAX_RAW);

    if (creep_velocity >= cruise_velocity_abs)
    {
        creep_velocity = cruise_velocity_abs / 2;
        if (creep_velocity < 1)
        {
            creep_velocity = 1;
        }
    }

    return creep_velocity;
}

actuator_soft_stall_status_t ActuatorSoftStall_Run(
    tmc6460_motor_t *motor,
    const actuator_profile_t *profile,
    const actuator_calibration_result_t *calibration,
    actuator_soft_stall_direction_t direction,
    volatile uint8_t *abort_requested,
    actuator_soft_stall_result_t *result,
    actuator_soft_stall_progress_cb_t progress_cb,
    void *progress_context)
{
#if (ACTUATOR_SOFT_STALL_ENABLE != 0U)
    tmc6460_motion_sample_t sample;
    tmc6460_status_t tmc_status;
    actuator_soft_stall_status_t final_status;
    actuator_soft_stall_stage_t stage;
    TickType_t start_tick;
    TickType_t stage_tick;
    TickType_t last_wake;
    TickType_t sample_ticks;
    TickType_t max_move_ticks;
    TickType_t startup_blanking_ticks;
    TickType_t creep_blanking_ticks;
    uint32_t stable_count = 0U;
    uint32_t position_only_count = 0U;
    uint32_t stable_required;
    uint32_t position_only_required;
    uint32_t delta_counts;
    uint32_t overshoot_counts;
    int32_t last_position = 0;
    int32_t position_direction_sign;
    int32_t target_end_raw;
    int32_t creep_start_raw;
    int32_t contact_arm_raw;
    int32_t cruise_velocity_abs;
    int32_t creep_velocity_abs;
    int32_t commanded_velocity;
    int32_t velocity_stop_threshold;
    int32_t torque_threshold;
    int32_t current_position;
    int32_t overshoot_boundary;
    uint8_t have_previous = 0U;
    uint8_t contact_armed;
    uint8_t position_stable;
    uint8_t velocity_low;
    uint8_t torque_high;
    uint8_t contact_vote;

    if ((motor == NULL) || (profile == NULL) ||
        (calibration == NULL) || (result == NULL))
    {
        return ACTUATOR_SOFT_STALL_STATUS_INVALID_PARAM;
    }

    if (motor->initialized == 0U)
    {
        return ACTUATOR_SOFT_STALL_STATUS_NOT_INITIALIZED;
    }

    if ((calibration->valid == 0U) || (calibration->stroke_counts == 0U))
    {
        return ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
    }

    if ((direction != ACTUATOR_SOFT_STALL_DIRECTION_CW) &&
        (direction != ACTUATOR_SOFT_STALL_DIRECTION_CCW))
    {
        return ACTUATOR_SOFT_STALL_STATUS_INVALID_PARAM;
    }

    memset(result, 0, sizeof(*result));
    memset(&sample, 0, sizeof(sample));
    result->direction = direction;

    s_soft_tmc_retry_count = 0U;
    s_soft_last_tmc_error = TMC6460_OK;

    if (abort_requested != NULL)
    {
        *abort_requested = 0U;
    }

    /* Position-count direction can be opposite to velocity command sign. The
     * calibration result is the authority for position comparison. */
    position_direction_sign = calibration->direction_sign;
    if (direction == ACTUATOR_SOFT_STALL_DIRECTION_CCW)
    {
        position_direction_sign = -position_direction_sign;
    }

    target_end_raw =
        (direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ?
            calibration->ninety_raw : calibration->zero_raw;

    creep_start_raw = ActuatorSoftStall_ComputeBoundary(
        target_end_raw,
        position_direction_sign,
        calibration->stroke_counts,
        ACTUATOR_SOFT_STALL_CREEP_START_PERCENT);

    contact_arm_raw = ActuatorSoftStall_ComputeBoundary(
        target_end_raw,
        position_direction_sign,
        calibration->stroke_counts,
        ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT);

    cruise_velocity_abs =
        (ActuatorSoftStall_Abs32(profile->motor.default_velocity_raw) *
         (int32_t)ACTUATOR_SOFT_STALL_CRUISE_VELOCITY_PERCENT) / 100;
    if (cruise_velocity_abs < 1)
    {
        cruise_velocity_abs = 1;
    }

    creep_velocity_abs =
        ActuatorSoftStall_ComputeCreepVelocity(profile, cruise_velocity_abs);

    result->creep_start_raw = creep_start_raw;
    result->contact_arm_raw = contact_arm_raw;
    result->target_end_raw = target_end_raw;
    result->cruise_velocity_raw =
        (direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ?
            cruise_velocity_abs : -cruise_velocity_abs;
    result->creep_velocity_raw =
        (direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ?
            creep_velocity_abs : -creep_velocity_abs;

    tmc_status = ActuatorSoftStall_ReadPositionRetry(motor, &current_position);
    if (tmc_status != TMC6460_OK)
    {
        result->status = ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
        result->tmc_retry_count = s_soft_tmc_retry_count;
        return result->status;
    }

    result->start_position_raw = current_position;

    /* If already at this calibrated end, simply reinforce HOLD. */
    if (ActuatorSoftStall_AbsDiff32(current_position, target_end_raw) <=
        (uint32_t)ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS)
    {
        tmc_status = ActuatorSoftStall_StopHoldRetry(motor);
        result->final_position_raw = current_position;
        result->status = (tmc_status == TMC6460_OK) ?
            ACTUATOR_SOFT_STALL_STATUS_OK :
            ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
        result->tmc_retry_count = s_soft_tmc_retry_count;
        return result->status;
    }

    sample.position_raw = current_position;
    ActuatorSoftStall_Notify(progress_cb,
                             progress_context,
                             ACTUATOR_SOFT_STALL_EVENT_START,
                             ACTUATOR_SOFT_STALL_STATUS_OK,
                             ACTUATOR_SOFT_STALL_STAGE_IDLE,
                             direction,
                             &sample,
                             target_end_raw,
                             creep_start_raw,
                             position_direction_sign,
                             0U,
                             0U,
                             0U);

    /* If the command starts inside the calibrated creep zone, do not accelerate
     * back to cruise speed. */
    if (ActuatorSoftStall_Reached(current_position,
                                  creep_start_raw,
                                  position_direction_sign) != 0U)
    {
        stage = ACTUATOR_SOFT_STALL_STAGE_CREEP;
        commanded_velocity = result->creep_velocity_raw;
        result->creep_entered = 1U;
    }
    else
    {
        stage = ACTUATOR_SOFT_STALL_STAGE_CRUISE;
        commanded_velocity = result->cruise_velocity_raw;
    }

    tmc_status = ActuatorSoftStall_SetVelocityRetry(motor, commanded_velocity);
    if (tmc_status != TMC6460_OK)
    {
        result->status = ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
        result->tmc_retry_count = s_soft_tmc_retry_count;
        ActuatorSoftStall_Notify(progress_cb,
                                 progress_context,
                                 ACTUATOR_SOFT_STALL_EVENT_ERROR,
                                 result->status,
                                 stage,
                                 direction,
                                 &sample,
                                 target_end_raw,
                                 creep_start_raw,
                                 position_direction_sign,
                                 0U,
                                 0U,
                                 0U);
        return result->status;
    }

    ActuatorSoftStall_Notify(progress_cb,
                             progress_context,
                             (stage == ACTUATOR_SOFT_STALL_STAGE_CREEP) ?
                                 ACTUATOR_SOFT_STALL_EVENT_CREEP :
                                 ACTUATOR_SOFT_STALL_EVENT_CRUISE,
                             ACTUATOR_SOFT_STALL_STATUS_OK,
                             stage,
                             direction,
                             &sample,
                             target_end_raw,
                             creep_start_raw,
                             position_direction_sign,
                             0U,
                             0U,
                             0U);

    sample_ticks = pdMS_TO_TICKS(1000U / ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ);
    if (sample_ticks == (TickType_t)0U)
    {
        sample_ticks = (TickType_t)1U;
    }

    stable_required =
        ((ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS *
          ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ) + 999U) / 1000U;
    if (stable_required == 0U)
    {
        stable_required = 1U;
    }

    position_only_required =
        ((ACTUATOR_SOFT_STALL_POSITION_ONLY_CONFIRM_MS *
          ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ) + 999U) / 1000U;
    if (position_only_required == 0U)
    {
        position_only_required = 1U;
    }

    max_move_ticks = pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_MAX_MOVE_TIME_MS);
    startup_blanking_ticks =
        pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_STARTUP_BLANKING_MS);
    creep_blanking_ticks =
        pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_CREEP_BLANKING_MS);

    torque_threshold = ActuatorSoftStall_GetTorqueThreshold(profile->type);

    overshoot_counts =
        (uint32_t)(((uint64_t)calibration->stroke_counts *
                    (uint64_t)ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100) /
                   10000ULL);
    if (overshoot_counts <
        (uint32_t)ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS)
    {
        overshoot_counts =
            (uint32_t)ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS;
    }

    overshoot_boundary = ActuatorSoftStall_SaturateInt64(
        (int64_t)target_end_raw +
        ((int64_t)position_direction_sign * (int64_t)overshoot_counts));

    start_tick = xTaskGetTickCount();
    stage_tick = start_tick;
    last_wake = start_tick;
    final_status = ACTUATOR_SOFT_STALL_STATUS_OK;

    for (;;)
    {
        if ((abort_requested != NULL) && (*abort_requested != 0U))
        {
            (void)ActuatorSoftStall_StopHoldRetry(motor);
            final_status = ACTUATOR_SOFT_STALL_STATUS_ABORTED;
            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_ABORTED,
                                     final_status,
                                     ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     0U,
                                     0U,
                                     0U);
            break;
        }

        tmc_status = ActuatorSoftStall_ReadMotionRetry(motor, &sample);
        if (tmc_status != TMC6460_OK)
        {
            (void)ActuatorSoftStall_StopHoldRetry(motor);
            final_status = ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_ERROR,
                                     final_status,
                                     ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     0U,
                                     0U,
                                     0U);
            break;
        }

        /* Transition from cruise to creep at a calibrated percentage of the
         * full stroke. This is the STM32 equivalent of the Qt learned soft
         * boundary concept, but continues at creep speed to touch the real end. */
        if ((stage == ACTUATOR_SOFT_STALL_STAGE_CRUISE) &&
            (ActuatorSoftStall_Reached(sample.position_raw,
                                       creep_start_raw,
                                       position_direction_sign) != 0U))
        {
            tmc_status = ActuatorSoftStall_SetVelocityRetry(
                motor,
                result->creep_velocity_raw);
            if (tmc_status != TMC6460_OK)
            {
                (void)ActuatorSoftStall_StopHoldRetry(motor);
                final_status = ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
                break;
            }

            stage = ACTUATOR_SOFT_STALL_STAGE_CREEP;
            stage_tick = xTaskGetTickCount();
            stable_count = 0U;
            position_only_count = 0U;
            have_previous = 0U;
            result->creep_entered = 1U;

            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_CREEP,
                                     ACTUATOR_SOFT_STALL_STATUS_OK,
                                     stage,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     0U,
                                     0U,
                                     0U);
        }

        contact_armed =
            (ActuatorSoftStall_Reached(sample.position_raw,
                                       contact_arm_raw,
                                       position_direction_sign) != 0U) ? 1U : 0U;

        position_stable = 0U;
        velocity_low = 0U;
        torque_high = 0U;
        contact_vote = 0U;

        if (have_previous != 0U)
        {
            delta_counts = ActuatorSoftStall_AbsDiff32(sample.position_raw,
                                                       last_position);
            position_stable =
                (delta_counts <=
                 (uint32_t)ACTUATOR_SOFT_STALL_POSITION_DELTA_COUNTS) ? 1U : 0U;

            velocity_stop_threshold =
                (creep_velocity_abs *
                 (int32_t)ACTUATOR_SOFT_STALL_VELOCITY_STOP_PERCENT) / 100;
            if (velocity_stop_threshold <
                (int32_t)ACTUATOR_SOFT_STALL_VELOCITY_STOP_MIN_RAW)
            {
                velocity_stop_threshold =
                    (int32_t)ACTUATOR_SOFT_STALL_VELOCITY_STOP_MIN_RAW;
            }

            velocity_low =
                (ActuatorSoftStall_Abs32(sample.velocity_raw) <=
                 velocity_stop_threshold) ? 1U : 0U;

            if (torque_threshold > 0)
            {
                torque_high =
                    (ActuatorSoftStall_Abs32(sample.torque_raw) >=
                     torque_threshold) ? 1U : 0U;
            }

            if ((contact_armed != 0U) &&
                (stage == ACTUATOR_SOFT_STALL_STAGE_CREEP) &&
                ((xTaskGetTickCount() - start_tick) >= startup_blanking_ticks) &&
                ((xTaskGetTickCount() - stage_tick) >= creep_blanking_ticks))
            {
                /* Same strong idea as the working Qt logic: 2-of-3 vote.
                 * With torque threshold disabled, this naturally becomes
                 * position-stable + velocity-low. Torque alone never stops. */
                contact_vote =
                    (((position_stable != 0U) && (velocity_low != 0U)) ||
                     ((position_stable != 0U) && (torque_high != 0U)) ||
                     ((velocity_low != 0U) && (torque_high != 0U))) ? 1U : 0U;

                if (position_stable != 0U)
                {
                    position_only_count++;
                }
                else
                {
                    position_only_count = 0U;
                }

                if (contact_vote != 0U)
                {
                    stable_count++;
                }
                else
                {
                    stable_count = 0U;
                }
            }
            else
            {
                stable_count = 0U;
                position_only_count = 0U;
            }
        }

        last_position = sample.position_raw;
        have_previous = 1U;

        ActuatorSoftStall_Notify(progress_cb,
                                 progress_context,
                                 ACTUATOR_SOFT_STALL_EVENT_SAMPLE,
                                 ACTUATOR_SOFT_STALL_STATUS_OK,
                                 stage,
                                 direction,
                                 &sample,
                                 target_end_raw,
                                 creep_start_raw,
                                 position_direction_sign,
                                 position_stable,
                                 velocity_low,
                                 torque_high);

        /* Do not stop merely because the calibrated raw endpoint was crossed.
         * Calibration endpoint scatter is expected. Continue at creep speed so
         * the mechanism actually touches the physical end softly; the sustained
         * position/velocity/torque vote below confirms contact. The overshoot
         * boundary remains a hard software guard. */

        if ((stable_count >= stable_required) ||
            (position_only_count >= position_only_required))
        {
            tmc_status = ActuatorSoftStall_StopHoldRetry(motor);
            final_status = (tmc_status == TMC6460_OK) ?
                ACTUATOR_SOFT_STALL_STATUS_OK :
                ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR;
            result->contact_confirmed = 1U;
            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_CONTACT,
                                     final_status,
                                     ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     position_stable,
                                     velocity_low,
                                     torque_high);
            break;
        }

        if (ActuatorSoftStall_Reached(sample.position_raw,
                                      overshoot_boundary,
                                      position_direction_sign) != 0U)
        {
            (void)ActuatorSoftStall_StopHoldRetry(motor);
            final_status = ACTUATOR_SOFT_STALL_STATUS_OVERSHOOT;
            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_ERROR,
                                     final_status,
                                     ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     position_stable,
                                     velocity_low,
                                     torque_high);
            break;
        }

        if ((xTaskGetTickCount() - start_tick) >= max_move_ticks)
        {
            (void)ActuatorSoftStall_StopHoldRetry(motor);
            final_status = ACTUATOR_SOFT_STALL_STATUS_TIMEOUT;
            ActuatorSoftStall_Notify(progress_cb,
                                     progress_context,
                                     ACTUATOR_SOFT_STALL_EVENT_ERROR,
                                     final_status,
                                     ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                     direction,
                                     &sample,
                                     target_end_raw,
                                     creep_start_raw,
                                     position_direction_sign,
                                     position_stable,
                                     velocity_low,
                                     torque_high);
            break;
        }

        vTaskDelayUntil(&last_wake, sample_ticks);
    }

    vTaskDelay(pdMS_TO_TICKS(ACTUATOR_SOFT_STALL_HOLD_SETTLE_MS));

    current_position = sample.position_raw;
    if (ActuatorSoftStall_ReadPositionRetry(motor, &current_position) == TMC6460_OK)
    {
        result->final_position_raw = current_position;
    }
    else
    {
        result->final_position_raw = sample.position_raw;
    }

    result->elapsed_ms =
        (uint32_t)((xTaskGetTickCount() - start_tick) * portTICK_PERIOD_MS);
    result->tmc_retry_count = s_soft_tmc_retry_count;
    result->status = final_status;

    if (final_status == ACTUATOR_SOFT_STALL_STATUS_OK)
    {
        ActuatorSoftStall_Notify(progress_cb,
                                 progress_context,
                                 ACTUATOR_SOFT_STALL_EVENT_COMPLETE,
                                 final_status,
                                 ACTUATOR_SOFT_STALL_STAGE_HOLD,
                                 direction,
                                 &sample,
                                 target_end_raw,
                                 creep_start_raw,
                                 position_direction_sign,
                                 position_stable,
                                 velocity_low,
                                 torque_high);
    }

    return final_status;
#else
    (void)motor;
    (void)profile;
    (void)calibration;
    (void)direction;
    (void)abort_requested;
    (void)result;
    (void)progress_cb;
    (void)progress_context;
    return ACTUATOR_SOFT_STALL_STATUS_INVALID_PARAM;
#endif
}

uint32_t ActuatorSoftStall_GetTmcRetryCount(void)
{
    return s_soft_tmc_retry_count;
}

tmc6460_status_t ActuatorSoftStall_GetLastTmcError(void)
{
    return s_soft_last_tmc_error;
}
