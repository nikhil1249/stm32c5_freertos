#include "actuator_reference.h"
#include "actuator_calibration_config.h"

#include <stddef.h>
#include <string.h>

static int32_t ActuatorReference_SaturateInt64(int64_t value)
{
    if (value > 2147483647LL)
    {
        return 2147483647L;
    }

    if (value < (-2147483647LL - 1LL))
    {
        return (int32_t)0x80000000UL;
    }

    return (int32_t)value;
}

void ActuatorReference_Clear(actuator_reference_t *reference)
{
    if (reference != NULL)
    {
        memset(reference, 0, sizeof(*reference));
        reference->direction_sign = 1L;
    }
}

uint8_t ActuatorReference_LoadCompileTime(actuator_type_t type,
                                          actuator_reference_t *reference)
{
    uint8_t valid = 0U;
    uint32_t stroke = 0U;
    int32_t direction = 1L;
    int32_t zero_ref = 0L;
    int32_t ninety_ref = 0L;

    if (reference == NULL)
    {
        return 0U;
    }

    ActuatorReference_Clear(reference);
    reference->actuator_type = type;

    switch (type)
    {
        case ACTUATOR_TYPE_10KG:
            valid = (uint8_t)ACT_CAL_10KG_VALID;
            stroke = (uint32_t)ACT_CAL_10KG_STROKE_COUNTS;
            direction = (int32_t)ACT_CAL_10KG_DIRECTION_SIGN;
            zero_ref = (int32_t)ACT_CAL_10KG_ZERO_RAW_REFERENCE;
            ninety_ref = (int32_t)ACT_CAL_10KG_NINETY_RAW_REFERENCE;
            break;

        case ACTUATOR_TYPE_20KG:
            valid = (uint8_t)ACT_CAL_20KG_VALID;
            stroke = (uint32_t)ACT_CAL_20KG_STROKE_COUNTS;
            direction = (int32_t)ACT_CAL_20KG_DIRECTION_SIGN;
            zero_ref = (int32_t)ACT_CAL_20KG_ZERO_RAW_REFERENCE;
            ninety_ref = (int32_t)ACT_CAL_20KG_NINETY_RAW_REFERENCE;
            break;

        case ACTUATOR_TYPE_35KG:
            valid = (uint8_t)ACT_CAL_35KG_VALID;
            stroke = (uint32_t)ACT_CAL_35KG_STROKE_COUNTS;
            direction = (int32_t)ACT_CAL_35KG_DIRECTION_SIGN;
            zero_ref = (int32_t)ACT_CAL_35KG_ZERO_RAW_REFERENCE;
            ninety_ref = (int32_t)ACT_CAL_35KG_NINETY_RAW_REFERENCE;
            break;

        default:
            return 0U;
    }

    if ((valid == 0U) ||
        (stroke < (uint32_t)ACTUATOR_CALIBRATION_MIN_STROKE_COUNTS) ||
        ((direction != 1L) && (direction != -1L)))
    {
        return 0U;
    }

    reference->calibration_available = 1U;
    reference->runtime_anchor_valid = 0U;
    reference->stroke_counts = stroke;
    reference->direction_sign = direction;
    reference->stored_zero_raw_reference = zero_ref;
    reference->stored_ninety_raw_reference = ninety_ref;

    return 1U;
}

void ActuatorReference_UpdateFromCalibration(
    actuator_reference_t *reference,
    const actuator_calibration_result_t *calibration)
{
    if ((reference == NULL) || (calibration == NULL) ||
        (calibration->valid == 0U) || (calibration->stroke_counts == 0U))
    {
        return;
    }

    reference->actuator_type = calibration->actuator_type;
    reference->calibration_available = 1U;
    reference->runtime_anchor_valid = 1U;
    reference->stroke_counts = calibration->stroke_counts;
    reference->direction_sign = calibration->direction_sign;
    reference->stored_zero_raw_reference = calibration->zero_raw;
    reference->stored_ninety_raw_reference = calibration->ninety_raw;
    reference->runtime_zero_raw = calibration->zero_raw;
    reference->runtime_ninety_raw = calibration->ninety_raw;
}

void ActuatorReference_AnchorAtEnd(actuator_reference_t *reference,
                                   uint8_t reached_ninety,
                                   int32_t position_raw)
{
    int64_t signed_stroke;

    if ((reference == NULL) ||
        (reference->calibration_available == 0U) ||
        (reference->stroke_counts == 0U))
    {
        return;
    }

    signed_stroke =
        (int64_t)reference->direction_sign * (int64_t)reference->stroke_counts;

    if (reached_ninety != 0U)
    {
        reference->runtime_ninety_raw = position_raw;
        reference->runtime_zero_raw = ActuatorReference_SaturateInt64(
            (int64_t)position_raw - signed_stroke);
    }
    else
    {
        reference->runtime_zero_raw = position_raw;
        reference->runtime_ninety_raw = ActuatorReference_SaturateInt64(
            (int64_t)position_raw + signed_stroke);
    }

    reference->runtime_anchor_valid = 1U;
}

uint8_t ActuatorReference_ToCalibrationResult(
    const actuator_reference_t *reference,
    actuator_calibration_result_t *result)
{
    int64_t signed_stroke;

    if ((reference == NULL) || (result == NULL))
    {
        return 0U;
    }

    memset(result, 0, sizeof(*result));

    if ((reference->calibration_available == 0U) ||
        (reference->runtime_anchor_valid == 0U) ||
        (reference->stroke_counts == 0U))
    {
        return 0U;
    }

    signed_stroke =
        (int64_t)reference->direction_sign * (int64_t)reference->stroke_counts;

    result->actuator_type = reference->actuator_type;
    result->zero_raw = reference->runtime_zero_raw;
    result->ninety_raw = reference->runtime_ninety_raw;
    result->zero_average_raw = reference->runtime_zero_raw;
    result->ninety_average_raw = reference->runtime_ninety_raw;
    result->stroke_counts = reference->stroke_counts;
    result->direction_sign = reference->direction_sign;
    result->stroke_signed_counts = ActuatorReference_SaturateInt64(signed_stroke);
    result->valid = 1U;

    return 1U;
}

int32_t ActuatorReference_PositionToDegX100(
    const actuator_reference_t *reference,
    int32_t position_raw)
{
    int64_t numerator;
    int64_t denominator;

    if ((reference == NULL) ||
        (reference->runtime_anchor_valid == 0U) ||
        (reference->stroke_counts == 0U) ||
        ((reference->direction_sign != 1L) &&
         (reference->direction_sign != -1L)))
    {
        return 0;
    }

    numerator =
        ((int64_t)position_raw - (int64_t)reference->runtime_zero_raw) * 9000LL;
    denominator =
        (int64_t)reference->direction_sign * (int64_t)reference->stroke_counts;

    if (denominator == 0LL)
    {
        return 0;
    }

    return ActuatorReference_SaturateInt64(numerator / denominator);
}
