#ifndef ACTUATOR_SOFT_STALL_CONFIG_H
#define ACTUATOR_SOFT_STALL_CONFIG_H

#include <stdint.h>

/* ========================================================================== */
/* Software soft-stall / soft-end-stop configuration                          */
/* ========================================================================== */
/*
 * Baseline: v11.1 calibration + v12 soft stall, updated for persistent
 * compile-time calibration parameters and reboot-safe X/Y operation.
 *
 * Important position-model rule:
 * TMC6460 Hall POSITION_ACTUAL is incremental.  STROKE_COUNTS and direction
 * are reusable across resets; old absolute raw endpoint values are not.
 * Therefore, after reset, the first X or Y command automatically performs a
 * low-speed soft end-reference search.  It touches the requested end softly,
 * establishes the current-session raw reference, and then all subsequent X/Y
 * commands use normal CRUISE -> CREEP -> CONTACT behavior.
 */

#define ACTUATOR_SOFT_STALL_ENABLE                              1U
#define ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ                     200U

/* Normal movement before the creep zone. */
#define ACTUATOR_SOFT_STALL_CRUISE_VELOCITY_PERCENT            100U

/* Use x100 percent to permit fine tuning near the end.
 * 9600 = 96.00% = creep begins around 86.4 degrees on a 90-degree stroke.
 * 9950 = 99.50% = contact detection is armed only for the final ~0.45 degree.
 * This is intentionally much later than the older 97% arm point, which could
 * falsely accept load/spring slowdown 2-4 degrees before the real hard end. */
#define ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100          9600U
#define ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100          9950U

/* Creep speed. 250k is deliberately aligned with the proven calibration
 * velocity, which was able to reach the physical end reliably. */
#define ACTUATOR_SOFT_STALL_CREEP_VELOCITY_PERCENT              25U
#define ACTUATOR_SOFT_STALL_CREEP_MIN_RAW                   150000L
#define ACTUATOR_SOFT_STALL_CREEP_MAX_RAW                   500000L

#define ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW         250000L
#define ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW         250000L
#define ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW         250000L

/* First X/Y after reboot when compile-time calibration is valid but no current
 * raw reference exists.  Run the complete first leg at a known-safe low speed,
 * find the requested mechanical end, then anchor the session. */
#define ACTUATOR_SOFT_STALL_REFERENCE_SEARCH_ENABLE               1U
#define ACTUATOR_SOFT_STALL_10KG_REFERENCE_SEARCH_VELOCITY_RAW 250000L
#define ACTUATOR_SOFT_STALL_20KG_REFERENCE_SEARCH_VELOCITY_RAW 250000L
#define ACTUATOR_SOFT_STALL_35KG_REFERENCE_SEARCH_VELOCITY_RAW 250000L
#define ACTUATOR_SOFT_STALL_REFERENCE_STARTUP_BLANKING_MS        400U
#define ACTUATOR_SOFT_STALL_REFERENCE_CONTACT_CONFIRM_MS        250U
#define ACTUATOR_SOFT_STALL_REFERENCE_POSITION_ONLY_MS          600U
/* Maximum position travel during first end search, as x100 percent of calibrated
 * full stroke. 11500 = 115%. Starting anywhere inside the stroke requires <=100%. */
#define ACTUATOR_SOFT_STALL_REFERENCE_MAX_TRAVEL_PERCENT_X100  11500U

/* Ignore contact voting after motion/creep transition. */
#define ACTUATOR_SOFT_STALL_STARTUP_BLANKING_MS                 250U
#define ACTUATOR_SOFT_STALL_CREEP_BLANKING_MS                   120U

/* Contact/stall observation. */
#define ACTUATOR_SOFT_STALL_POSITION_DELTA_COUNTS                 8L
#define ACTUATOR_SOFT_STALL_VELOCITY_STOP_PERCENT                12U
#define ACTUATOR_SOFT_STALL_VELOCITY_STOP_MIN_RAW              1000L
#define ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS                  180U
#define ACTUATOR_SOFT_STALL_POSITION_ONLY_CONFIRM_MS            400U

/* Optional per-actuator torque corroboration. 0 disables torque threshold.
 * Torque alone never declares an end. */
#define ACTUATOR_SOFT_STALL_10KG_TORQUE_CONTACT_RAW               0L
#define ACTUATOR_SOFT_STALL_20KG_TORQUE_CONTACT_RAW               0L
#define ACTUATOR_SOFT_STALL_35KG_TORQUE_CONTACT_RAW               0L

/* If the actuator slows/stops BEFORE the contact-arm window, it is not yet an
 * end.  Increase creep speed in small steps so spring/load cannot cause the
 * old 3-4 degree early-stop behavior. */
#define ACTUATOR_SOFT_STALL_PRE_END_BOOST_ENABLE                   1U
#define ACTUATOR_SOFT_STALL_PRE_END_STALL_CONFIRM_MS             120U
#define ACTUATOR_SOFT_STALL_CREEP_BOOST_STEP_RAW               50000L
#define ACTUATOR_SOFT_STALL_CREEP_BOOST_MAX_RAW               450000L

/* The calibrated raw endpoint is not an immediate stop point. Continue at
 * creep until physical contact.  A 2% guard allows calibration scatter while
 * still bounding travel in case feedback/contact detection fails. */
#define ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS             16L
#define ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100           200U /* 2.00% */

#define ACTUATOR_SOFT_STALL_MAX_MOVE_TIME_MS                   30000U
#define ACTUATOR_SOFT_STALL_HOLD_SETTLE_MS                       100U

#define ACTUATOR_SOFT_STALL_TMC_RETRY_COUNT                        3U
#define ACTUATOR_SOFT_STALL_TMC_RETRY_DELAY_MS                     2U

/* ========================================================================== */
/* Compile-time checks                                                        */
/* ========================================================================== */

#if (ACTUATOR_SOFT_STALL_ENABLE != 0U)

#if ((ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ == 0U) || \
     (ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ > 1000U))
#error "Invalid ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ"
#endif

#if ((ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 == 0U) || \
     (ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 >= 10000U))
#error "Creep start must be between 0.01% and 99.99%"
#endif

#if ((ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 < \
      ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100) || \
     (ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 > 10000U))
#error "Contact arm must be >= creep start and <= 100.00%"
#endif

#if (ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS == 0U)
#error "Soft stall contact confirmation must be non-zero"
#endif

#endif /* ACTUATOR_SOFT_STALL_ENABLE */

#endif /* ACTUATOR_SOFT_STALL_CONFIG_H */
