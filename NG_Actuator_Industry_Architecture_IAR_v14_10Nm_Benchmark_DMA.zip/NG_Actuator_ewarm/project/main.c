/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : NG Actuator application entry point
  ******************************************************************************
  */
#include "main.h"
#include "bsp.h"
#include "uart_iface.h"
#include "spi_iface.h"
#include "hardware_config.h"
#include "app.h"

int main(void)
{
  /* HAL, NVIC, cache and system clock first. */
  if (mx_system_init() != SYSTEM_OK)
  {
    return -1;
  }

  /* Board-specific GPIO and UART initialization from hardware_config.h. */
  if (BSP_Init() != BSP_OK)
  {
    return -1;
  }

  /* Debug UART is always initialized here when enabled.  If TMC UART is
   * selected, UART_IF_Init() also registers the TMC UART context. */
  if (UART_IF_Init() != UART_IF_OK)
  {
    return -1;
  }

#if (HW_TMC_SPI_ENABLE != 0U)
  /* Register RTOS-aware interrupt SPI transport when SPI is selected. */
  if (SPI_IF_Init() != SPI_IF_OK)
  {
    return -1;
  }
#endif

  /* Application/device contexts. */
  if (APP_Init() != 0)
  {
    return -1;
  }

  /* Create FreeRTOS tasks. */
  if (app_synctasks_init() != 0)
  {
    return -1;
  }

  vTaskStartScheduler();

  /* Scheduler should never return. */
  for (;;)
  {
  }
}
