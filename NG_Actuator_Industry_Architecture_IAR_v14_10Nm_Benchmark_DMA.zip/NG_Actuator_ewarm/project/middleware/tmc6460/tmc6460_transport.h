#ifndef TMC6460_TRANSPORT_H
#define TMC6460_TRANSPORT_H

#include <stdint.h>

typedef enum
{
    TMC6460_TRANSPORT_OK = 0,
    TMC6460_TRANSPORT_ERROR,
    TMC6460_TRANSPORT_BUSY,
    TMC6460_TRANSPORT_TIMEOUT,
    TMC6460_TRANSPORT_INVALID_PARAM
} tmc6460_transport_status_t;

/* Interface-specific register transactions selected at compile time by
 * HW_TMC_UART_ENABLE / HW_TMC_SPI_ENABLE in hardware_config.h. */
tmc6460_transport_status_t TMC6460_TransportReadRegister(uint16_t address,
                                                         uint32_t *value,
                                                         uint32_t timeout_ms);

tmc6460_transport_status_t TMC6460_TransportWriteRegister(uint16_t address,
                                                          uint32_t value,
                                                          uint32_t timeout_ms);

#endif /* TMC6460_TRANSPORT_H */
