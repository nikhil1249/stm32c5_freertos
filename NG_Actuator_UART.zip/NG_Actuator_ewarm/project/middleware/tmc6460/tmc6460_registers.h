#ifndef TMC6460_REGISTERS_H
#define TMC6460_REGISTERS_H

#include <stdint.h>

/*
 * TMC6460 register map for the released Rev.0 data sheet (May 2026).
 *
 * IMPORTANT:
 * Earlier pre-release/Qt code used a few legacy register labels.  In Rev.0:
 *   0x153 = FOC.PID_TORQUE_FLUX_ACTUAL
 *   0x154 = FOC.PID_VELOCITY_ACTUAL
 *   0x155 = FOC.PID_POSITION_ACTUAL
 * and feedback configuration continues at 0x244..0x250.
 */

/* CHIP --------------------------------------------------------------------- */
#define TMC6460_REG_CHIP_ID                         0x0000U
#define TMC6460_REG_CHIP_INPUTS_RAW                 0x0004U
#define TMC6460_REG_CHIP_IO_MATRIX                  0x0006U
#define TMC6460_REG_CHIP_IO_PU_PD                   0x0007U
#define TMC6460_REG_CHIP_IO_CONFIG                  0x0008U
#define TMC6460_REG_CHIP_STATUS_FLAGS               0x0009U
#define TMC6460_REG_CHIP_EVENTS                     0x000AU

/* MCC / current acquisition ------------------------------------------------ */
#define TMC6460_REG_MCC_ADC_CSA_GAIN                0x00C3U

/* Motor control configuration ---------------------------------------------- */
#define TMC6460_REG_MCC_CONFIG_MOTOR_MOTION         0x0100U
#define TMC6460_REG_MCC_CONFIG_GDRV                 0x0101U
#define TMC6460_REG_MCC_CONFIG_PWM                  0x0102U
#define TMC6460_REG_MCC_CONFIG_PWM_PERIOD           0x0103U

/* FOC ---------------------------------------------------------------------- */
#define TMC6460_REG_FOC_PID_CONFIG                  0x0140U
#define TMC6460_REG_FOC_PID_FLUX_COEFF              0x0142U
#define TMC6460_REG_FOC_PID_TORQUE_COEFF            0x0143U
#define TMC6460_REG_FOC_PID_VELOCITY_COEFF          0x0145U
#define TMC6460_REG_FOC_PID_UQ_UD_LIMITS            0x0149U
#define TMC6460_REG_FOC_PID_TORQUE_FLUX_LIMITS      0x014AU
#define TMC6460_REG_FOC_PID_VELOCITY_LIMIT          0x014BU
#define TMC6460_REG_FOC_PID_TORQUE_FLUX_TARGET      0x014EU
#define TMC6460_REG_FOC_PID_VELOCITY_TARGET         0x0150U
#define TMC6460_REG_FOC_PID_TORQUE_FLUX_ACTUAL      0x0153U
#define TMC6460_REG_FOC_PID_VELOCITY_ACTUAL         0x0154U
#define TMC6460_REG_FOC_PID_POSITION_ACTUAL         0x0155U
#define TMC6460_REG_FOC_PID_POSITION_ACTUAL_OFFSET  0x0156U

/* Feedback engine ---------------------------------------------------------- */
#define TMC6460_REG_FEEDBACK_CONF_CH_A               0x0240U
#define TMC6460_REG_FEEDBACK_CONF_CH_B               0x0241U
#define TMC6460_REG_FEEDBACK_PHI_E_OFFSET            0x0242U
#define TMC6460_REG_FEEDBACK_LUT                     0x0243U
#define TMC6460_REG_FEEDBACK_VELOCITY_FRQ_CONF       0x0244U
#define TMC6460_REG_FEEDBACK_VELOCITY_PER_CONF       0x0245U
#define TMC6460_REG_FEEDBACK_VELOCITY_PER_FILTER     0x0246U
#define TMC6460_REG_FEEDBACK_PHI_CONVERTED           0x0247U
#define TMC6460_REG_FEEDBACK_CH_A                    0x0248U
#define TMC6460_REG_FEEDBACK_CH_B                    0x0249U
#define TMC6460_REG_FEEDBACK_VELOCITY_FRQ            0x024AU
#define TMC6460_REG_FEEDBACK_VELOCITY_PER            0x024BU
#define TMC6460_REG_FEEDBACK_OUTPUT_CONF             0x0250U
#define TMC6460_REG_FEEDBACK_PHI_E                   0x0251U
#define TMC6460_REG_FEEDBACK_PHI_DIFF_LIMIT          0x0252U

/* Hall decoder ------------------------------------------------------------- */
#define TMC6460_REG_HALL_MAP_CONFIG                  0x0300U
#define TMC6460_REG_HALL_DIG_COUNT                   0x0301U
#define TMC6460_REG_HALL_DIG_EVENTS                  0x030AU

/* -------------------------------------------------------------------------- */
/* Working actuator configuration - byte-for-byte match to proven Qt setup   */
/* -------------------------------------------------------------------------- */

/* CHIP configuration */
#define TMC6460_VALUE_CHIP_IO_MATRIX                 0x00000000UL
#define TMC6460_VALUE_CHIP_IO_PU_PD                  0x075800FFUL
#define TMC6460_VALUE_CHIP_IO_CONFIG                 0x70055038UL

/* Motor/current configuration */
#define TMC6460_VALUE_MCC_ADC_CSA_GAIN               0x00000005UL

/*
 * IMPORTANT: These two values intentionally match the already-proven Qt/TMC
 * setup instead of re-deriving a different mode from the data-sheet fields.
 *
 * 0x2386 is written during configuration/idle.
 * 0xE586 is the value used by the working Qt path before applying a signed
 * velocity target.  This preserves the user's validated behavior exactly.
 */
#define TMC6460_VALUE_MOTOR_MOTION_IDLE              0x00002386UL
#define TMC6460_VALUE_MOTOR_MOTION_RUN               0x0000E586UL

#define TMC6460_VALUE_GDRV_DISABLED                  0x80003431UL
#define TMC6460_VALUE_GDRV_ENABLED                   0x80013431UL
#define TMC6460_VALUE_PWM_CONFIG                     0x00000017UL

/* FOC/PID values from the proven velocity configuration screenshot. */
#define TMC6460_VALUE_PID_CONFIG                     0x00008558UL
#define TMC6460_VALUE_FLUX_COEFF                     0x01E54C51UL
#define TMC6460_VALUE_TORQUE_COEFF                   0x01E54C51UL
#define TMC6460_VALUE_VELOCITY_COEFF                 0x00960005UL
#define TMC6460_VALUE_UQ_UD_LIMITS                   0x00004E20UL

/* Feedback values from the same working configuration. */
#define TMC6460_VALUE_FEEDBACK_CH_A                  0x052AAAABUL
#define TMC6460_VALUE_FEEDBACK_CH_B                  0x06000000UL
#define TMC6460_VALUE_FEEDBACK_VELOCITY_FRQ_CONF     0x001B4F00UL
#define TMC6460_VALUE_FEEDBACK_VELOCITY_PER_CONF     0xFFF00001UL
#define TMC6460_VALUE_FEEDBACK_VELOCITY_PER_FILTER   0x00000003UL
#define TMC6460_VALUE_FEEDBACK_OUTPUT_CONF           0x00400001UL
#define TMC6460_VALUE_HALL_MAP_CONFIG                0x00000001UL

/* Register 0x242 is not written by the proven setup; leave reset/current value. */
#define TMC6460_VALUE_FEEDBACK_PHI_E_OFFSET          0x00000000UL

/* Status flag masks. */
#define TMC6460_STATUS_GDRV_ON_MASK                  0x80000000UL
#define TMC6460_STATUS_SYS_READY_MASK                0x40000000UL
#define TMC6460_STATUS_HALL_FAIL_MASK                0x00800000UL
#define TMC6460_STATUS_VEL_FAIL_MASK                 0x00000800UL
#define TMC6460_EVENT_VEL_FAIL_MASK                  0x00000800UL
#define TMC6460_GDRV_DRV_EN_BIT_MASK                 0x00010000UL

/* CHIP.INPUTS_RAW bit positions. */
#define TMC6460_INPUTS_HALL_RAW_SHIFT                3U
#define TMC6460_INPUTS_HALL_RAW_MASK                 0x00000038UL
#define TMC6460_INPUTS_HALL_LOGIC_SHIFT              22U
#define TMC6460_INPUTS_HALL_LOGIC_MASK               0x01C00000UL
#define TMC6460_INPUTS_DRV_EN_MASK                   0x00008000UL

#endif /* TMC6460_REGISTERS_H */
