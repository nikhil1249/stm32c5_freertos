#include "actuator_profile.h"

#include <stddef.h>

/*
 * Values below are taken from the latest delivered Qt ActuatorConfig.h.
 * Profile A is the current 10 Nm calibration benchmark. Its normal and maximum
 * velocity are both 9,000,000 raw as validated on the bench. Other profiles
 * remain unchanged until independently validated. The benchmark STM32 build
 * uses the validated TMC6460 velocity motion value 0x00002786.
 *
 * Add future actuator types only in this table + enum. The command and motor
 * service layers do not need to change.
 */
static const actuator_profile_t s_profiles[ACTUATOR_TYPE_COUNT] =
{
    {
        ACTUATOR_TYPE_10KG,
        'A',
        "10 Nm benchmark",
        { 1000, 1200, 1200, 9000000, 9000000 }
    },
    {
        ACTUATOR_TYPE_20KG,
        'B',
        "20 kg",
        { 1500, 1500, 2000, 1000000, 1500000 }
    },
    {
        ACTUATOR_TYPE_35KG,
        'C',
        "35 kg",
        { 2500, 2000, 2500, 1000000, 1500000 }
    }
};

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type)
{
    if ((uint32_t)type >= (uint32_t)ACTUATOR_TYPE_COUNT)
    {
        return NULL;
    }

    return &s_profiles[(uint32_t)type];
}

const actuator_profile_t *ActuatorProfile_FromCommand(char command)
{
    uint32_t i;

    if ((command >= 'a') && (command <= 'z'))
    {
        command = (char)(command - ('a' - 'A'));
    }

    for (i = 0U; i < (uint32_t)ACTUATOR_TYPE_COUNT; i++)
    {
        if (s_profiles[i].command_key == command)
        {
            return &s_profiles[i];
        }
    }

    return NULL;
}
