#ifndef MAIN_H
#define MAIN_H

#include "mx_hal_def.h"
#include "mx_system.h"
#include "mx_freertos_app.h"

#endif /* MAIN_H */
