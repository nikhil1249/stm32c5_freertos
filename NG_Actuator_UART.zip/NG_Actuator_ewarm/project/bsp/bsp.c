#include "bsp.h"
#include "hardware_config.h"

#include <stddef.h>

/*
 * Interrupt handlers have external linkage because the startup vector table
 * references these symbols.  IAR diagnostic Pa045 requires a visible
 * prototype before the function definition.  The names are selected in
 * hardware_config.h and expand to USART1_IRQHandler / USART2_IRQHandler for
 * the current board configuration.
 */
void HW_TMC_UART_IRQ_HANDLER(void);
#if (HW_DEBUG_UART_ENABLE != 0U)
void HW_DEBUG_UART_IRQ_HANDLER(void);
#endif

static hal_uart_handle_t s_tmc_uart;
#if (HW_DEBUG_UART_ENABLE != 0U)
static hal_uart_handle_t s_debug_uart;
#endif

static bsp_status_t BSP_LED_Init(void)
{
    hal_gpio_config_t gpio_config;

    gpio_config.mode        = HAL_GPIO_MODE_OUTPUT;
    gpio_config.speed       = HAL_GPIO_SPEED_FREQ_LOW;
    gpio_config.pull        = HAL_GPIO_PULL_NO;
    gpio_config.output_type = HAL_GPIO_OUTPUT_PUSHPULL;
    gpio_config.init_state  = HW_LED_INIT_STATE;

    if (HAL_GPIO_Init(HW_LED_PORT, HW_LED_PIN, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

static bsp_status_t BSP_UART_Config(hal_uart_handle_t *huart,
                                    hal_uart_t instance,
                                    uint32_t baudrate,
                                    hal_gpio_t tx_port,
                                    uint32_t tx_pin,
                                    hal_gpio_t rx_port,
                                    uint32_t rx_pin,
                                    uint32_t alternate,
                                    IRQn_Type irqn,
                                    hal_cortex_nvic_preemp_priority_t preempt_priority,
                                    hal_cortex_nvic_sub_priority_t sub_priority,
                                    hal_status_t (*kernel_clock_config)(void))
{
    hal_uart_config_t uart_config;
    hal_gpio_config_t gpio_config;

    if ((huart == NULL) || (kernel_clock_config == NULL))
    {
        return BSP_ERROR;
    }

    if (HAL_UART_Init(huart, instance) != HAL_OK)
    {
        return BSP_ERROR;
    }

    if (kernel_clock_config() != HAL_OK)
    {
        return BSP_ERROR;
    }

    uart_config.baud_rate        = baudrate;
    uart_config.clock_prescaler  = HW_UART_PRESCALER;
    uart_config.word_length      = HW_UART_WORD_LENGTH;
    uart_config.stop_bits        = HW_UART_STOP_BITS;
    uart_config.parity           = HW_UART_PARITY;
    uart_config.direction        = HW_UART_DIRECTION;
    uart_config.hw_flow_ctl      = HW_UART_HW_FLOW_CONTROL;
    uart_config.oversampling     = HW_UART_OVERSAMPLING;
    uart_config.one_bit_sampling = HW_UART_ONE_BIT_SAMPLING;

    if (HAL_UART_SetConfig(huart, &uart_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    gpio_config.mode        = HAL_GPIO_MODE_ALTERNATE;
    gpio_config.output_type = HW_UART_GPIO_OUTPUT_TYPE;
    gpio_config.pull        = HW_UART_GPIO_PULL;
    gpio_config.speed       = HW_UART_GPIO_SPEED;
    gpio_config.alternate   = alternate;

    if (HAL_GPIO_Init(tx_port, tx_pin, &gpio_config) != HAL_OK)
    {
        return BSP_ERROR;
    }

    if ((rx_port == tx_port) && (alternate == gpio_config.alternate))
    {
        if (HAL_GPIO_Init(rx_port, rx_pin, &gpio_config) != HAL_OK)
        {
            return BSP_ERROR;
        }
    }
    else
    {
        if (HAL_GPIO_Init(rx_port, rx_pin, &gpio_config) != HAL_OK)
        {
            return BSP_ERROR;
        }
    }

    HAL_CORTEX_NVIC_SetPriority(irqn, preempt_priority, sub_priority);
    HAL_CORTEX_NVIC_EnableIRQ(irqn);

    return BSP_OK;
}

/* HAL RCC kernel-clock selection functions are instance-specific, so provide
 * tiny adapters while keeping the selection itself in hardware_config.h. */
static hal_status_t BSP_TMC_UART_SetKernelClock(void)
{
    return HW_TMC_UART_KERNEL_CLOCK_CONFIG();
}

#if (HW_DEBUG_UART_ENABLE != 0U)
static hal_status_t BSP_DEBUG_UART_SetKernelClock(void)
{
    return HW_DEBUG_UART_KERNEL_CLOCK_CONFIG();
}
#endif

bsp_status_t BSP_Init(void)
{
    if (BSP_LED_Init() != BSP_OK)
    {
        return BSP_ERROR;
    }

    if (BSP_UART_Config(&s_tmc_uart,
                        HW_TMC_UART_INSTANCE,
                        HW_TMC_UART_BAUDRATE,
                        HW_TMC_UART_TX_PORT,
                        HW_TMC_UART_TX_PIN,
                        HW_TMC_UART_RX_PORT,
                        HW_TMC_UART_RX_PIN,
                        HW_TMC_UART_GPIO_AF,
                        HW_TMC_UART_IRQn,
                        HW_TMC_UART_IRQ_PREEMPT_PRIORITY,
                        HW_TMC_UART_IRQ_SUB_PRIORITY,
                        BSP_TMC_UART_SetKernelClock) != BSP_OK)
    {
        return BSP_ERROR;
    }

#if (HW_DEBUG_UART_ENABLE != 0U)
    if (BSP_UART_Config(&s_debug_uart,
                        HW_DEBUG_UART_INSTANCE,
                        HW_DEBUG_UART_BAUDRATE,
                        HW_DEBUG_UART_TX_PORT,
                        HW_DEBUG_UART_TX_PIN,
                        HW_DEBUG_UART_RX_PORT,
                        HW_DEBUG_UART_RX_PIN,
                        HW_DEBUG_UART_GPIO_AF,
                        HW_DEBUG_UART_IRQn,
                        HW_DEBUG_UART_IRQ_PREEMPT_PRIORITY,
                        HW_DEBUG_UART_IRQ_SUB_PRIORITY,
                        BSP_DEBUG_UART_SetKernelClock) != BSP_OK)
    {
        return BSP_ERROR;
    }
#endif

    return BSP_OK;
}

void BSP_LED_On(void)
{
    HAL_GPIO_WritePin(HW_LED_PORT, HW_LED_PIN, HAL_GPIO_PIN_SET);
}

void BSP_LED_Off(void)
{
    HAL_GPIO_WritePin(HW_LED_PORT, HW_LED_PIN, HAL_GPIO_PIN_RESET);
}

void BSP_LED_Toggle(void)
{
    HAL_GPIO_TogglePin(HW_LED_PORT, HW_LED_PIN);
}

hal_uart_handle_t *BSP_UART_GetHandle(bsp_uart_id_t id)
{
    if (id == BSP_UART_TMC)
    {
        return &s_tmc_uart;
    }

#if (HW_DEBUG_UART_ENABLE != 0U)
    if (id == BSP_UART_DEBUG)
    {
        return &s_debug_uart;
    }
#endif

    return NULL;
}

void HW_TMC_UART_IRQ_HANDLER(void)
{
    HAL_UART_IRQHandler(&s_tmc_uart);
}

#if (HW_DEBUG_UART_ENABLE != 0U)
void HW_DEBUG_UART_IRQ_HANDLER(void)
{
    HAL_UART_IRQHandler(&s_debug_uart);
}
#endif
